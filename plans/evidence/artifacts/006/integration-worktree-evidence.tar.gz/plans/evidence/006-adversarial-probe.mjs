import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(new URL('../../apps/credential-tests/package.json', import.meta.url));
const { build } = require('esbuild');
const { Miniflare } = require('miniflare');
const root = new URL('../../', import.meta.url).pathname;
const cryptoBundle = await build({entryPoints:[root+'apps/web/src/lib/codex-credential-crypto.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const {sealCredentials,openCredentials} = await import('data:text/javascript;base64,'+Buffer.from(cryptoBundle.outputFiles[0].text).toString('base64'));
const ring={current:'fixture',keys:{fixture:'01'.repeat(32)}};
const large={access:'\\'.repeat(8192),refresh:'\\'.repeat(8192),identity:'\\'.repeat(8192),expiresAt:0};
const sealed=await sealCredentials(large,'owner',1,ring);
await assert.rejects(openCredentials(sealed,'owner',1,ring),/credential_integrity/);
console.log(JSON.stringify({probe:'seal/open bound mismatch',acceptedTokenBytes:8192,envelopeBytes:sealed.length,openRejected:true}));
const script = await build({stdin:{contents:`import {FixtureCredential} from './apps/credential-tests/src/entry.ts'; export class ProbeCredential extends FixtureCredential { snapshot(){return this.ctx.storage.sql.exec('SELECT sealed FROM credential').one().sealed;} replay(sealed){this.ctx.storage.sql.exec('UPDATE credential SET sealed=?',sealed);} } export default {fetch:()=>new Response('Not found',{status:404})};`,resolveDir:root,sourcefile:'probe.ts'},bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers']});
let calls=0;
const tokens={access:'fixture-one',refresh:'fixture-refresh-one',expiresAt:0};
const rotated={access:'fixture-two',refresh:'fixture-refresh-two',expiresAt:4102444800000};
const mf=new Miniflare({modules:true,script:script.outputFiles[0].text,compatibilityDate:'2026-03-10',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],durableObjects:{CodexCredential:{className:'ProbeCredential',useSQLite:true}},bindings:{CODEX_CREDENTIAL_CURRENT_KEY_VERSION:'fixture',CODEX_CREDENTIAL_KEYS:JSON.stringify(ring.keys)},outboundService:async request=>{assert.equal(request.url,'https://credential-fixture.invalid/rotate');assert.deepEqual(await request.json(),{refresh:tokens.refresh});calls++;return Response.json(rotated);}});
try {
 const db=await mf.getD1Database('DB');
 await db.exec("CREATE TABLE user(id TEXT PRIMARY KEY); CREATE TABLE codex_connections(user_id TEXT PRIMARY KEY,generation INTEGER,revoked INTEGER,status TEXT,projection_version INTEGER,updated_at INTEGER); INSERT INTO user VALUES('owner'); INSERT INTO codex_connections VALUES('owner',1,0,'connected',0,0)");
 const ns=await mf.getDurableObjectNamespace('CodexCredential');const stub=ns.get(ns.idFromName('owner'));
 assert.equal((await stub.install('owner',1,tokens)).status,'connected');
 const old=await stub.snapshot();
 assert.equal((await stub.ensureFresh('owner')).status,'connected');assert.equal(calls,1);
 await stub.replay(old);
 assert.equal((await stub.ensureFresh('owner')).status,'connected');assert.equal(calls,2);
 console.log(JSON.stringify({probe:'same-generation ciphertext replay',refreshDispatches:calls,metadataRewound:false}));
} finally {await mf.dispose();}
const production = await build({entryPoints:[root+'apps/credential-tests/src/entry.ts'],bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers']});
const productionMf = new Miniflare({modules:true,script:production.outputFiles[0].text,compatibilityDate:'2026-03-10',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],durableObjects:{CodexCredential:{className:'CodexCredential',useSQLite:true}},bindings:{CODEX_CREDENTIAL_CURRENT_KEY_VERSION:'fixture',CODEX_CREDENTIAL_KEYS:JSON.stringify(ring.keys)},outboundService:()=>{throw new Error('unexpected external I/O');}});
try {
 const ns=await productionMf.getDurableObjectNamespace('CodexCredential'); const stub=ns.get(ns.idFromName('owner'));
 const denied=[];
 for(const property of ['env','ctx','constructor','__proto__']) {
  try { await stub[property]; throw new Error('unexpected property exposure'); } catch(error) { if(error.message==='unexpected property exposure') throw error; denied.push(property); }
 }
 console.log(JSON.stringify({probe:'production inherited RPC property access',denied}));
} finally {await productionMf.dispose();}
