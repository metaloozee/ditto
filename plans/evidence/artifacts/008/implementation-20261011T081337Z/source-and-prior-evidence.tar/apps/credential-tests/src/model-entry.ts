import { WorkerEntrypoint } from "cloudflare:workers";
import type { ModelTransportDescriptorV1 } from "../../../packages/runtime-contracts/src/model.js";
import type { ModelClaimRpc } from "../../web/src/lib/model-product-authority";
import {
	type ModelProductBindings,
	performPrivateModelRequest,
	readPrivateModelPermit,
} from "../../web/src/lib/model-product-transport";

export { PiDurableHostFixture } from "../../runtime/src/pi-durable-host.ts";
export {
	CandidateFixtureCredential,
	CodexCredential,
	FixtureCredential,
} from "./entry";

import type { QueueDecisionV2 } from "../../../packages/runtime-contracts/src/product-command.js";
import {
	type CandidateRuntimeScope,
	type CandidateSessionBindings,
	PiDurableProductSession,
	parseCandidateRuntimeScope,
} from "../../runtime/src/pi-durable-product-session.ts";
import { readOwnedConfigurationAuthority } from "../../web/src/lib/configuration-product-authority";
import { CANDIDATE_MODEL_POLICY } from "../../web/src/lib/model-product-authority";
import { CandidateProductCommands } from "../../web/src/lib/session-command-candidate";
import type { CandidateFixtureCredential } from "./entry";

export class FixtureProduct extends WorkerEntrypoint<ModelProductBindings> {
	async readConfigurationAuthority(input: unknown, selection?: unknown) {
		const credential =
			await this.env.CodexCredential.getByName("owner").status("owner");
		if (
			selection !== undefined &&
			(credential.status !== "connected" || credential.generation !== 1)
		)
			return { version: 1 as const, status: "denied" as const };
		return readOwnedConfigurationAuthority(
			this.env.DB,
			{
				version: 1,
				userId: "owner",
				projectId: "project",
				workspaceSessionId: "session",
				identityId: "executor",
				incarnationId: "incarnation",
				controllerNamespace: "fixture-execution-v1",
				lifecycleGeneration: 1,
				runtimeOwnerVersion: 1,
				connectionGeneration: 1,
				capabilityRevision: 1,
			},
			input,
			selection,
			true,
		);
	}
	async readSecondConfigurationAuthority(input: unknown, selection?: unknown) {
		const credential =
			await this.env.CodexCredential.getByName("owner").status("owner");
		if (
			selection !== undefined &&
			(credential.status !== "connected" || credential.generation !== 1)
		)
			return { version: 1 as const, status: "denied" as const };
		return readOwnedConfigurationAuthority(
			this.env.DB,
			{
				version: 1,
				userId: "owner",
				projectId: "project",
				workspaceSessionId: "session-2",
				identityId: "executor-2",
				incarnationId: "incarnation-2",
				controllerNamespace: "fixture-execution-v1",
				lifecycleGeneration: 1,
				runtimeOwnerVersion: 1,
				connectionGeneration: 1,
				capabilityRevision: 1,
			},
			input,
			selection,
			true,
		);
	}
	requestModel(input: unknown, capability: ModelClaimRpc) {
		return performPrivateModelRequest(this.env, input, capability, true);
	}
	readModelPermit(input: unknown, descriptor: ModelTransportDescriptorV1) {
		return readPrivateModelPermit(this.env.DB, input, descriptor, true);
	}
	fetch() {
		return new Response("Not found", { status: 404 });
	}
}
type CandidateFixtureBindings = CandidateSessionBindings & {
	DB: D1Database;
	CandidateCredential: DurableObjectNamespace<CandidateFixtureCredential>;
};

export class CandidateFixtureSession extends PiDurableProductSession {
	private retired = false;
	private alarmCompletion: Promise<void> | undefined;
	async alarm() {
		if (this.retired) return;
		this.alarmCompletion = super.alarm();
		await this.alarmCompletion;
	}
	async retireFixture() {
		this.retired = true;
		await this.alarmCompletion;
		if (this.host) {
			await this.host.yield();
			await this.host.awaitClosure();
			this.host = undefined;
		}
		await this.ctx.storage.deleteAlarm();
	}
	async reopenFixture() {
		this.retired = true;
		try {
			await this.alarmCompletion;
			if (this.host) {
				await this.host.yield();
				await this.host.awaitClosure();
				this.host = undefined;
			}
			await this.activate();
		} finally {
			this.retired = false;
		}
		await (await this.activate()).repairWakeup();
	}
	async candidateSnapshot() {
		if (!this.host) await this.activate();
		return {
			conversations: this.ctx.storage.sql
				.exec("SELECT count(*) AS count FROM conversations")
				.one().count,
			submissions: this.ctx.storage.sql
				.exec("SELECT * FROM submissions")
				.toArray(),
			commands: this.ctx.storage.sql
				.exec(
					"SELECT id,run,state,sequence,submission FROM host_commands ORDER BY sequence",
				)
				.toArray(),
			runs: this.ctx.storage.sql.exec("SELECT * FROM host_runs").toArray(),
			members: this.ctx.storage.sql
				.exec(
					"SELECT m.* FROM host_members m JOIN host_commands c ON c.assistant=m.assistant ORDER BY c.sequence",
				)
				.toArray(),
			projections: this.ctx.storage.sql
				.exec("SELECT * FROM host_projections")
				.toArray(),
			effects: this.ctx.storage.sql
				.exec("SELECT id,state,epoch FROM host_effects")
				.toArray(),
			safety: this.ctx.storage.sql
				.exec("SELECT reason FROM host_safety")
				.toArray(),
			retained: this.ctx.storage.sql
				.exec(
					"SELECT p.payload,i.content FROM host_product_commands p LEFT JOIN host_inbox i ON i.id=p.id",
				)
				.toArray(),
			invocations: this.ctx.storage.sql
				.exec("SELECT * FROM host_invocations")
				.toArray(),
		};
	}
}

export class CandidateFixtureProduct extends WorkerEntrypoint<CandidateFixtureBindings> {
	private commands() {
		return new CandidateProductCommands(
			this.env.DB,
			{
				readSelection: (subject) =>
					this.env.CandidateSessions.getByName(
						subject.workspaceSessionId,
					).readSelection(subject),
				targetStatus: (subject, runId) =>
					this.env.CandidateSessions.getByName(
						subject.workspaceSessionId,
					).targetStatus(subject, runId),
			},
			(owner) => this.env.CandidateCredential.getByName(owner),
		);
	}
	admitOwned(userId: string, input: unknown) {
		return this.commands().admit(userId, input);
	}
	drain() {
		return this.commands().drain((sessionId, commandId, ownerVersion) =>
			this.env.CandidateSessions.getByName(sessionId).deliverCommand(
				commandId,
				ownerVersion,
			),
		);
	}
	reconstructCommand(commandId: string, ownerVersion: number) {
		return this.commands().reconstruct(commandId, ownerVersion);
	}
	readRuntimeAuthority(value: CandidateRuntimeScope) {
		const scope = parseCandidateRuntimeScope(value);
		return this.commands().runtimeAuthority(
			scope.userId,
			scope.projectId,
			scope.workspaceSessionId,
		);
	}
	async readCandidateSubject(commandId: string, ownerVersion: number) {
		try {
			return await this.commands().subjectForCommand(commandId, ownerVersion);
		} catch {
			return null;
		}
	}
	reconcileCandidateDecision(decision: QueueDecisionV2) {
		return this.commands().reconcileDecision(
			decision.commandId,
			decision.ownerVersion,
			decision,
		);
	}
	async readCandidateConfigurationAuthority(
		commandId: string,
		input: unknown,
		selection?: unknown,
	) {
		const subject = await this.readCandidateSubject(commandId, 1);
		if (!subject) return { version: 1 as const, status: "denied" as const };
		const status = await this.env.CandidateCredential.getByName(
			subject.userId,
		).status(subject.userId);
		if (
			selection !== undefined &&
			(status.status !== "connected" ||
				status.generation !== subject.connectionGeneration)
		)
			return { version: 1 as const, status: "denied" as const };
		return readOwnedConfigurationAuthority(
			this.env.DB,
			subject,
			input,
			selection,
			true,
			CANDIDATE_MODEL_POLICY,
		);
	}
	requestModel(input: unknown, capability: ModelClaimRpc) {
		return performPrivateModelRequest(
			{ DB: this.env.DB, CodexCredential: this.env.CandidateCredential },
			input,
			capability,
			true,
		);
	}
	readModelPermit(input: unknown, descriptor: ModelTransportDescriptorV1) {
		return readPrivateModelPermit(
			this.env.DB,
			input,
			descriptor,
			true,
			CANDIDATE_MODEL_POLICY,
		);
	}
	fetch() {
		return new Response("Not found", { status: 404 });
	}
}

export default FixtureProduct;
