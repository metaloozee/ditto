import { env, fetchMock } from "cloudflare:test";
import { afterEach, beforeEach, expect, it } from "vitest";
import type { ModelTransportDescriptorV1 } from "../../../packages/runtime-contracts/src/model.js";
import m0 from "../../web/migrations/0000_wet_giant_girl.sql?raw";
import m1 from "../../web/migrations/0001_jazzy_firelord.sql?raw";
import m2 from "../../web/migrations/0002_sparkling_agent_zero.sql?raw";
import m3 from "../../web/migrations/0003_material_ghost_rider.sql?raw";
import m4 from "../../web/migrations/0004_same_stellaris.sql?raw";
import m5 from "../../web/migrations/0005_illegal_invisible_woman.sql?raw";
import m6 from "../../web/migrations/0006_late_wonder_man.sql?raw";
import m7 from "../../web/migrations/0007_amused_shinobi_shaw.sql?raw";
import m8 from "../../web/migrations/0008_chunky_sunset_bain.sql?raw";
import m9 from "../../web/migrations/0009_worthless_young_avengers.sql?raw";
import m10 from "../../web/migrations/0010_worthless_george_stacy.sql?raw";
import m11 from "../../web/migrations/0011_handy_loa.sql?raw";
import m12 from "../../web/migrations/0012_pale_hiroim.sql?raw";
import m13 from "../../web/migrations/0013_lonely_tigra.sql?raw";
import m14 from "../../web/migrations/0014_smiling_namora.sql?raw";
import m15 from "../../web/migrations/0015_opencode_contract_denials.sql?raw";
import m16 from "../../web/migrations/0016_git_push_contract_state.sql?raw";
import m17 from "../../web/migrations/0017_dazzling_sandman.sql?raw";
import m18 from "../../web/migrations/0018_old_whistler.sql?raw";
import m19 from "../../web/migrations/0019_needy_squadron_sinister.sql?raw";
import m20 from "../../web/migrations/0020_trusted_runtime_additive.sql?raw";
import m21 from "../../web/migrations/0021_first_lilandra.sql?raw";
import m22 from "../../web/migrations/0022_synthetic_model_transport.sql?raw";
import m23 from "../../web/migrations/0023_candidate_product_commands.sql?raw";
import {
	CANDIDATE_MODEL_POLICY,
	ModelProductAuthority,
} from "../../web/src/lib/model-product-authority";
import { CandidateProductCommands } from "../../web/src/lib/session-command-candidate";

import type { CandidateFixtureCredential } from "./entry";
import type {
	CandidateFixtureProduct,
	CandidateFixtureSession,
} from "./model-entry";

declare module "cloudflare:test" {
	interface ProvidedEnv {
		CandidateProduct: Service<CandidateFixtureProduct>;
		CandidateSessions: DurableObjectNamespace<CandidateFixtureSession>;
		CandidateCredential: DurableObjectNamespace<CandidateFixtureCredential>;
	}
}

const account = {
	version: 1,
	status: "available",
	generation: 1,
	revision: 1,
	models: [{ id: "faux-1", thinking: ["off"] }],
};
async function candidateCredential() {
	const credential = env.CandidateCredential.getByName("owner");
	await credential.install("owner", 1, {
		access: "synthetic-product-access",
		refresh: "synthetic-product-refresh",
		expiresAt: 4102444800000,
	});
	return credential;
}
let modelCalls = 0;
let trapInstalled = false;
function modelReplies() {
	if (!trapInstalled) {
		trapInstalled = true;
		fetchMock
			.get("https://codex-model-fixture.invalid")
			.intercept({ path: "/v1/stream", method: "POST" })
			.reply(() => {
				modelCalls++;
				return {
					statusCode: 200,
					data:
						[
							{ version: 1, type: "delta", text: "Synthetic product result" },
							{
								version: 1,
								type: "done",
								stopReason: "stop",
								inputTokens: 1,
								outputTokens: 1,
							},
						]
							.map((value) => JSON.stringify(value))
							.join("\n") + "\n",
					responseOptions: {
						headers: { "content-type": "application/x-ndjson" },
					},
				};
			})
			.persist();
	}
	return () => modelCalls;
}
let terminal = false;
const commands = (now: () => number = Date.now) =>
	new CandidateProductCommands(
		env.DB,
		{
			readSelection: async () => null,
			targetStatus: async (_subject, runId) => ({
				ownerVersion: 1,
				runId,
				state: terminal ? "terminal" : "not_delivered",
			}),
		},
		(owner) => env.CodexCredential.getByName(owner),
		now,
	);
const prompt = {
	version: 2,
	kind: "prompt",
	projectId: "project",
	idempotencyKey: "first",
	text: "Synthetic admitted command",
};
async function counts() {
	return Promise.all(
		[
			"workspace_sessions",
			"sandbox_identities",
			"session_commands",
			"messages",
			"workspace_runtime_work",
			"candidate_workspace_claims",
			"runtime_command_memberships",
		].map(
			async (table) =>
				(await env.DB.prepare(`SELECT count(*) AS n FROM ${table}`).first<{
					n: number;
				}>())!.n,
		),
	);
}
beforeEach(async () => {
	modelCalls = 0;
	terminal = false;
	fetchMock.activate();
	fetchMock.disableNetConnect();
	for (const migration of [
		m0,
		m1,
		m2,
		m3,
		m4,
		m5,
		m6,
		m7,
		m8,
		m9,
		m10,
		m11,
		m12,
		m13,
		m14,
		m15,
		m16,
		m17,
		m18,
		m19,
		m20,
		m21,
		m22,
		m23,
	])
		for (const statement of migration.split("--> statement-breakpoint"))
			if (statement.trim())
				await env.DB.exec(
					statement.replace(/^\s*--[^\n]*$/gm, "").replaceAll("\n", " "),
				);
	await env.DB.batch([
		env.DB.prepare(
			"INSERT INTO user(id,name,email,createdAt,updatedAt) VALUES('owner','Synthetic owner','owner@example.invalid',0,0)",
		),
		env.DB.prepare(
			"INSERT INTO projects(id,name,userId,status) VALUES('project','Synthetic project','owner','ready')",
		),
		env.DB.prepare(
			"INSERT INTO codex_connections VALUES('owner',1,0,'connected',0,0)",
		),
		env.DB.prepare(
			"INSERT INTO codex_fixture_capabilities VALUES('owner',1,1,?)",
		).bind(JSON.stringify(account)),
	]);
	expect(
		(
			await env.CodexCredential.getByName("owner").install("owner", 1, {
				access: "synthetic-product-access",
				refresh: "synthetic-product-refresh",
				expiresAt: 4102444800000,
			})
		).status,
	).toBe("connected");
});
afterEach(() => fetchMock.deactivate());

it("runs an actually admitted prompt through leased delivery, native DO alarm, Pi and the candidate credential claim path", async () => {
	await env.CandidateCredential.getByName("owner").install("owner", 1, {
		access: "synthetic-product-access",
		refresh: "synthetic-product-refresh",
		expiresAt: 4102444800000,
	});
	const calls = modelReplies();
	const receipt = await env.CandidateProduct.admitOwned("owner", prompt);
	const runtime = env.CandidateSessions.getByName(receipt.workspaceSessionId);
	try {
		await env.CandidateProduct.drain();
		expect(
			(
				await env.DB.prepare(
					"SELECT deliveryState FROM workspace_runtime_work WHERE commandId=?",
				)
					.bind(receipt.commandId)
					.first()
			)?.deliveryState,
		).toBe("delivered");
		await expect
			.poll(
				async () =>
					(await runtime.candidateSnapshot()).members.filter(
						(row) => row.state === "pending",
					).length,
				{ timeout: 3000 },
			)
			.toBe(0);
		const snapshot = await runtime.candidateSnapshot();
		expect(calls()).toBe(1);
		expect(snapshot.conversations).toBe(1);
		expect(snapshot.submissions).toHaveLength(1);
		expect(snapshot.commands).toMatchObject([
			{ id: receipt.commandId, sequence: receipt.commandSeq },
		]);
		expect(snapshot.members).toMatchObject([
			{ assistant: receipt.assistantMessageId, state: "complete" },
		]);
		expect(snapshot.projections).toMatchObject([
			{ assistant: receipt.assistantMessageId, state: "complete" },
		]);
		expect(JSON.stringify(snapshot.retained)).not.toContain(prompt.text);
		expect(
			(
				await env.DB.prepare(
					"SELECT decision FROM candidate_command_decisions WHERE commandId=?",
				)
					.bind(receipt.commandId)
					.first()
			)?.decision,
		).toBe("started");
		expect(await counts()).toEqual([1, 1, 1, 2, 1, 1, 1]);
	} finally {
		await runtime.retireFixture();
	}
});

it("admits concurrent identical first prompts with one receipt, identity, capacity claim and message pair", async () => {
	const [a, b] = await Promise.all([
		commands().admit("owner", prompt),
		commands().admit("owner", prompt),
	]);
	expect(a).toEqual(b);
	expect(await counts()).toEqual([1, 1, 1, 2, 1, 1, 0]);
	const command = await commands().reconstruct(a.commandId, 1);
	expect(command).toMatchObject({
		commandId: a.commandId,
		receiptId: a.receiptId,
		text: prompt.text,
		userMessageId: a.userMessageId,
		assistantMessageId: a.assistantMessageId,
	});
	await expect(
		commands().admit("owner", { ...prompt, text: "Changed" }),
	).rejects.toMatchObject({ code: "conflict" });
	expect(await counts()).toEqual([1, 1, 1, 2, 1, 1, 0]);
});
it("keeps one lifetime workspace claim for concurrent distinct first prompts", async () => {
	const results = await Promise.allSettled([
		commands().admit("owner", prompt),
		commands().admit("owner", { ...prompt, idempotencyKey: "second" }),
	]);
	expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);
	const rejected = results.find((r) => r.status === "rejected");
	expect(rejected?.status === "rejected" && rejected.reason).toMatchObject({
		code: "fixture_capacity_exhausted",
	});
	expect(await counts()).toEqual([1, 1, 1, 2, 1, 1, 0]);
});
it.each([
	"UPDATE projects SET status='deleting'",
	"UPDATE projects SET status='pending'",
	"UPDATE codex_connections SET revoked=1",
	"UPDATE codex_fixture_capabilities SET revision=2",
	"UPDATE codex_fixture_capabilities SET snapshot=json_set(snapshot,'$.models',json('[]'))",
	"INSERT INTO runtime_deleted_target_fences VALUES('project','project',1,0)",
])("rejects current readiness before all admission writes: %s", async (sql) => {
	await env.DB.prepare(sql).run();
	await expect(commands().admit("owner", prompt)).rejects.toMatchObject({
		code: "model_unconfigured",
	});
	expect(await counts()).toEqual([0, 0, 0, 0, 0, 0, 0]);
});
it("denies caller authority, byte overflow and foreign ownership without rows", async () => {
	for (const value of [
		{ ...prompt, userId: "owner" },
		{ ...prompt, text: "😀".repeat(2049) },
		{ ...prompt, kind: "retry_backup" },
	])
		await expect(commands().admit("owner", value)).rejects.toThrow();
	await expect(commands().admit("foreign", prompt)).rejects.toMatchObject({
		code: "model_unconfigured",
	});
	expect(await counts()).toEqual([0, 0, 0, 0, 0, 0, 0]);
});
it("rejects terminal and foreign targets but admits cold Stop after capability removal", async () => {
	const first = await commands().admit("owner", prompt);
	const follow = {
		...prompt,
		kind: "follow_up",
		sessionId: first.workspaceSessionId,
		targetRunId: first.commandId,
		idempotencyKey: "follow",
	};
	await expect(
		commands().admit("owner", { ...follow, targetRunId: "foreign" }),
	).rejects.toMatchObject({ code: "invalid_target" });
	terminal = true;
	await expect(commands().admit("owner", follow)).rejects.toMatchObject({
		code: "target_run_terminal",
	});
	await env.DB.batch([
		env.DB.prepare("DELETE FROM codex_fixture_capabilities"),
		env.DB.prepare("UPDATE codex_connections SET revoked=1"),
	]);
	const stop = await commands().admit("owner", {
		version: 2,
		kind: "stop",
		projectId: "project",
		sessionId: first.workspaceSessionId,
		targetRunId: first.commandId,
		idempotencyKey: "stop",
	});
	expect(stop.commandSeq).toBe(2);
	expect(await counts()).toEqual([1, 1, 2, 2, 2, 1, 0]);
	expect(await commands().admit("owner", prompt)).toEqual(first);
});
it.each(
	Array.from({ length: 11 }, (_, index) => index),
)("rolls back first admission at D1 batch boundary %s without leaking capacity or identity", async (boundary) => {
	const db = new Proxy(env.DB, {
		get(target, key) {
			if (key === "batch")
				return (statements: D1PreparedStatement[]) =>
					target.batch([
						...statements.slice(0, boundary),
						target.prepare("INSERT INTO missing_fixture_table VALUES(1)"),
						...statements.slice(boundary),
					]);
			const value: unknown = Reflect.get(target, key);
			return typeof value === "function" ? value.bind(target) : value;
		},
	});
	const faulted = new CandidateProductCommands(
		db,
		{
			readSelection: async () => null,
			targetStatus: async (_subject, runId) => ({
				ownerVersion: 1,
				runId,
				state: "not_delivered",
			}),
		},
		(owner) => env.CodexCredential.getByName(owner),
	);
	await expect(faulted.admit("owner", prompt)).rejects.toThrow(
		"missing_fixture_table",
	);
	expect(await counts()).toEqual([0, 0, 0, 0, 0, 0, 0]);
});

it("fails trusted reconstruction when admitted text or outbox membership changes", async () => {
	const first = await commands().admit("owner", prompt);
	await env.DB.prepare("UPDATE messages SET content='Changed' WHERE id=?")
		.bind(first.userMessageId)
		.run();
	expect(await commands().reconstruct(first.commandId, 1)).toBeNull();
});

it.each([
	"started",
	"expired",
] as const)("reconciles the exact %s outcome idempotently and never accepts the opposite fate", async (decision) => {
	let now = Date.now();
	const product = commands(() => now);
	const first = await product.admit("owner", prompt);
	const command = await product.reconstruct(first.commandId, 1);
	if (!command || command.kind !== "prompt")
		throw new Error("Missing admitted prompt");
	now = decision === "started" ? command.acceptedAt + 1 : command.deadlineAt;
	const evidence = {
		version: 2,
		commandId: command.commandId,
		ownerVersion: 1,
		runId: command.commandId,
		runEpoch: 1,
		decision,
		decidedAt: now,
		queueDeadlineAt: command.deadlineAt,
		payloadDigest: command.payloadDigest,
	};
	expect(await product.reconcileDecision(command.commandId, 1, evidence)).toBe(
		true,
	);
	expect(await product.reconcileDecision(command.commandId, 1, evidence)).toBe(
		true,
	);
	expect(
		await product.reconcileDecision(command.commandId, 1, {
			...evidence,
			payloadDigest: "a".repeat(64),
		}),
	).toBe(false);
	now = command.deadlineAt + 1;
	expect(
		await product.reconcileDecision(command.commandId, 1, {
			...evidence,
			decision: decision === "started" ? "expired" : "started",
			decidedAt: decision === "started" ? now : command.acceptedAt,
		}),
	).toBe(false);
	const subject = await product.subjectForCommand(command.commandId, 1);
	if (!subject) throw new Error("Missing owned subject");
	const descriptor: ModelTransportDescriptorV1 = {
		version: 1,
		subject,
		requestDigest: "b".repeat(64),
		attempt: {
			version: 1,
			effectId: "effect",
			operationId: "operation",
			runId: command.commandId,
			commandId: command.commandId,
			assistantId: command.assistantMessageId,
			taskId: 1,
			epoch: 1,
			attempt: 1,
			generation: 1,
			deadlineAt: now + 30000,
			requestDigest: "b".repeat(64),
			kind: "generation",
		},
	};
	const policy = new ModelProductAuthority(
		env.DB,
		() => now,
		CANDIDATE_MODEL_POLICY,
	);
	expect(await policy.current(descriptor)).toBe(decision === "started");
	const body = {
		version: 1 as const,
		protocol: "ditto-synthetic-ndjson-1" as const,
		purpose: "generation" as const,
		model: "faux-1" as const,
		thinking: "off" as const,
		transcript: "Synthetic policy boundary",
		options: { maxTokens: 64 },
	};
	if (decision === "started") {
		expect(await policy.open(descriptor)).not.toBeNull();
		expect(await policy.reserve(descriptor, body)).not.toBeNull();
		expect(await policy.permit(descriptor, body)).toBe(true);
		await env.DB.prepare(
			"UPDATE workspace_sessions SET runtimeProtocolVersion=1",
		).run();
		expect(await policy.current(descriptor)).toBe(false);
		expect(await policy.permit(descriptor, body)).toBe(false);
		await env.DB.prepare(
			"UPDATE workspace_sessions SET runtimeProtocolVersion=2",
		).run();
		expect(await policy.denial(descriptor)).toBe(false);
		expect(await policy.denial(descriptor)).toBe(false);
		expect(await policy.denial(descriptor)).toBe(true);
		expect(
			(
				await env.DB.prepare(
					"SELECT runtimeFailureReasonCode FROM workspace_sessions",
				).first()
			)?.runtimeFailureReasonCode,
		).toBe("model_contract_review");
		expect(await policy.permit(descriptor, body)).toBe(false);
	} else {
		expect(await policy.open(descriptor)).toBeNull();
		expect(await policy.reserve(descriptor, body)).toBeNull();
		expect(await policy.permit(descriptor, body)).toBe(false);
	}
	expect(
		await new ModelProductAuthority(env.DB, () => now).current(descriptor),
	).toBe(false);
	expect(
		await policy.current({
			...descriptor,
			subject: { ...subject, controllerNamespace: "fixture-execution-v1" },
		}),
	).toBe(false);
	expect(await counts()).toEqual([1, 1, 1, 2, 1, 1, 1]);
});

it("native alarms drain delivery order 3,1,2 through individual model turns without client scheduling", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const follow = (key: string) =>
		env.CandidateProduct.admitOwned("owner", {
			version: 2,
			kind: "follow_up",
			projectId: "project",
			sessionId: first.workspaceSessionId,
			targetRunId: first.commandId,
			idempotencyKey: key,
			text: `Synthetic ${key}`,
		});
	const second = await follow("second"),
		third = await follow("third");
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	try {
		const thirdAck = await runtime.deliverCommand(third.commandId, 1);
		expect(thirdAck).toMatchObject({
			receiptId: third.receiptId,
			acceptedPosition: 3,
		});
		expect((await runtime.candidateSnapshot()).submissions).toHaveLength(0);
		await runtime.deliverCommand(first.commandId, 1);
		await runtime.deliverCommand(second.commandId, 1);
		await expect
			.poll(
				async () =>
					(await runtime.candidateSnapshot()).members.filter(
						(member) => member.state === "complete",
					).length,
				{ timeout: 3000 },
			)
			.toBe(3);
		const snapshot = await runtime.candidateSnapshot();
		expect(calls()).toBe(3);
		expect(snapshot.submissions).toHaveLength(3);
		expect(snapshot.commands.map((row) => row.id)).toEqual([
			first.commandId,
			second.commandId,
			third.commandId,
		]);
		expect(snapshot.projections).toHaveLength(3);
		await runtime.reopenFixture();
		expect(await runtime.deliverCommand(third.commandId, 1)).toEqual(thirdAck);
		expect((await runtime.candidateSnapshot()).submissions).toHaveLength(3);
		expect(calls()).toBe(3);
	} finally {
		await runtime.retireFixture();
	}
});
it("lost delivery acknowledgment and new product invocation retain the receipt and one Pi submission", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	let now = Date.now();
	const dispatcher = commands(() => now);
	try {
		await dispatcher.drain(async (_session, commandId, version) => {
			await runtime.deliverCommand(commandId, version);
			throw new Error("Lost durable DO acknowledgment");
		});
		expect(
			await env.DB.prepare(
				"SELECT deliveryState,deliveryAttempts FROM workspace_runtime_work WHERE commandId=?",
			)
				.bind(first.commandId)
				.first(),
		).toMatchObject({ deliveryState: "pending", deliveryAttempts: 1 });
		await expect
			.poll(async () => (await runtime.candidateSnapshot()).members[0]?.state, {
				timeout: 3000,
			})
			.toBe("complete");
		await runtime.reopenFixture();
		now += 1001;
		await commands(() => now).drain((_session, id, version) =>
			runtime.deliverCommand(id, version),
		);
		expect(
			(
				await env.DB.prepare(
					"SELECT deliveryState FROM workspace_runtime_work WHERE commandId=?",
				)
					.bind(first.commandId)
					.first()
			)?.deliveryState,
		).toBe("delivered");
		expect(await env.CandidateProduct.admitOwned("owner", prompt)).toEqual(
			first,
		);
		expect((await runtime.candidateSnapshot()).submissions).toHaveLength(1);
		expect(calls()).toBe(1);
	} finally {
		await runtime.retireFixture();
	}
});
it("cold Stop after disconnect beats delivery gaps and retains multiple late message memberships across reopen", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const follow = (key: string) =>
		env.CandidateProduct.admitOwned("owner", {
			version: 2,
			kind: "follow_up",
			projectId: "project",
			sessionId: first.workspaceSessionId,
			targetRunId: first.commandId,
			idempotencyKey: key,
			text: `Synthetic ${key}`,
		});
	const second = await follow("second"),
		third = await follow("third");
	await env.DB.batch([
		env.DB.prepare("UPDATE codex_connections SET revoked=1"),
		env.DB.prepare("DELETE FROM codex_fixture_capabilities"),
	]);
	const stop = await env.CandidateProduct.admitOwned("owner", {
		version: 2,
		kind: "stop",
		projectId: "project",
		sessionId: first.workspaceSessionId,
		targetRunId: first.commandId,
		idempotencyKey: "stop",
	});
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	try {
		const stopAck = await runtime.deliverCommand(stop.commandId, 1);
		const stopped = await runtime.candidateSnapshot();
		expect(stopped.conversations).toBe(0);
		const stoppedEpoch = stopped.runs[0]?.epoch;
		await runtime.reopenFixture();
		for (const accepted of [third, first, second]) {
			const ack = await runtime.deliverCommand(accepted.commandId, 1);
			expect(await runtime.deliverCommand(accepted.commandId, 1)).toEqual(ack);
		}
		expect(await runtime.deliverCommand(stop.commandId, 1)).toEqual(stopAck);
		const snapshot = await runtime.candidateSnapshot();
		expect(snapshot.submissions).toHaveLength(0);
		expect(snapshot.members.map((row) => row.state)).toEqual([
			"failed",
			"failed",
			"failed",
		]);
		expect(snapshot.projections).toHaveLength(3);
		expect(snapshot.runs).toMatchObject([
			{ id: first.commandId, state: "canceled", epoch: stoppedEpoch },
		]);
		expect(calls()).toBe(0);
		expect(await env.CandidateProduct.admitOwned("owner", prompt)).toEqual(
			first,
		);
	} finally {
		await runtime.retireFixture();
	}
});
it("a follow-up admitted before completion but delivered afterward fails its own assistant without reopening the completed run", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const second = await env.CandidateProduct.admitOwned("owner", {
		version: 2,
		kind: "follow_up",
		projectId: "project",
		sessionId: first.workspaceSessionId,
		targetRunId: first.commandId,
		idempotencyKey: "late",
		text: "Synthetic delayed follow-up",
	});
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	try {
		await runtime.deliverCommand(first.commandId, 1);
		await expect
			.poll(async () => (await runtime.candidateSnapshot()).runs[0]?.state, {
				timeout: 3000,
			})
			.toBe("complete");
		await runtime.reopenFixture();
		const ack = await runtime.deliverCommand(second.commandId, 1);
		await runtime.reopenFixture();
		expect(await runtime.deliverCommand(second.commandId, 1)).toEqual(ack);
		const snapshot = await runtime.candidateSnapshot();
		expect(snapshot.members.map((row) => row.state)).toEqual([
			"complete",
			"failed",
		]);
		expect(snapshot.projections.map((row) => row.state)).toEqual([
			"complete",
			"failed",
		]);
		expect(snapshot.runs).toMatchObject([{ state: "complete" }]);
		expect(snapshot.submissions).toHaveLength(1);
		expect(calls()).toBe(1);
		expect(
			await env.CandidateProduct.admitOwned("owner", {
				version: 2,
				kind: "follow_up",
				projectId: "project",
				sessionId: first.workspaceSessionId,
				targetRunId: first.commandId,
				idempotencyKey: "late",
				text: "Synthetic delayed follow-up",
			}),
		).toEqual(second);
	} finally {
		await runtime.retireFixture();
	}
});
it("priority Stop fences a held credential claim without ordinary capacity or a second provider dispatch", async () => {
	const credential = await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	await credential.holdModel("claim");
	try {
		await runtime.deliverCommand(first.commandId, 1);
		await credential.waitModel();
		const stop = await env.CandidateProduct.admitOwned("owner", {
			version: 2,
			kind: "stop",
			projectId: "project",
			sessionId: first.workspaceSessionId,
			targetRunId: first.commandId,
			idempotencyKey: "stop-held",
		});
		await runtime.deliverCommand(stop.commandId, 1);
		const stopped = await runtime.candidateSnapshot();
		expect(Number(stopped.runs[0]?.epoch)).toBeGreaterThan(1);
		expect(["stopping", "canceled", "failed"]).toContain(
			stopped.runs[0]?.state,
		);
		expect(calls()).toBe(0);
		await credential.releaseModel();
		await expect
			.poll(async () => (await runtime.candidateSnapshot()).members[0]?.state, {
				timeout: 3000,
			})
			.toBe("failed");
		expect(calls()).toBe(0);
	} finally {
		await credential.releaseModel();
		await runtime.retireFixture();
	}
});
it("real delivery expires an admitted but unstarted instruction without creating a Pi root or provider effect", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await commands(() => Date.now() - 900001).admit(
		"owner",
		prompt,
	);
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	try {
		const ack = await runtime.deliverCommand(first.commandId, 1);
		await expect
			.poll(async () => (await runtime.candidateSnapshot()).members[0]?.state, {
				timeout: 3000,
			})
			.toBe("failed");
		await runtime.reopenFixture();
		expect(await runtime.deliverCommand(first.commandId, 1)).toEqual(ack);
		const snapshot = await runtime.candidateSnapshot();
		expect(snapshot.conversations).toBe(0);
		expect(snapshot.submissions).toHaveLength(0);
		expect(snapshot.projections).toMatchObject([
			{ assistant: first.assistantMessageId, state: "failed" },
		]);
		expect(
			(
				await env.DB.prepare(
					"SELECT decision FROM candidate_command_decisions WHERE commandId=?",
				)
					.bind(first.commandId)
					.first()
			)?.decision,
		).toBe("expired");
		expect(calls()).toBe(0);
	} finally {
		await runtime.retireFixture();
	}
});
it("product cancellation reconstructs a missing follow-up and closes its sequence without skipping the initial prompt", async () => {
	await candidateCredential();
	const calls = modelReplies();
	const first = await env.CandidateProduct.admitOwned("owner", prompt);
	const second = await env.CandidateProduct.admitOwned("owner", {
		version: 2,
		kind: "follow_up",
		projectId: "project",
		sessionId: first.workspaceSessionId,
		targetRunId: first.commandId,
		idempotencyKey: "canceled",
		text: "Synthetic canceled input",
	});
	const cancel = await env.CandidateProduct.admitOwned("owner", {
		version: 2,
		kind: "cancel",
		projectId: "project",
		sessionId: first.workspaceSessionId,
		targetCommandId: second.commandId,
		idempotencyKey: "cancel",
	});
	const runtime = env.CandidateSessions.getByName(first.workspaceSessionId);
	try {
		await runtime.deliverCommand(cancel.commandId, 1);
		expect((await runtime.candidateSnapshot()).submissions).toHaveLength(0);
		await runtime.deliverCommand(first.commandId, 1);
		await expect
			.poll(async () => (await runtime.candidateSnapshot()).members[0]?.state, {
				timeout: 3000,
			})
			.toBe("complete");
		const ack = await runtime.deliverCommand(second.commandId, 1);
		await runtime.reopenFixture();
		expect(await runtime.deliverCommand(second.commandId, 1)).toEqual(ack);
		const snapshot = await runtime.candidateSnapshot();
		expect(snapshot.members.map((row) => row.state)).toEqual([
			"complete",
			"failed",
		]);
		expect(snapshot.submissions).toHaveLength(1);
		expect(calls()).toBe(1);
	} finally {
		await runtime.retireFixture();
	}
});
