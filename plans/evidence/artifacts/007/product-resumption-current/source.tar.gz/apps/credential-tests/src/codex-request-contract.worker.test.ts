import { env, fetchMock, runInDurableObject, SELF } from "cloudflare:test";
import { afterEach, beforeEach, expect, it } from "vitest";
import m0 from "../../web/migrations/0000_wet_giant_girl.sql?raw";
import m1 from "../../web/migrations/0001_jazzy_firelord.sql?raw";
import m2 from "../../web/migrations/0002_sparkling_agent_zero.sql?raw";
import m13 from "../../web/migrations/0013_lonely_tigra.sql?raw";
import m14 from "../../web/migrations/0014_smiling_namora.sql?raw";
import m15 from "../../web/migrations/0015_opencode_contract_denials.sql?raw";
import m16 from "../../web/migrations/0016_git_push_contract_state.sql?raw";
import m17 from "../../web/migrations/0017_dazzling_sandman.sql?raw";
import m18 from "../../web/migrations/0018_old_whistler.sql?raw";
import m20 from "../../web/migrations/0020_trusted_runtime_additive.sql?raw";
import m21 from "../../web/migrations/0021_first_lilandra.sql?raw";
import m22 from "../../web/migrations/0022_synthetic_model_transport.sql?raw";
import { parseSyntheticModelBodyV1, parseSyntheticModelRequestV1, type ModelSubjectV1, type ModelTransportDescriptorV1, type SyntheticModelRequestV1 } from "../../../packages/runtime-contracts/src/model.js";
import { PiDurableHost, type PiDurableHostFixture } from "../../runtime/src/pi-durable-host.ts";
import { createPrivateModelAdapter, type PrivateModelTransport } from "../../runtime/src/pi-durable-models.ts";
import { ModelProductAuthority } from "../../web/src/lib/model-product-authority";
import { CodexCredential } from "../../web/src/lib/codex-credential-do";
import type { FixtureCredential, FixtureProduct } from "./entry";

declare module "cloudflare:test" { interface ProvidedEnv {
	PI_MODEL_HOST: DurableObjectNamespace<PiDurableHostFixture>;
	DB: D1Database;
	CodexCredential: DurableObjectNamespace<FixtureCredential>;
	CODEX_CREDENTIAL_CURRENT_KEY_VERSION: string;
	CODEX_CREDENTIAL_KEYS: string;
} }
const product = SELF as Service<FixtureProduct>;
const credential = {
	holdModel: (phase: "authority" | "credentials" | "claim") => env.CodexCredential.getByName("owner").holdModel(phase),
	waitModel: () => env.CodexCredential.getByName("owner").waitModel(),
	releaseModel: () => env.CodexCredential.getByName("owner").releaseModel(),
};
const subject: ModelSubjectV1 = { version: 1, userId: "owner", projectId: "project", workspaceSessionId: "session", identityId: "executor", incarnationId: "incarnation", controllerNamespace: "fixture-execution-v1", lifecycleGeneration: 1, runtimeOwnerVersion: 1, connectionGeneration: 1, capabilityRevision: 1 };
const account = { version: 1, status: "available", generation: 1, revision: 1, models: [{ id: "faux-1", thinking: ["off", "low", "high", "max"] }, { id: "faux-2", thinking: ["off", "low", "high", "max"] }] };
const syntheticTokens = { access: "synthetic-request-access", refresh: "synthetic-request-refresh", expiresAt: 4102444800000 };
const frames = [{ version: 1, type: "delta", text: "Synthetic answer ".repeat(50) }, { version: 1, type: "done", stopReason: "stop", inputTokens: 4, outputTokens: 6 }];
const encodedFrames = frames.map((frame) => JSON.stringify(frame)).join("\n") + "\n";
let calls: { body: ReturnType<typeof parseSyntheticModelBodyV1>; headerNames: string[] }[];
let installed = false;
let responses: { status: number; response: string }[] = [];
let defaultResponse = { status: 200, response: encodedFrames };
function upstream(status = 200, response = encodedFrames, times?: number) {
	if (times) responses.push(...Array.from({ length: times }, () => ({ status, response })));
	else defaultResponse = { status, response };
}
function installTrap() {
	if (installed) return;
	installed = true;
	fetchMock.get("https://codex-model-fixture.invalid").intercept({ path: "/v1/stream", method: "POST" }).reply((options) => {
		expect(typeof options.body).toBe("string");
		const body = parseSyntheticModelBodyV1(options.body);
		const headers = options.headers;
		expect(headers).toMatchObject({ "content-type": "application/json", accept: "application/x-ndjson", authorization: `Bearer ${syntheticTokens.access}` });
		calls.push({ body, headerNames: Object.keys(headers ?? {}).sort() });
		const selected = responses.shift() ?? defaultResponse;
		return { statusCode: selected.status, data: selected.response, responseOptions: { headers: { "content-type": "application/x-ndjson" } } };
	}).persist().delay(100);
}
function deferred() {
	let resolve!: () => void;
	const promise = new Promise<void>((r) => { resolve = r; });
	return { promise, resolve };
}
async function bounded<T>(promise: Promise<T>): Promise<T> {
	let timer: ReturnType<typeof setTimeout> | undefined;
	try { return await Promise.race([promise, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("Fixture bounded wait expired")), 3000); })]); }
	finally { clearTimeout(timer); }
}
async function until(check: () => boolean | Promise<boolean>) {
	const deadline = Date.now() + 3000;
	while (!(await check())) {
		if (Date.now() >= deadline) throw new Error("Fixture bounded observation expired");
		await new Promise<void>((r) => setTimeout(r, 1));
	}
}
beforeEach(async () => {
	calls = []; responses = []; defaultResponse = { status: 200, response: encodedFrames };
	fetchMock.activate(); fetchMock.disableNetConnect(); installTrap();
	for (const migration of [m0, m1, m2, m13, m14, m15, m16, m17, m18, m20, m21, m22])
		for (const statement of migration.split("--> statement-breakpoint"))
			if (statement.trim()) await env.DB.exec(statement.replaceAll("\n", " "));
	await env.DB.batch([
		env.DB.prepare("INSERT INTO user(id,name,email,createdAt,updatedAt) VALUES('owner','Synthetic owner','owner@example.invalid',0,0)"),
		env.DB.prepare("INSERT INTO projects(id,name,userId,status) VALUES('project','Synthetic project','owner','ready')"),
		env.DB.prepare("INSERT INTO workspace_sessions(id,projectId,userId,status,sandboxIdentityId,runtimeOwner,runtimeOwnerVersion) VALUES('session','project','owner','active','executor','trusted_v1',1)"),
		env.DB.prepare("INSERT INTO sandbox_identities(id,kind,sandboxId,containerId,userId,projectId,workspaceSessionId,state,controllerClass,controllerNamespace,incarnationId) VALUES('executor','workspace_session','sandbox','container','owner','project','session','ready','Sandbox','fixture-execution-v1','incarnation')"),
		env.DB.prepare("INSERT INTO codex_connections VALUES('owner',1,0,'connected',0,0)"),
		env.DB.prepare("INSERT INTO codex_fixture_capabilities VALUES('owner',1,1,?)").bind(JSON.stringify(account)),
		env.DB.prepare("INSERT INTO session_commands(id,userId,targetKind,targetId,projectId,sessionId,kind,commandSeq,payloadVersion,userMessageId,assistantMessageId,payloadDigest,acceptedAt,deadlineAt) VALUES('command','owner','workspace_session','session','project','session','prompt',1,1,'user-message','assistant','fixture-digest',0,?)").bind(Date.now() + 600000),
		env.DB.prepare("INSERT INTO runtime_command_memberships(commandId,sessionId,runId,userMessageId,assistantMessageId,runEpoch) VALUES('command','session','run','user-message','assistant',1)"),
	]);
	expect((await env.CodexCredential.getByName("owner").install("owner", 1, syntheticTokens)).status).toBe("connected");
});
afterEach(() => {
	// Denial tests deliberately leave the fixed-destination credential-bearing trap unused.
	for (const pending of fetchMock.pendingInterceptors())
		expect(pending).toMatchObject({ origin: "https://codex-model-fixture.invalid", path: "/v1/stream", method: "POST", persist: true });
	fetchMock.deactivate();
});

async function gate(name: string, test: (f: { host: PiDurableHost; storage: DurableObjectStorage; start(): Promise<void>; settled: Promise<void>; snapshot(): Promise<unknown>; claimFlush(): { entered: Promise<void>; release(): void } }) => Promise<void>, options: { transform?: (request: SyntheticModelRequestV1) => unknown; threeDenials?: boolean; retry?: boolean; purpose?: "generation" | "git_metadata" } = {}) {
	await runInDurableObject(env.PI_MODEL_HOST.getByName(name), async (_instance, state) => {
		const finished = deferred();
		const probe: ModelTransportDescriptorV1 = { version: 1, subject, requestDigest: "0".repeat(64), attempt: { version: 1, effectId: "check", operationId: "check", runId: "run", commandId: "command", assistantId: "assistant", taskId: 1, epoch: 1, attempt: 1, generation: 1, deadlineAt: Date.now() + 600000, requestDigest: "0".repeat(64), kind: "generation" } };
		let hold: { entered: ReturnType<typeof deferred>; released: ReturnType<typeof deferred> } | undefined;
		const storage = new Proxy(state.storage, { get(target, key) {
			if (key === "sync") return async () => {
				if (hold && state.storage.sql.exec("SELECT 1 FROM host_model_dispatch WHERE claimed=1").toArray().length) {
					const waiting = hold; hold = undefined; waiting.entered.resolve(); await waiting.released.promise;
				}
				await target.sync();
			};
			const value: unknown = Reflect.get(target, key, target);
			return typeof value === "function" ? value.bind(target) : value;
		} });
		const transport: PrivateModelTransport = {
			readModelPermit: (request, descriptor) => product.readModelPermit(request, descriptor),
			requestModel: async (input, capability) => {
				try {
					const request = parseSyntheticModelRequestV1(input);
					if (options.threeDenials) {
						for (let count = 0; count < 3; count++) expect((await product.requestModel({ ...request, method: "GET" }, capability)).status).toBe("denied");
						return { version: 1, status: "denied" };
					}
					return await product.requestModel(options.transform ? options.transform(request) : request, capability);
				} finally { finished.resolve(); }
			},
		};
		const host = await PiDurableHost.open(storage, {
			now: Date.now, authority: async () => ({ current: await new ModelProductAuthority(env.DB).current(probe), generation: 1, executor: 1 }),
			budgets: { workMs: 10000, drainMs: 1000 }, operationMs: { model: 10000, tool: 10000 },
			wakeup: { getAlarm: async () => null, setAlarm: async () => {} },
			options: (guard) => {
				const adapter = createPrivateModelAdapter(guard, transport, subject, options.purpose ?? "generation");
				return { models: adapter.models, registry: adapter.registry, settings: { extensions: [adapter.extension], retry: { enabled: options.retry ?? false, maxRetries: 1, baseDelayMs: 1 }, compaction: { enabled: false, reserveTokens: 64, keepRecentTokens: 1, backgroundTokens: 0 } } };
			},
		});
		try {
			await host.accept("command", "Synthetic request", { run: "run", user: "user-message", assistant: "assistant", sequence: 1 });
			await test({ host, storage: state.storage, start: async () => { await host.schedule("command"); }, settled: finished.promise,
				claimFlush: () => { const entered = deferred(), released = deferred(); hold = { entered, released }; return { entered: entered.promise, release: released.resolve }; },
				snapshot: async () => ({ calls: calls.length, windows: (await env.DB.prepare("SELECT consumedRequests,contractDenials,closeReason,openSlot FROM privileged_operations").all()).results,
					admissions: (await env.DB.prepare("SELECT effectId,purpose,state,requestDigest FROM model_request_admissions").all()).results,
					claims: state.storage.sql.exec("SELECT claimed FROM host_model_dispatch").toArray(), runs: state.storage.sql.exec("SELECT state,epoch FROM host_runs").toArray() }),
			});
		} finally {
			hold?.released.resolve();
			await credential.releaseModel();
			await host.yield();
			await state.storage.deleteAlarm();
			await state.storage.sync();
		}
	});
}

it("the mandatory adapter constructs an exact credential-owned request and bounded stream through private RPC", async () => {
	upstream();
	await gate("valid", async (f) => {
		await f.start(); await bounded(f.settled); await f.host.waitIdle();
		expect(calls).toHaveLength(1);
		expect(calls[0].body).toMatchObject({ version: 1, protocol: "ditto-synthetic-ndjson-1", purpose: "generation", model: "faux-1", thinking: "off", options: { maxTokens: 4096 } });
		expect(calls[0].body.transcript).toContain("Synthetic request");
		expect(calls[0].headerNames).toEqual(["accept", "authorization", "content-type"]);
		expect(await f.snapshot()).toMatchObject({ calls: 1, windows: [{ consumedRequests: 1, contractDenials: 0 }], admissions: [{ state: "complete" }], claims: [{ claimed: 1 }], runs: [{ state: "complete" }] });
		console.log("[007-product-constructed]", JSON.stringify({ ...calls[0], frames, snapshot: await f.snapshot() }));
	});
});

for (const transform of [
	(request: SyntheticModelRequestV1) => ({ ...request, method: "GET" }),
	(request: SyntheticModelRequestV1) => ({ ...request, url: `${request.url}?proxy=1` }),
	(request: SyntheticModelRequestV1) => ({ ...request, headers: [...request.headers, ["authorization", "caller"]] }),
	(request: SyntheticModelRequestV1) => ({ ...request, body: request.body.replace('"version":1', '"version":1,"version":1') }),
	(request: SyntheticModelRequestV1) => ({ ...request, body: JSON.stringify({ ...JSON.parse(request.body), thinking: "high" }) }),
]) it(`invalid or differently bound request dispatches zero calls: ${transform.toString()}`, async () => {
	upstream();
	await gate("request-denial", async (f) => {
		await f.start(); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ windows: [{ consumedRequests: 0, contractDenials: 1 }], admissions: [], claims: [{ claimed: 0 }] });
	}, { transform });
});

const revocations = [
	"UPDATE projects SET userId='foreign'", "UPDATE workspace_sessions SET status='archived'",
	"UPDATE workspace_sessions SET runtimeOwnerVersion=2", "UPDATE workspace_sessions SET runtimeOwner='legacy'",
	"UPDATE sandbox_identities SET kind='project_seed'", "UPDATE sandbox_identities SET retiredAt=1",
	"UPDATE sandbox_identities SET lifecycleGeneration=2", "UPDATE sandbox_identities SET incarnationId='replacement'",
	"UPDATE sandbox_identities SET controllerNamespace='foreign'", "UPDATE codex_connections SET revoked=1,generation=2",
	"UPDATE codex_fixture_capabilities SET snapshot=json_set(snapshot,'$.models',json('[]'))",
];
for (const phase of ["authority", "credentials", "claim"] as const)
	for (const sql of revocations) it(`fresh D1 revocation after held ${phase} prevents attachment: ${sql}`, async () => {
		upstream();
		await credential.holdModel(phase);
		await gate(`race-${phase}`, async (f) => {
			await f.start(); await bounded(credential.waitModel());
			// Foreign membership fixtures change the owner without creating an authorized replacement.
			if (sql.includes("userId='foreign'")) await env.DB.prepare("INSERT INTO user(id,name,email,createdAt,updatedAt) VALUES('foreign','Foreign','foreign@example.invalid',0,0)").run();
			await env.DB.prepare(sql).run();
			await credential.releaseModel(); await bounded(f.settled);
			expect(calls).toHaveLength(0);
			expect(f.storage.sql.exec("SELECT claimed FROM host_model_dispatch").one().claimed).toBe(0);
		});
	});

it("Stop wins during credential preparation before the host acknowledgment, with zero fetches", async () => {
	upstream(); await credential.holdModel("credentials");
	await gate("stop-preparation", async (f) => {
		await f.start(); await bounded(credential.waitModel());
		await f.host.stop("stop", "run"); await credential.releaseModel(); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ windows: [{ consumedRequests: 1 }], admissions: [{ state: "failed_known" }], claims: [{ claimed: 0 }] });
	});
});

it("a model capability revoked while the actual claim flush is held is freshly denied after that flush", async () => {
	upstream();
	await gate("claim-flush-revoke", async (f) => {
		const hold = f.claimFlush(); await f.start(); await bounded(hold.entered);
		await env.DB.prepare("UPDATE codex_fixture_capabilities SET revision=2").run(); hold.release(); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ windows: [{ consumedRequests: 1 }], admissions: [{ state: "failed_known" }], claims: [{ claimed: 1 }] });
	});
});

it("three contract denials durably close the window, record review and halt the exact run without reentry", async () => {
	upstream();
	await gate("three-denials", async (f) => {
		await f.start(); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ windows: [{ consumedRequests: 0, contractDenials: 3, closeReason: "contract_denials" }], runs: [{ state: "failed" }], claims: [{ claimed: 0 }] });
		expect(await env.DB.prepare("SELECT runtimeFailureReasonCode FROM workspace_sessions").first()).toEqual({ runtimeFailureReasonCode: "model_contract_review" });
	}, { threeDenials: true });
});

it("production credentials remain unavailable even with connected fixture records", async () => {
	const stub = env.CodexCredential.getByName("owner");
	await runInDurableObject(stub, async (_instance, state) => {
		const production = new CodexCredential(state, env);
		expect(await production.requestModel({}, { describe: async () => { throw new Error("must not inspect"); }, claim: async () => ({ status: "admitted" }), halt: async () => ({ status: "halted" }) })).toEqual({ version: 1, status: "unavailable" });
	});
	expect(calls).toHaveLength(0);
});

it("a known generation failure retries as a separate admitted attempt", async () => {
	upstream(503, "", 1); upstream();
	await gate("generation-retry", async (f) => {
		await f.start(); await until(() => calls.length === 2); await f.host.waitIdle();
		expect(await f.snapshot()).toMatchObject({ calls: 2, windows: [{ consumedRequests: 1, closeReason: "failed_known" }, { consumedRequests: 1, closeReason: "complete" }], admissions: [{ state: "failed_known" }, { state: "complete" }], claims: [{ claimed: 1 }, { claimed: 1 }] });
	}, { retry: true });
});

it("Git metadata's reserved attempt is never refunded after a known failure", async () => {
	upstream(503, "", 1); upstream();
	await gate("metadata-reservation", async (f) => {
		await f.start(); await until(() => f.storage.sql.exec("SELECT id FROM host_effects").toArray().length === 2);
		await bounded(f.settled); await f.host.yield();
		expect(calls).toHaveLength(1);
		expect(await f.snapshot()).toMatchObject({ windows: [{ consumedRequests: 1 }], admissions: [{ purpose: "git_metadata", state: "failed_known" }] });
	}, { retry: true, purpose: "git_metadata" });
});

it("Stop after host acknowledgment retains the credential-bearing start and late product evidence", async () => {
	upstream();
	await gate("stop-after-admission", async (f) => {
		await f.start(); await until(() => calls.length === 1);
		await f.host.stop("stop", "run"); await bounded(f.settled);
		expect(calls).toHaveLength(1);
		expect(await f.snapshot()).toMatchObject({ admissions: [{ state: "complete" }], claims: [{ claimed: 1 }] });
		expect(f.storage.sql.exec("SELECT state FROM host_effects").one().state).toBe("admitted");
		console.log("[007-product-stop-after]", JSON.stringify(await f.snapshot()));
	});
});

it("accepted custom summaries use the same private transport and exactly one fresh association", async () => {
	upstream();
	await gate("custom-summary", async (f) => {
		await f.start();
		await until(async () => (await f.host.inspect()).tasks.some((t) => t.record.kind === "pi.generation" && t.record.state.status === "terminal"));
		await f.host.compact("command");
		await until(() => calls.length === 2);
		await f.host.waitIdle();
		expect(calls.map((call) => call.body.purpose)).toEqual(["generation", "custom_summary"]);
		expect(calls[1].body.transcript).toContain("Synthetic request");
		expect(await f.snapshot()).toMatchObject({ admissions: [{ purpose: "generation", state: "complete" }, { purpose: "custom_summary", state: "complete" }], claims: [{ claimed: 1 }, { claimed: 1 }] });
		console.log("[007-product-summary]", JSON.stringify({ body: calls[1].body, frames, snapshot: await f.snapshot() }));
	}, { retry: true });
});

it("a known custom summary failure spends its one attempt without an automatic retry", async () => {
	upstream(200, encodedFrames, 1); upstream(503, "");
	await gate("custom-summary-failure", async (f) => {
		await f.start();
		await until(async () => (await f.host.inspect()).tasks.some((t) => t.record.kind === "pi.generation" && t.record.state.status === "terminal"));
		await f.host.compact("command");
		await until(() => calls.length === 2);
		await f.host.yield();
		expect(calls.map((call) => call.body.purpose)).toEqual(["generation", "custom_summary"]);
		expect(await f.snapshot()).toMatchObject({ admissions: [{ state: "complete" }, { purpose: "custom_summary", state: "failed_known" }], claims: [{ claimed: 1 }, { claimed: 1 }] });
	}, { retry: true });
});

it("disconnect of the local credential record while preparation is held prevents fetch even before a D1 projection", async () => {
	upstream(); await credential.holdModel("credentials");
	await gate("local-disconnect", async (f) => {
		await f.start(); await bounded(credential.waitModel());
		await env.CodexCredential.getByName("owner").revoke("owner", 2);
		await credential.releaseModel(); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ admissions: [{ state: "failed_known" }], claims: [{ claimed: 0 }] });
	});
});

it("real epoch-first Stop during the claim durability flush prevents fetch without refunding consumption", async () => {
	upstream();
	await gate("claim-flush-stop", async (f) => {
		const hold = f.claimFlush(); await f.start(); await bounded(hold.entered);
		const stopped = f.host.stop("stop", "run");
		expect(f.storage.sql.exec("SELECT epoch FROM host_runs WHERE id='run'").one().epoch).toBe(2);
		hold.release(); await bounded(stopped); await bounded(f.settled);
		expect(calls).toHaveLength(0);
		expect(await f.snapshot()).toMatchObject({ admissions: [{ state: "failed_known" }], claims: [{ claimed: 1 }] });
	});
});

for (const response of ["truncated", `${JSON.stringify(frames[1])}\n{}\n`, "x".repeat(131073)])
	it("malformed upstream outcomes retain uncertain admission without redispatch", async () => {
		upstream(200, response);
		await gate("unknown-upstream", async (f) => {
			await f.start(); await bounded(f.settled); await f.host.yield();
			expect(await f.snapshot()).toMatchObject({ calls: 1, windows: [{ consumedRequests: 1 }], admissions: [{ state: "outcome_unknown" }], claims: [{ claimed: 1 }] });
		});
	});
