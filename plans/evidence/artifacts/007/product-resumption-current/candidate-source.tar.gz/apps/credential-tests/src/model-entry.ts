import { WorkerEntrypoint } from "cloudflare:workers";
import type { ModelTransportDescriptorV1 } from "../../../packages/runtime-contracts/src/model.js";
import type { ModelClaimRpc } from "../../web/src/lib/model-product-authority";
import {
	type ModelProductBindings,
	performPrivateModelRequest,
	readPrivateModelPermit,
} from "../../web/src/lib/model-product-transport";

export { PiDurableHostFixture } from "../../runtime/src/pi-durable-host.ts";
export { CodexCredential, FixtureCredential } from "./entry";

export class FixtureProduct extends WorkerEntrypoint<ModelProductBindings> {
	requestModel(input: unknown, capability: ModelClaimRpc) {
		return performPrivateModelRequest(this.env, input, capability, true);
	}
	readModelPermit(input: unknown, descriptor: ModelTransportDescriptorV1) {
		return readPrivateModelPermit(this.env.DB, input, descriptor, true);
	}
	fetch() {
		return new Response("Not found", { status: 404 });
	}
}
export default FixtureProduct;
