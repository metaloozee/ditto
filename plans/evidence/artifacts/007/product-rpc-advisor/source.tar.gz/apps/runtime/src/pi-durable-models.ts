import { RpcTarget } from "cloudflare:workers";
import { parseModelAttemptV1 } from "../../../packages/runtime-contracts/src/model.js";
import type { ModelDispatch } from "./pi-durable-host.ts";

export type OwnedModelRequest = {
	userId: string;
	projectId: string;
	workspaceSessionId: string;
	requestDigest: string;
};

/** Only deployment-owned runtime composition creates this live RPC target. */
export class ExactModelClaim extends RpcTarget {
	#dispatch: ModelDispatch;
	#owned: Readonly<OwnedModelRequest>;
	#used = false;

	constructor(dispatch: ModelDispatch, owned: OwnedModelRequest) {
		super();
		if (
			!Object.values(owned).every(
				(value) =>
					typeof value === "string" && value.length > 0 && value.length <= 512,
			) ||
			!/^[a-f0-9]{64}$/.test(owned.requestDigest)
		)
			throw new Error("Invalid owned model request");
		this.#dispatch = dispatch;
		this.#owned = Object.freeze({ ...owned });
	}

	async claim(
		attempt: unknown,
		owned: unknown,
	): Promise<{ status: "admitted" | "denied" }> {
		try {
			const parsed = parseModelAttemptV1(attempt);
			if (
				!owned ||
				typeof owned !== "object" ||
				Array.isArray(owned) ||
				Object.keys(owned).length !== 4 ||
				Object.entries(this.#owned).some(
					([key, value]) =>
						!Object.hasOwn(owned, key) || Reflect.get(owned, key) !== value,
				) ||
				JSON.stringify(parsed) !== JSON.stringify(this.#dispatch.attempt) ||
				this.#used
			)
				return { status: "denied" };
			this.#used = true;
			await this.#dispatch.claim(parsed);
			return { status: "admitted" };
		} catch {
			return { status: "denied" };
		}
	}
}
