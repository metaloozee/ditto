import {
	ContractParseError,
	decodeContractInput,
	integerField,
	literalField,
	strictRecord,
	stringField,
} from "./json.js";

export type ModelAttemptV1 = {
	version: 1;
	effectId: string;
	operationId: string;
	runId: string;
	commandId: string;
	assistantId: string;
	taskId: number;
	epoch: number;
	attempt: number;
	generation: number;
	deadlineAt: number;
	requestDigest: string;
	kind: "generation" | "custom_summary";
};

export function parseModelAttemptV1(input: unknown): ModelAttemptV1 {
	const row = strictRecord(
		decodeContractInput(input, 4096),
		[
			"version",
			"effectId",
			"operationId",
			"runId",
			"commandId",
			"assistantId",
			"taskId",
			"epoch",
			"attempt",
			"generation",
			"deadlineAt",
			"requestDigest",
			"kind",
		],
		"model attempt",
	);
	const id = (key: string) => stringField(row, key, { maxBytes: 512 });
	const positive = (key: string) => integerField(row, key, { minimum: 1 });
	const digest = stringField(row, "requestDigest", { maxBytes: 64 });
	if (!/^[a-f0-9]{64}$/.test(digest))
		throw new ContractParseError("invalid_digest", "Invalid request digest.");
	return {
		version: literalField(row, "version", [1]),
		effectId: id("effectId"),
		operationId: id("operationId"),
		runId: id("runId"),
		commandId: id("commandId"),
		assistantId: id("assistantId"),
		taskId: positive("taskId"),
		epoch: positive("epoch"),
		attempt: positive("attempt"),
		generation: positive("generation"),
		deadlineAt: positive("deadlineAt"),
		requestDigest: digest,
		kind: literalField(row, "kind", ["generation", "custom_summary"]),
	};
}
