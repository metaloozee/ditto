import { env, runInDurableObject } from "cloudflare:test";
import { awaitWithContext, BACKGROUND_CONTEXT } from "@earendil-works/chord/context";
import { fauxAssistantMessage, fauxToolCall } from "@earendil-works/pi-ai/providers/faux";
import type { AssistantMessage } from "@earendil-works/pi-ai";
import type { Harness, Storage } from "@earendil-works/pi-durable";
import { expect, it } from "vitest";
import { cooperativeFixture, pendingRemote } from "./pi-durable-cooperative-fixture.ts";
import { PiDurableHost, type HostFixtureDependencies, type HostGuard, type ModelRequest } from "./pi-durable-host.ts";
import { openHostField } from "./host-private.ts";
import { importRuntimeKeyringFromBytes } from "./runtime-crypto.ts";
import { preparedSummary, summaryText } from "./pi-durable-summary.ts";

async function until(predicate: () => boolean | Promise<boolean>) {
	for (let n = 0; n < 200; n++) {
		if (await predicate()) return;
		await new Promise((resolve) => setTimeout(resolve, 5));
	}
	throw new Error("Custom summary observation deadline");
}
async function gate(name: string, encrypted: boolean, use: (f: Awaited<ReturnType<typeof fixture>>, state: DurableObjectState) => Promise<void>) {
	await runInDurableObject(env.PI_HOST_STORAGE.getByName(`007-custom-${name}-${encrypted}`), async (_instance, state) => {
		const f = await fixture(state.storage, encrypted);
		try { await f.open(); await use(f, state); }
		finally { f.prepare?.resolve(); f.returning?.resolve(); for (const remote of f.fixtures) remote.remote.resolve(); await f.host.yield(); await state.storage.deleteAlarm(); }
	});
}
async function fixture(storage: DurableObjectStorage, encrypted: boolean) {
	const retained = encrypted ? { ownerId: "007-synthetic-owner", workspaceSessionId: "007-synthetic-workspace", keyring: await importRuntimeKeyringFromBytes("v1", { v1: new Uint8Array(32).fill(17) }) } : undefined;
	let host!: PiDurableHost, current = true, automatic = false;
	let prepare: ReturnType<typeof pendingRemote<void>> | undefined, returning: ReturnType<typeof pendingRemote<void>> | undefined;
	let result: AssistantMessage | undefined, storageFault: "preparation-write" | "preparation-flush" | "result" | undefined;
	let mutate: ((guard: HostGuard) => HostGuard) | undefined;
	let piStorage: HostFixtureDependencies["piStorage"];
	const requests: ModelRequest[] = [], fixtures: ReturnType<typeof cooperativeFixture>[] = [];
	const dependencies: HostFixtureDependencies = {
		now: () => Date.now() + 60_000, retained,
		authority: async () => ({ current, generation: 1, executor: 1 }), budgets: { workMs: 10_000, drainMs: 1000 },
		wakeup: { getAlarm: async () => null, setAlarm: async () => {} },
		fault: (point) => { if (point === storageFault) throw new Error(`Synthetic custom storage ${point}`); },
		prepareModel: async () => { if (prepare) await prepare.promise; },
		piStorage: (storage) => piStorage?.(storage) ?? storage,
		options: (guard) => {
			const adapter: HostGuard = {
				...guard,
				model: (request, context, start) => guard.model(request, context, () => {
					requests.push({ ...request, options: Object.fromEntries(Object.entries(request.options).filter(([key]) => key !== "signal")) });
					return request.options.maxTokens !== undefined && result ? Promise.resolve(result) : start();
				}),
				result: async (id, context, evidence) => {
					await guard.result(id, context, evidence);
					if (id.startsWith("ditto-summary-1/") && returning) await awaitWithContext(returning.promise, context);
				},
			};
			const f = cooperativeFixture("answer", guard.admit, adapter.result, mutate?.(adapter) ?? adapter);
			fixtures.push(f);
			return { models: f.models, registry: f.registry, settings: { extensions: [f.extension], retry: { enabled: true, maxRetries: 3 }, stream: { maxRetries: 4 }, compaction: { get enabled() { return automatic; }, reserveTokens: 64, keepRecentTokens: 1, backgroundTokens: 0 } } };
		},
	};
	return {
		fixtures, requests, dependencies,
		get host() { return host; }, get harness() { return Reflect.get(host, "harness") as Harness; },
		get prepare() { return prepare; }, set prepare(value: typeof prepare) { prepare = value; },
		get returning() { return returning; }, set returning(value: typeof returning) { returning = value; },
		set result(value: typeof result) { result = value; }, set current(value: boolean) { current = value; },
		set automatic(value: boolean) { automatic = value; }, set mutate(value: typeof mutate) { mutate = value; },
		set piStorage(value: typeof piStorage) { piStorage = value; }, set fault(value: typeof storageFault) { storageFault = value; },
		get providerCalls() { return fixtures.reduce((n, f) => n + f.providerCalls, 0); },
		async open() { host = await PiDurableHost.open(storage, dependencies); },
		async start() { await host.accept("initial", "Synthetic summary context ".repeat(40)); await host.schedule("initial"); await this.harness.waitForIdle(BACKGROUND_CONTEXT); },
		async follow() { await host.accept("follow", "Synthetic next instruction", { run: "initial", user: "follow-user", assistant: "follow-assistant", sequence: 2 }); await host.schedule("follow"); },
		async effects() {
			const rows = storage.sql.exec<{ id: string; state: string; attempt: number; correlation: string; evidence: string | null }>("SELECT id,state,attempt,correlation,evidence FROM host_effects ORDER BY rowid").toArray();
			return Promise.all(rows.map(async (row) => ({ ...row, correlation: JSON.parse(retained ? await openHostField(retained, `effect:${row.id}:correlation`, row.correlation) : row.correlation), evidence: row.evidence ? JSON.parse(retained ? await openHostField(retained, `effect:${row.id}:evidence`, row.evidence) : row.evidence) : null })));
		},
	};
}
for (const encrypted of [false, true]) {
	for (const automatic of [false, true]) it(`custom summary places a real ${automatic ? "automatic" : "manual"} Pi receipt, encrypted=${encrypted}`, async () => gate(`placement-${automatic}`, encrypted, async (f) => {
		await f.start(); f.automatic = automatic;
		if (automatic) { await f.follow(); await f.harness.waitForIdle(BACKGROUND_CONTEXT); }
		else { const task = await f.host.compact("initial"); await f.harness.waitForTask(task, BACKGROUND_CONTEXT); }
		await f.host.reconcile();
		const summaries = (await f.effects()).filter((row) => row.correlation.version === 2);
		expect(summaries).toHaveLength(1); expect(summaries[0]).toMatchObject({ attempt: 1, state: "pi-committed", correlation: { replay: "never", piAttempt: 1 } });
		const request = f.requests.find((request) => request.options.maxTokens !== undefined)!;
		expect(request.options).toMatchObject({ maxRetries: 0, cacheRetention: "none", maxTokens: 1024 });
		expect(request.transcript).toMatchObject({ messages: [{ role: "system", content: expect.stringContaining("Ditto summary policy 1") }, { role: "user", content: expect.stringContaining("Synthetic summary context") }] });
		expect((await f.host.history()).items.filter((entry) => entry.kind === "pi.compaction")).toHaveLength(1);
		const calls = f.providerCalls; await f.host.yield(); await f.open(); await f.host.reconcile(); expect(f.providerCalls).toBe(calls);
	}));
	it(`recorded success survives close before hook return and is accounted once, encrypted=${encrypted}`, async () => gate("success-reuse", encrypted, async (f, state) => {
		await f.start(); f.returning = pendingRemote<void>();
		const task = await f.host.compact("initial");
		await until(async () => (await f.effects()).some((row) => row.correlation.version === 2 && row.state === "result-recorded"));
		const original = (await f.effects()).find((row) => row.correlation.version === 2)!;
		expect((await f.host.task(task))?.state.checkpoint).toEqual({ phase: "select" });
		await f.host.yield(); f.returning = undefined; await f.open();
		await expect(f.host.admit("tool", "replay-defense", BACKGROUND_CONTEXT)).rejects.toThrow();
		await f.host.schedule("initial"); await f.harness.waitForTask(task, BACKGROUND_CONTEXT); await f.host.reconcile();
		expect(f.providerCalls).toBe(2);
		const summaries = (await f.effects()).filter((row) => row.correlation.version === 2);
		expect(summaries).toHaveLength(1); expect(summaries[0]).toMatchObject({ id: original.id, evidence: original.evidence, state: "pi-committed" });
		await f.host.reconcile(); await f.host.yield(); await f.open(); await f.host.reconcile(); expect(f.providerCalls).toBe(2);
		expect((await f.effects()).filter((row) => row.correlation.version === 2).map((row) => row.evidence.usage)).toEqual([original.evidence.usage]);
		if (encrypted) { const raw = JSON.stringify(state.storage.sql.exec("SELECT * FROM host_effects").toArray()); expect(raw).not.toContain("Synthetic durable summary"); expect(raw).toContain("aes-256-gcm"); }
	}));
	it(`unknown admitted custom summary blocks two reopens without a second attempt, encrypted=${encrypted}`, async () => gate("unknown", encrypted, async (f) => {
		await f.start(); f.fixtures.at(-1)!.summary = "pending"; await f.host.compact("initial"); await f.fixtures.at(-1)!.entered.promise;
		const original = (await f.effects()).find((row) => row.correlation.version === 2)!;
		for (let n = 0; n < 2; n++) { await f.host.yield(); await f.open(); await expect(f.host.schedule("initial")).rejects.toThrow(); await expect(f.host.admit("tool", `blocked-${n}`, BACKGROUND_CONTEXT)).rejects.toThrow(); f.harness.resume(); await f.harness.waitForIdle(BACKGROUND_CONTEXT); expect(f.providerCalls).toBe(2); expect((await f.effects()).find((row) => row.id === original.id)).toEqual(original); }
	}));
	for (const fault of ["preparation-write", "preparation-flush", "result"] as const) it(`custom ${fault} persistence failure fences every later effect, encrypted=${encrypted}`, async () => gate(`fault-${fault}`, encrypted, async (f) => {
		await f.start(); f.fault = fault; const task = await f.host.compact("initial"); await f.harness.waitForTask(task, BACKGROUND_CONTEXT);
		expect(f.providerCalls).toBe(fault === "result" ? 2 : 1); await expect(f.host.admit("model", "later", BACKGROUND_CONTEXT)).rejects.toThrow(); f.fault = undefined;
		await f.host.yield(); await f.open(); await expect(f.host.schedule("initial")).rejects.toThrow();
	}));
}
for (const result of [
	fauxAssistantMessage([], { stopReason: "error", errorMessage: "503 Synthetic summary failure" }),
	fauxAssistantMessage([], { stopReason: "aborted" }),
	fauxAssistantMessage(""),
	fauxAssistantMessage(fauxToolCall("forbidden", {}), { stopReason: "toolUse" }),
	fauxAssistantMessage("x".repeat(5000)),
]) it(`known custom failure ${result.stopReason}/${result.content.length} settles the run with one nonrefundable attempt`, async () => gate(`failed-${result.stopReason}-${JSON.stringify(result.content).length}`, false, async (f, state) => {
	await f.start(); await f.host.accept("follow", "Synthetic pending follow-up", { run: "initial", user: "follow-user", assistant: "follow-assistant", sequence: 2 }); f.result = result;
	const task = await f.host.compact("initial"); await f.harness.waitForTask(task, BACKGROUND_CONTEXT); await f.host.reconcile();
	expect(state.storage.sql.exec("SELECT state FROM host_runs WHERE id='initial'").one().state).toBe("failed");
	expect(state.storage.sql.exec("SELECT state FROM host_members WHERE assistant='follow-assistant'").one().state).toBe("failed");
	expect((await f.effects()).filter((row) => row.correlation.version === 2)).toHaveLength(1); expect(f.requests.filter((request) => request.options.maxTokens !== undefined)).toHaveLength(1);
	await expect(f.host.schedule("follow")).rejects.toThrow(); expect((await f.host.history()).items.filter((entry) => entry.kind === "pi.compaction")).toHaveLength(0);
	await f.host.yield(); await f.open(); await expect(f.host.schedule("initial")).rejects.toThrow(); expect(f.providerCalls).toBe(1);
}));
for (const denial of ["range", "policy", "epoch", "authority", "stop"] as const) it(`custom summary ${denial} after preparation dispatches nothing`, async () => gate(`denial-${denial}`, false, async (f, state) => {
	await f.start(); f.prepare = pendingRemote<void>(); const task = await f.host.compact("initial");
	await until(() => state.storage.sql.exec("SELECT prepared FROM host_tasks WHERE task = ?", Number(task)).one().prepared !== null);
	if (denial === "range") state.storage.sql.exec("UPDATE host_tasks SET selection = '{}' WHERE task = ?", Number(task));
	if (denial === "policy") { const row = state.storage.sql.exec<{ prepared: string }>("SELECT prepared FROM host_tasks WHERE task=?", Number(task)).one(); const prepared = JSON.parse(row.prepared); prepared.policy = "unsupported"; state.storage.sql.exec("UPDATE host_tasks SET prepared=? WHERE task=?", JSON.stringify(prepared), Number(task)); }
	if (denial === "epoch") state.storage.sql.exec("UPDATE host_runs SET epoch=epoch+1 WHERE id='initial'");
	if (denial === "authority") f.current = false;
	if (denial === "stop") await f.host.stop("stop", "initial");
	f.prepare.resolve(); await f.harness.waitForTask(task, BACKGROUND_CONTEXT); expect(f.providerCalls).toBe(1); expect((await f.effects()).filter((row) => row.correlation.version === 2)).toHaveLength(0);
}));
it("policy parser rejects old/custom meanings and malformed usage", () => {
	expect(() => preparedSummary({ policy: "ditto-summary-0" })).toThrow();
	expect(() => summaryText({ ...fauxAssistantMessage("summary"), usage: {} })).toThrow();
});
