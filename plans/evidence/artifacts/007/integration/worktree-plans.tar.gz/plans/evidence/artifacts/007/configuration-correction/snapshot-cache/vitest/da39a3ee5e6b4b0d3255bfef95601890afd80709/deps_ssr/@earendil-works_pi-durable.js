import {
  ArrayOptions,
  Clone,
  Evaluate,
  Flatten,
  Get,
  Instantiate,
  Intersect,
  IsArray,
  IsBigInt,
  IsBoolean,
  IsCodec,
  IsConstructor,
  IsCyclic,
  IsEnum,
  IsFunction,
  IsInteger,
  IsIntersect,
  IsLiteral,
  IsLiteralBigInt,
  IsLiteralBoolean,
  IsLiteralNumber,
  IsLiteralString,
  IsNever,
  IsNull,
  IsNumber,
  IsObject,
  IsOptional,
  IsRecord,
  IsRef,
  IsRefine,
  IsSchema,
  IsString,
  IsSymbol,
  IsTemplateLiteral,
  IsTuple,
  IsUndefined,
  IsUnion,
  IsVoid,
  Literal,
  Priority,
  Record,
  RecordKey,
  RecordPattern,
  RecordValue,
  Ref,
  String as String2,
  TemplateLiteralDecode,
  Tuple,
  Union,
  Unknown,
  Unreachable,
  With,
  _Array_,
  _Object_,
  arguments_exports,
  emit_exports,
  environment_exports,
  globals_exports,
  guard_default,
  guard_exports,
  hash_exports,
  settings_exports
} from "./chunk-SSUJQZQA.js";
import {
  ConversationBusy,
  ReadAfterWrite,
  StorageRejected,
  idFromNumber,
  seqFromNumber
} from "./chunk-XWH7TXR6.js";
import {
  declarationsEqual,
  getCurrentTools,
  getSystemMessageText,
  toToolDeclaration
} from "./chunk-47T7GGRX.js";
import {
  applyImmutable,
  applyImmutableBatches,
  copyJson,
  overlap,
  track
} from "./chunk-EOP7IIM4.js";
import {
  BACKGROUND_CONTEXT,
  awaitWithContext,
  withAbortSignal,
  withoutAbortSignal
} from "./chunk-E62EHYRK.js";
import {
  __export
} from "./chunk-PZ5AY32C.js";

// ../../node_modules/.pnpm/@earendil-works+chord@1.0.1/node_modules/@earendil-works/chord/dist/services/handle.js
var _a;
var ValueView = class {
  #resolve;
  #children = /* @__PURE__ */ new Map();
  proxy;
  constructor(resolve, callable) {
    this.#resolve = resolve;
    const target = callable ? () => void 0 : /* @__PURE__ */ Object.create(null);
    this.proxy = new Proxy(target, {
      apply: (_target, _thisArg, args) => this.#invoke(args),
      get: (_target, property) => this.#get(property)
    });
  }
  #invoke(args) {
    const { value, receiver } = this.#resolve();
    if (typeof value !== "function")
      throw new TypeError("Service member is not callable");
    return Reflect.apply(value, receiver, args);
  }
  #get(property) {
    const resolve = () => {
      const parent = this.#resolve();
      if (!isObject(parent.value))
        throw new TypeError("Service member does not have properties");
      return {
        value: Reflect.get(parent.value, property, parent.value),
        receiver: parent.value
      };
    };
    const current = resolve().value;
    if (typeof current !== "function")
      return current;
    let child = this.#children.get(property);
    if (child === void 0) {
      child = new _a(resolve, true);
      this.#children.set(property, child);
    }
    return child.proxy;
  }
};
_a = ValueView;
function isObject(value) {
  return typeof value === "object" && value !== null || typeof value === "function";
}

// ../../node_modules/.pnpm/@earendil-works+chord@1.0.1/node_modules/@earendil-works/chord/dist/services/state-internals.js
var sources = /* @__PURE__ */ new WeakMap();
function registerReplicatedStateInternals(value, internals) {
  sources.set(value, internals);
}

// ../../node_modules/.pnpm/@earendil-works+chord@1.0.1/node_modules/@earendil-works/chord/dist/services/state.js
var StateSubscriber = class {
  #listener;
  #reportError;
  #pending = [];
  #running = false;
  #started = false;
  #closed = false;
  constructor(listener, reportError) {
    this.#listener = listener;
    this.#reportError = reportError;
  }
  push(frame) {
    if (this.#closed)
      return;
    if (this.#pending.length === 100) {
      const hydration = this.#started ? void 0 : this.#pending[0];
      this.#pending.length = 0;
      if (hydration !== void 0)
        this.#pending.push(hydration);
    }
    this.#pending.push(frame);
  }
  drain() {
    if (this.#running || this.#closed)
      return;
    this.#running = true;
    for (let frame = this.#pending.shift(); frame !== void 0; frame = this.#pending.shift()) {
      this.#started = true;
      try {
        const result = this.#listener(frame.value, frame.context, frame.delivery);
        if (isPromiseLike(result)) {
          void Promise.resolve(result).then(() => this.#resume(), (error) => {
            this.#report(error);
            this.#resume();
          });
          return;
        }
      } catch (error) {
        this.#report(error);
      }
    }
    this.#running = false;
  }
  clear() {
    this.#pending.length = 0;
  }
  close() {
    this.#closed = true;
    this.clear();
  }
  #resume() {
    this.#running = false;
    this.drain();
  }
  #report(error) {
    try {
      this.#reportError(toError(error));
    } catch (reportError) {
      reportErrorAsync(toError(reportError));
    }
  }
};
var ReplicatedStatePublisher = class {
  #listeners = /* @__PURE__ */ new Map();
  #reportError;
  #sourceListeners = /* @__PURE__ */ new Set();
  #publications = [];
  #value;
  #sequence = 0;
  #delivering = false;
  constructor(initial, reportError = reportErrorAsync) {
    this.#value = initial;
    this.#reportError = reportError;
  }
  get value() {
    return this.#value;
  }
  snapshot() {
    return { value: this.#value, sequence: this.#sequence };
  }
  subscribe(listener) {
    const { value, sequence } = this.snapshot();
    const subscriber = new StateSubscriber(listener, this.#reportError);
    this.#listeners.set(subscriber, sequence);
    subscriber.push({ value, context: serviceDeliveryContext(), delivery: { kind: "hydrate", sequence } });
    subscriber.drain();
    return () => {
      subscriber.close();
      this.#listeners.delete(subscriber);
    };
  }
  subscribeSource(listener) {
    this.#sourceListeners.add(listener);
    return () => this.#sourceListeners.delete(listener);
  }
  /** Publish an already-prepared immutable revision and return isolated listener failures. */
  publish(value, ops, context) {
    this.#value = value;
    this.#sequence += 1;
    this.#publications.push({ value, ops, sequence: this.#sequence, context });
    if (this.#delivering)
      return [];
    this.#delivering = true;
    const errors = [];
    try {
      for (let publication = this.#publications.shift(); publication !== void 0; publication = this.#publications.shift()) {
        for (const listener of [...this.#sourceListeners]) {
          try {
            listener(publication.ops, publication.sequence, publication.context);
          } catch (error) {
            errors.push(error);
          }
        }
        const delivery = { kind: "update", sequence: publication.sequence };
        for (const [subscriber, hydratedSequence] of [...this.#listeners]) {
          if (publication.sequence <= hydratedSequence)
            continue;
          subscriber.push({ value: publication.value, context: publication.context, delivery });
          subscriber.drain();
        }
      }
    } finally {
      this.#delivering = false;
    }
    return errors;
  }
};
var MutableReplicatedStateImpl = class {
  #tracker;
  #publisher;
  #changing = false;
  constructor(initial) {
    this.#tracker = track(initial);
    this.#publisher = new ReplicatedStatePublisher(this.#tracker.value);
    registerReplicatedStateInternals(this, {
      snapshot: () => this.#publisher.snapshot(),
      subscribe: (listener) => this.#publisher.subscribeSource(listener)
    });
  }
  get value() {
    return this.#tracker.value;
  }
  change(context, mutate) {
    if (this.#changing)
      throw new Error("Replicated state cannot be changed reentrantly from a change callback");
    this.#changing = true;
    let prepared;
    try {
      const change = this.#tracker.beginChange();
      try {
        const outcome = mutate(change.state);
        if (isPromiseLike(outcome)) {
          void Promise.resolve(outcome).catch(() => void 0);
          throw new TypeError("Replicated state change callbacks must be synchronous");
        }
        prepared = change.prepare();
      } catch (error) {
        change.abort();
        throw error;
      }
    } finally {
      this.#changing = false;
    }
    this.#tracker.adopt(prepared);
    if (prepared.ops.length === 0)
      return;
    throwCollectedErrors(this.#publisher.publish(prepared.value, prepared.ops, context), "Replicated state listeners failed");
  }
  replace(context, value) {
    if (this.#changing)
      throw new Error("Replicated state cannot be replaced from a change callback");
    const prepared = this.#tracker.prepareReplace(value);
    this.#tracker.adopt(prepared);
    if (prepared.ops.length === 0)
      return;
    throwCollectedErrors(this.#publisher.publish(prepared.value, prepared.ops, context), "Replicated state listeners failed");
  }
  subscribe(listener) {
    return this.#publisher.subscribe(listener);
  }
};
var AttachedReplicatedStateImpl = class {
  #publisher;
  #attachment;
  #reportError;
  #cursor;
  #disposed = false;
  constructor(attachment, options) {
    const { snapshot } = attachment;
    assertCursor(snapshot.cursor, "snapshot");
    this.#attachment = attachment;
    this.#cursor = snapshot.cursor;
    this.#reportError = options.onError ?? reportErrorAsync;
    this.#publisher = new ReplicatedStatePublisher(snapshot.value, (error) => this.#report(error));
    registerReplicatedStateInternals(this, {
      snapshot: () => this.#publisher.snapshot(),
      subscribe: (listener) => this.#publisher.subscribeSource(listener)
    });
  }
  get value() {
    return this.#publisher.value;
  }
  subscribe(listener) {
    return this.#publisher.subscribe(listener);
  }
  activate() {
    this.#attachment.activate((frame) => this.#receive(frame));
  }
  dispose() {
    if (this.#disposed)
      return;
    this.#disposed = true;
    this.#attachment.dispose();
  }
  #receive(frame) {
    if (this.#disposed)
      return;
    try {
      assertCursor(frame.cursor, "frame");
      const expected = this.#cursor + 1;
      if (frame.cursor !== expected) {
        throw new Error(`Replicated state source cursor has a gap: expected ${expected}, received ${frame.cursor}`);
      }
      this.#cursor = frame.cursor;
      const errors = this.#publisher.publish(frame.value, frame.ops, frame.context);
      if (errors.length === 1)
        this.#report(errors[0]);
      else if (errors.length > 1)
        this.#report(new AggregateError(errors, "Replicated state listeners failed"));
    } catch (error) {
      this.#fail(toError(error));
    }
  }
  #fail(error) {
    if (this.#disposed)
      return;
    this.#disposed = true;
    try {
      this.#attachment.dispose();
    } catch (disposeError) {
      this.#report(new AggregateError([error, disposeError], "Replicated state source contract failed"));
      return;
    }
    this.#report(error);
  }
  #report(error) {
    try {
      this.#reportError(toError(error));
    } catch (reportError) {
      reportErrorAsync(toError(reportError));
    }
  }
};
function attachReplicatedStateSource(source, options = {}) {
  const attachment = source.attach();
  try {
    const state2 = new AttachedReplicatedStateImpl(attachment, options);
    state2.activate();
    return state2;
  } catch (error) {
    try {
      attachment.dispose();
    } catch (disposeError) {
      throw new AggregateError([error, disposeError], "Failed to attach replicated state source");
    }
    throw error;
  }
}
function serviceDeliveryContext() {
  return BACKGROUND_CONTEXT;
}
function assertCursor(cursor, kind) {
  if (!Number.isSafeInteger(cursor))
    throw new TypeError(`Replicated state source ${kind} cursor must be a safe integer`);
}
function isPromiseLike(value) {
  return (typeof value === "object" && value !== null || typeof value === "function") && typeof value.then === "function";
}
function throwCollectedErrors(errors, message) {
  if (errors.length === 1)
    throw errors[0];
  if (errors.length > 1)
    throw new AggregateError(errors, message);
}
function reportErrorAsync(error) {
  queueMicrotask(() => {
    throw error;
  });
}
function toError(error) {
  return error instanceof Error ? error : new Error(String(error));
}

// ../../node_modules/.pnpm/@earendil-works+chord@1.0.1/node_modules/@earendil-works/chord/dist/api.js
function replicatedState(initialOrSource, options) {
  if (isReplicatedStateSource(initialOrSource))
    return attachReplicatedStateSource(initialOrSource, options);
  return new MutableReplicatedStateImpl(initialOrSource);
}
function isReplicatedStateSource(value) {
  return typeof value.attach === "function";
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/documents.js
function defineDoc(definition) {
  validateDefinition(definition);
  return { definition };
}
function defineDocFamily(definition) {
  validateDefinition(definition);
  return { definition };
}
function validateDefinition(definition) {
  if (!Number.isSafeInteger(definition.version) || definition.version < 1) {
    throw new TypeError(`Document ${definition.kind} version must be a positive integer`);
  }
}
function resolveAddress(definition, args) {
  let index3 = 0;
  let scope;
  switch (definition.scope) {
    case "session":
      scope = { kind: "session" };
      break;
    case "conversation":
      scope = { kind: "conversation", conversationId: ownerId(args[index3++], definition) };
      break;
    case "task":
      scope = { kind: "task", taskId: ownerId(args[index3++], definition) };
      break;
  }
  const key = definition.family === true ? args[index3++] : void 0;
  const address = key === void 0 ? { kind: definition.kind, scope } : { kind: definition.kind, scope, key };
  return { address, id: addressId(address), nextArgument: index3 };
}
function ownerId(value, definition) {
  if (typeof value !== "number" || !Number.isSafeInteger(value)) {
    throw new TypeError(`Document ${definition.kind} requires a ${definition.scope} ID`);
  }
  return idFromNumber(value);
}
function addressId(address) {
  const owner = address.scope.kind === "session" ? null : address.scope.kind === "conversation" ? address.scope.conversationId : address.scope.taskId;
  return JSON.stringify([address.kind, address.scope.kind, owner, address.key ?? null]);
}
function documentCreate(definition, address, id) {
  const key = address.key === void 0 ? {} : { key: address.key };
  switch (address.scope.kind) {
    case "session":
      return { id, kind: address.kind, ...key, scope: address.scope };
    case "task":
      return { id, kind: address.kind, ...key, scope: address.scope };
    case "conversation":
      return {
        id,
        kind: address.kind,
        ...key,
        scope: address.scope,
        history: definition.history,
        fork: definition.fork
      };
  }
}
function checkRecordScope(definition, record) {
  if (record.scope.kind !== definition.scope || record.scope.kind === "conversation" && (record.history !== definition.history || record.fork !== definition.fork)) {
    throw new TypeError(`Document ${record.id} (${record.kind}) does not match the supplied definition semantics`);
  }
}
function checkRecordVersion(definition, record, version) {
  if (version > definition.version) {
    throw new Error(`Document ${record.id} (${record.kind}) has newer version ${version} than ${definition.version}`);
  }
  if (version < definition.version && definition.migrate === void 0) {
    throw new Error(`Document ${record.id} (${record.kind}) requires migration from version ${version}`);
  }
}
function materializeDocument(definition, stored) {
  return materializeDocumentValue(definition, stored.record, stored.version, stored.value);
}
function materializeDocumentValue(definition, record, version, value) {
  checkRecordScope(definition, record);
  checkRecordVersion(definition, record, version);
  if (version === definition.version)
    return value;
  return copyJson(definition.migrate(value, version));
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/entries.js
function defineEntry(kind) {
  if (typeof kind !== "string" || kind.length === 0)
    throw new TypeError("Entry kind must be a non-empty string");
  return {
    kind,
    is: (entry) => entry !== void 0 && entry.kind === kind
  };
}
var UserEntry = defineEntry("pi.user");
var AssistantEntry = defineEntry("pi.assistant");
var SystemEntry = defineEntry("pi.system");
var ToolResultEntry = defineEntry("pi.tool-result");
var ResetEntry = defineEntry("pi.reset");
var CompactionEntry = defineEntry("pi.compaction");

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/agent.js
var DEFAULT_RETRY_POLICY = {
  enabled: true,
  maxRetries: 3,
  baseDelayMs: 2e3,
  maxAgentDelayMs: 6e4
};
var DEFAULT_COMPACTION_POLICY = {
  enabled: true,
  reserveTokens: 16384,
  keepRecentTokens: 2e4,
  backgroundTokens: 32768
};
var INSTRUCTIONS_KEY = "instructions";
var AgentDoc = defineDoc({
  kind: "pi.agent",
  version: 1,
  scope: "conversation",
  history: "rewindable",
  fork: "asOf",
  initial: () => ({}),
  checkpointWhen: () => true
});
function resolveSettings(settings) {
  const extensions = settings?.extensions;
  return {
    ...extensions === void 0 ? {} : { extensions },
    stream: { ...settings?.stream },
    retry: { ...DEFAULT_RETRY_POLICY, ...settings?.retry },
    compaction: { ...DEFAULT_COMPACTION_POLICY, ...settings?.compaction },
    toolExecution: settings?.toolExecution ?? "parallel",
    steeringMode: settings?.steeringMode ?? "one-at-a-time",
    followUpMode: settings?.followUpMode ?? "one-at-a-time"
  };
}
async function configure(tx, conversationId, change) {
  const state2 = await tx.doc(AgentDoc, conversationId);
  applyChange(state2, change);
}
async function addTools(tx, conversationId, added) {
  const state2 = await tx.doc(AgentDoc, conversationId);
  const tools = state2.tools;
  if (tools === void 0)
    return;
  if (Array.isArray(tools)) {
    for (const name of added)
      if (!tools.includes(name))
        tools.push(name);
  } else {
    const remove = tools.remove;
    if (remove.some((name) => added.includes(name))) {
      state2.tools = { remove: remove.filter((name) => !added.includes(name)) };
    }
  }
}
function applyChange(state2, change) {
  const set = (key, value) => {
    if (value === void 0)
      return;
    if (value === null)
      delete state2[key];
    else
      state2[key] = value;
  };
  set("model", change.model === void 0 || change.model === null ? change.model : { ...change.model });
  set("thinkingLevel", change.thinkingLevel);
  const extensions = change.extensions;
  set("extensions", extensions === void 0 || extensions === null ? extensions : isList(extensions) ? names(extensions) : {
    ...extensions.add === void 0 ? {} : { add: names(extensions.add) },
    ...extensions.remove === void 0 ? {} : { remove: names(extensions.remove) }
  });
  const tools = change.tools;
  set("tools", tools === void 0 || tools === null ? tools : isList(tools) ? names(tools) : { remove: names(tools.remove) });
  set("instructions", change.instructions);
  set("cwd", change.cwd);
}
function isList(value) {
  return Array.isArray(value);
}
function names(items) {
  return items.map((item) => item.name);
}
async function createAgent(tx, conversation) {
  if (conversation.parent !== void 0)
    return;
  const agent = await tx.doc(AgentDoc, conversation.id);
  if (conversation.owner === void 0)
    return;
  const owner = await tx.doc(AgentDoc, conversation.owner.conversationId);
  Object.assign(agent, copyJson(owner));
}
function agentHooks(agent, taskName) {
  const handlers = [];
  for (const extension of agent.extensions) {
    for (const hook2 of extension.hooks ?? [])
      if (hook2.task === taskName)
        handlers.push(hook2.handlers);
  }
  return handlers;
}
function resolveAgent(state2, snapshot, settings, report) {
  const extensions = selectExtensions(state2?.extensions, snapshot, settings);
  const composed = /* @__PURE__ */ new Map();
  for (const extension of extensions)
    for (const tool of extension.tools ?? [])
      composed.set(tool.name, tool);
  const sections = /* @__PURE__ */ new Map();
  for (const extension of extensions) {
    for (const section2 of extension.sections ?? [])
      sections.set(section2.key, section2);
  }
  for (const extension of extensions) {
    for (const wrap of extension.wraps ?? []) {
      if ("tool" in wrap)
        applyWrap(composed, wrap.tool, (tool) => wrap.wrap(tool), (tool) => tool.name, report);
      else
        applyWrap(sections, wrap.section, (section2) => wrap.wrap(section2), (section2) => section2.key, report);
    }
  }
  const filter = state2?.tools;
  let tools;
  if (filter === void 0)
    tools = [...composed.values()];
  else if (Array.isArray(filter)) {
    tools = [];
    for (const name of new Set(filter)) {
      const tool = composed.get(name);
      if (tool !== void 0)
        tools.push(tool);
    }
  } else {
    const removed = new Set(filter.remove);
    tools = [...composed.values()].filter((tool) => !removed.has(tool.name));
  }
  const instructions = state2?.instructions;
  const agentSections = [...sections.values()];
  if (instructions !== void 0)
    agentSections.push({ key: INSTRUCTIONS_KEY, render: () => instructions });
  const agent = {
    ...state2?.model === void 0 ? {} : { model: state2.model },
    thinkingLevel: state2?.thinkingLevel ?? "off",
    extensions,
    tools,
    sections: agentSections,
    ...instructions === void 0 ? {} : { instructions },
    ...state2?.cwd === void 0 ? {} : { cwd: state2.cwd }
  };
  return agent;
}
function selectExtensions(stored, snapshot, settings) {
  let selected;
  if (Array.isArray(stored))
    selected = stored;
  else {
    const base = settings.extensions?.map((extension) => extension.name) ?? snapshot.installed().map((e) => e.name);
    const edit = stored;
    const removed = new Set(edit?.remove ?? []);
    selected = [...base, ...edit?.add ?? []].filter((name) => !removed.has(name));
  }
  const extensions = [];
  for (const name of new Set(selected)) {
    const extension = snapshot.extension(name);
    if (extension !== void 0)
      extensions.push(extension);
  }
  return extensions;
}
function applyWrap(items, target, wrap, nameOf, report) {
  const item = items.get(target);
  if (item === void 0)
    return;
  try {
    const wrapped = wrap(item);
    if (nameOf(wrapped) !== target)
      throw new Error(`Wrapper renamed ${target} to ${nameOf(wrapped)}`);
    items.set(target, wrapped);
  } catch (error) {
    items.delete(target);
    report(error);
  }
}

// ../../node_modules/.pnpm/@earendil-works+pi-ai@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelcontextpro_284929f414f75b7f77d6867259ed136d/node_modules/@earendil-works/pi-ai/dist/utils/estimate.js
var CHARS_PER_TOKEN = 4;
var ESTIMATED_IMAGE_CHARS = 4800;
function calculateContextTokens(usage) {
  return usage.totalTokens || usage.input + usage.output + usage.cacheRead + usage.cacheWrite;
}
function safeJsonStringify(value) {
  try {
    return JSON.stringify(value) ?? "undefined";
  } catch {
    return "[unserializable]";
  }
}
function estimateTextAndImageContentChars(content) {
  if (typeof content === "string")
    return content.length;
  let chars = 0;
  for (const block of content)
    chars += block.type === "text" ? block.text.length : ESTIMATED_IMAGE_CHARS;
  return chars;
}
function estimateTextTokens(text) {
  return Math.ceil(text.length / CHARS_PER_TOKEN);
}
function estimateTextAndImageContentTokens(content) {
  return Math.ceil(estimateTextAndImageContentChars(content) / CHARS_PER_TOKEN);
}
function estimateMessageTokens(message) {
  let chars = 0;
  if (message.role === "system") {
    return estimateTextTokens(getSystemMessageText(message)) + estimateToolsTokens(message.toolsAdded) + estimateToolsTokens(message.toolsRemoved);
  }
  if (message.role === "user")
    return estimateTextAndImageContentTokens(message.content);
  if (message.role === "toolResult")
    return estimateTextAndImageContentTokens(message.content);
  for (const block of message.content) {
    if (block.type === "text") {
      chars += block.text.length;
    } else if (block.type === "thinking") {
      chars += block.thinking.length;
    } else {
      chars += block.name.length + safeJsonStringify(block.arguments).length;
    }
  }
  return Math.ceil(chars / CHARS_PER_TOKEN);
}
function estimateToolsTokens(tools) {
  if (!tools || tools.length === 0)
    return 0;
  return estimateTextTokens(safeJsonStringify(tools));
}

// ../../node_modules/.pnpm/@earendil-works+pi-ai@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelcontextpro_284929f414f75b7f77d6867259ed136d/node_modules/@earendil-works/pi-ai/dist/utils/retry.js
function buildProviderErrorPattern(patterns) {
  return new RegExp(patterns.join("|"), "i");
}
var NON_RETRYABLE_PROVIDER_LIMIT_ERROR_PATTERN = buildProviderErrorPattern([
  // OpenCode Go/free-tier limits returned as 429 JSON error types by OpenCode's
  // Zen API. These are subscription/account limits, not transient throttles.
  "GoUsageLimitError",
  "FreeUsageLimitError",
  // OpenCode Go subscription-limit text asks users to enable available-balance
  // usage after rolling/weekly/monthly limits are reached.
  "Monthly usage limit reached",
  "available balance",
  // Generic quota/budget/billing exhaustion. `insufficient_quota` is OpenAI's
  // quota/billing error code; the other strings cover common gateway wording.
  "insufficient_quota",
  "out of budget",
  "quota exceeded",
  "billing",
  // Sign in with ChatGPT: the subscription's shared usage limit, which resets
  // after hours rather than seconds.
  "subscription_sharing_usage_limit_exceeded"
]);
var RETRYABLE_PROVIDER_ERROR_PATTERN = buildProviderErrorPattern([
  // Generic provider load, HTTP status, and server-side transient failures.
  "overloaded",
  "currently experiencing high demand",
  "model is at capacity",
  "rate.?limit",
  "too many requests",
  "429",
  "500",
  "502",
  "503",
  "504",
  "520",
  "524",
  "service.?unavailable",
  "server.?error",
  "internal.?error",
  // Wrapper/provider text for transient upstream failures, including OpenRouter
  // "Provider returned error" responses (#2264).
  "provider.?returned.?error",
  "exceeded request buffer limit while retrying upstream",
  // Network, proxy, and fetch transport failures. This includes OpenAI Codex
  // raw-fetch failures such as "upstream connect", "connection refused", and
  // "reset before headers" (#733), plus OpenRouter connection drops (#3317).
  "network.?error",
  "connection.?error",
  "connection.?refused",
  "connection.?lost",
  "other side closed",
  "fetch failed",
  "getaddrinfo",
  "ENOTFOUND",
  "EAI_AGAIN",
  "upstream.?connect",
  "reset before headers",
  "socket hang up",
  "socket connection was closed",
  "timed? out",
  "timeout",
  "terminated",
  // WebSocket transports can report close/error text instead of HTTP/fetch text.
  "websocket.?closed",
  "websocket.?error",
  // Premature stream endings from SDKs and transports. Anthropic can throw
  // "stream ended without ..." and "Anthropic stream ended before message_stop"
  // (#4433); Bedrock/Smithy can throw an HTTP/2 no-response error (#3594).
  "ended without",
  "stream ended before message_stop",
  "stream ended before a terminal response event",
  "http2 request did not get a response",
  // Provider-requested retry delay cap failures should flow through the outer
  // retry policy so callers can surface/abort the backoff (#1123).
  "retry delay",
  // Explicit retry guidance emitted mid-stream by OpenAI Responses and Bedrock
  // stream exceptions (#6019).
  "you can retry your request",
  "try your request again",
  "please retry your request",
  // gRPC based providers (e.g. NVIDIA NIM)
  "ResourceExhausted",
  // Sign in with ChatGPT: usage or user data temporarily unavailable. Usage
  // failures can arrive mid-stream without an HTTP 503 in the message.
  "subscription_sharing_usage_unavailable",
  "subscription_sharing_user_unavailable"
]);
var DEFAULT_MAX_AGENT_RETRY_DELAY_MS = 6e4;
function retryDelayMs(policy, attempt) {
  const delay2 = policy.baseDelayMs * 2 ** Math.max(0, attempt - 1);
  const safeDelay = Number.isSafeInteger(delay2) ? delay2 : Number.MAX_SAFE_INTEGER;
  return Math.min(safeDelay, policy.maxAgentDelayMs ?? DEFAULT_MAX_AGENT_RETRY_DELAY_MS);
}
function isRetryableAssistantError(message) {
  if (message.stopReason !== "error" || !message.errorMessage)
    return false;
  const errorMessage = message.errorMessage;
  if (NON_RETRYABLE_PROVIDER_LIMIT_ERROR_PATTERN.test(errorMessage))
    return false;
  return RETRYABLE_PROVIDER_ERROR_PATTERN.test(errorMessage);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/tasks.js
function defineTask(definition) {
  return { definition };
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/context.js
var SCAN_PAGE_SIZE = 256;
var EXCLUDED_STOP_REASONS = /* @__PURE__ */ new Set(["aborted", "error", "deferred"]);
var MISSING_RESULT_TEXT = "Tool result unavailable: history ends before this call completed.";
async function captureContextBounds(storage, conversationId, context, at) {
  let tail;
  if (at === void 0) {
    tail = (await storage.scanEntries({ conversationId }, 1, void 0, context)).items[0]?.id;
    if (tail === void 0)
      return void 0;
  } else {
    if (await storage.entry(conversationId, at, context) === void 0) {
      throw new Error(`Entry ${at} is not visible from conversation ${conversationId}`);
    }
    tail = at;
  }
  return { head: await storage.findLatestHeadMarker(conversationId, tail, context), tail };
}
async function readContext(session, storage, conversationId, context, at) {
  const bounds = await session.readOnLine(() => captureContextBounds(storage, conversationId, context, at));
  return deriveContext(storage, conversationId, bounds, context);
}
async function deriveContext(storage, conversationId, bounds, context) {
  if (bounds === void 0)
    return { head: void 0, entries: [], contributions: [], messages: [] };
  const head = bounds.head;
  const range = await scanRange(storage, conversationId, bounds, context);
  const edits = /* @__PURE__ */ new Map();
  for (const entry of range)
    for (const edit of entry.edits ?? [])
      edits.set(edit.target, edit);
  const entries = selectActive(head, range);
  const contributions = entries.map((entry) => {
    const edit = edits.get(entry.id);
    if (edit?.action === "omit")
      return [];
    const contributed = edit?.action === "replace" ? edit.messages : entry.model ?? [];
    return contributed.filter((message) => message.role !== "assistant" || !EXCLUDED_STOP_REASONS.has(message.stopReason));
  });
  return { head, entries, contributions, messages: orderToolResults(contributions.flat()) };
}
async function activeEntries(storage, conversationId, bounds, context) {
  if (bounds === void 0)
    return [];
  return selectActive(bounds.head, await scanRange(storage, conversationId, bounds, context));
}
async function scanRange(storage, conversationId, bounds, context) {
  const head = bounds.head;
  const range = [];
  let cursor;
  do {
    const page2 = await storage.scanEntries(head === void 0 ? { conversationId, maxEntryId: bounds.tail } : { conversationId, minEntryId: head.head, maxEntryId: bounds.tail }, SCAN_PAGE_SIZE, cursor, context);
    range.push(...page2.items);
    cursor = page2.next;
  } while (cursor !== void 0);
  return range.reverse();
}
function selectActive(head, range) {
  return head === void 0 ? range : [head, ...range.filter((entry) => entry.head === void 0)];
}
function orderToolResults(messages) {
  const ordered = [];
  for (let index3 = 0; index3 < messages.length; index3++) {
    const message = messages[index3];
    if (message.role === "toolResult")
      continue;
    ordered.push(message);
    if (message.role !== "assistant")
      continue;
    const calls = message.content.filter((content) => content.type === "toolCall");
    if (calls.length === 0)
      continue;
    const results = /* @__PURE__ */ new Map();
    for (let next = index3 + 1; next < messages.length && messages[next].role !== "assistant"; next++) {
      const candidate = messages[next];
      if (candidate.role === "toolResult" && !results.has(candidate.toolCallId)) {
        results.set(candidate.toolCallId, next);
      }
    }
    for (const call of calls) {
      const resultIndex = results.get(call.id);
      ordered.push(resultIndex === void 0 ? missingResult(call, message.timestamp) : messages[resultIndex]);
    }
  }
  return ordered;
}
function missingResult(call, timestamp) {
  return {
    role: "toolResult",
    toolCallId: call.id,
    toolName: call.name,
    content: [{ type: "text", text: MISSING_RESULT_TEXT }],
    isError: true,
    details: { reason: "missing_result" },
    timestamp
  };
}

// ../../node_modules/.pnpm/@earendil-works+pi-ai@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelcontextpro_284929f414f75b7f77d6867259ed136d/node_modules/@earendil-works/pi-ai/dist/utils/overflow.js
var OVERFLOW_PATTERNS = [
  /prompt (?:is )?too long/i,
  // Anthropic and z.ai token overflow
  /prompt exceeds max length/i,
  // z.ai CN endpoint token overflow
  /request_too_large/i,
  // Anthropic request byte-size overflow (HTTP 413)
  /input is too long for requested model/i,
  // Amazon Bedrock
  /exceeds the context window/i,
  // OpenAI (Completions & Responses API)
  /exceeds (?:the )?(?:model'?s )?maximum context length(?: of [\d,]+ tokens?|\s*\([\d,]+\))/i,
  // OpenAI-compatible proxies (LiteLLM)
  /input token count.*exceeds the maximum/i,
  // Google (Gemini)
  /maximum prompt length is \d+/i,
  // xAI (Grok)
  /reduce the length of the messages/i,
  // Groq
  /maximum context length is \d+ tokens/i,
  // OpenRouter (most backends)
  /exceeds (?:the )?maximum allowed input length of [\d,]+ tokens?/i,
  // OpenRouter/Poolside
  /input \(\d+ tokens\) is longer than the model'?s context length \(\d+ tokens\)/i,
  // Together AI
  /exceeds the limit of \d+/i,
  // GitHub Copilot
  /exceeds the available context size/i,
  // llama.cpp server
  /greater than the context length/i,
  // LM Studio
  /context window exceeds limit/i,
  // MiniMax
  /exceeded model token limit/i,
  // Kimi For Coding
  /too large for model with \d+ maximum context length/i,
  // Mistral
  /prompt has [\d,]+ tokens?, but the configured context size is [\d,]+ tokens?/i,
  // DS4 server
  /model_context_window_exceeded/i,
  // z.ai non-standard finish_reason surfaced as error text
  /prompt too long; exceeded (?:max )?context length/i,
  // Ollama explicit overflow error
  /range of input length should be/i,
  // DashScope / Qwen Token Plan
  /context[_ ]length[_ ]exceeded/i,
  // Generic fallback
  /too many tokens/i,
  // Generic fallback
  /token limit exceeded/i
  // Generic fallback
];
var CEREBRAS_BODYLESS_OVERFLOW_PATTERN = /^4(?:00|13)\s*(?:status code)?\s*\(no body\)/i;
var NON_OVERFLOW_PATTERNS = [
  /^(Throttling error|Service unavailable):/i,
  // AWS Bedrock non-overflow errors (human-readable prefixes from formatBedrockError)
  /rate limit/i,
  // Generic rate limiting
  /too many requests/i
  // Generic HTTP 429 style
];
function isContextOverflow(message, contextWindow) {
  if (message.stopReason === "error" && message.errorMessage) {
    const isNonOverflow = NON_OVERFLOW_PATTERNS.some((p) => p.test(message.errorMessage));
    if (!isNonOverflow) {
      if (OVERFLOW_PATTERNS.some((p) => p.test(message.errorMessage))) {
        return true;
      }
      if (message.provider === "cerebras" && CEREBRAS_BODYLESS_OVERFLOW_PATTERN.test(message.errorMessage)) {
        return true;
      }
    }
  }
  if (contextWindow && message.stopReason === "stop") {
    const inputTokens = message.usage.input + message.usage.cacheRead;
    if (inputTokens > contextWindow) {
      return true;
    }
  }
  if (contextWindow && message.stopReason === "length" && message.usage.output === 0) {
    const inputTokens = message.usage.input + message.usage.cacheRead;
    if (inputTokens >= contextWindow * 0.99) {
      return true;
    }
  }
  return false;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/inbox.js
var InboxDoc = defineDoc({
  kind: "pi.inbox",
  version: 1,
  scope: "conversation",
  history: "latest",
  fork: "initial",
  initial: () => ({ items: [] }),
  checkpointWhen: (value) => value.items.length === 0
});
async function prepareBoundary(tx, conversationId, modes) {
  const head = (await tx.latestHeadMarker(conversationId))?.head;
  const inbox = await tx.doc(InboxDoc, conversationId);
  return {
    conversationId,
    inbox,
    steeringMode: modes.steeringMode,
    followUpMode: modes.followUpMode,
    head
  };
}
async function applyBoundary(tx, boundary, at, now) {
  const { conversationId, inbox } = boundary;
  const items = inbox.items;
  const reset = items.some((item) => item.mode === "write" && item.entry.head === "self");
  const final = at === "final" || reset;
  const pick = (mode, queueMode) => {
    const indexes = items.flatMap((item, index3) => item.mode === mode ? [index3] : []);
    return queueMode === "all" ? indexes : indexes.slice(0, 1);
  };
  const writes = items.flatMap((item, index3) => item.mode === "write" ? [index3] : []);
  const users = [...pick("steer", boundary.steeringMode), ...final ? pick("followUp", boundary.followUpMode) : []];
  users.sort((a, b) => a - b);
  for (const index3 of writes) {
    const item = items[index3];
    const draft = item.entry;
    if (isStale(boundary, draft)) {
      tx.settleSubmission(item.id, { status: "unanswered", reason: "stale" });
      continue;
    }
    const entry = await tx.appendEntry(conversationId, draft);
    if (draft.head !== void 0)
      boundary.head = draft.head === "self" ? entry.id : draft.head;
    tx.placeSubmission(item.id, entry.id);
  }
  const placed = [];
  for (const index3 of users) {
    const item = items[index3];
    const message = { role: "user", content: item.content, timestamp: now };
    const entry = await tx.appendEntry(UserEntry, conversationId, { model: [message] });
    tx.placeSubmission(item.id, entry.id);
    placed.push(item.id);
  }
  const removed = [...writes, ...users].sort((a, b) => b - a);
  for (const index3 of removed)
    items.splice(index3, 1);
  return { users: placed, reset };
}
function isStale(boundary, entry) {
  return typeof entry.head === "number" && boundary.head !== void 0 && entry.head < boundary.head;
}
async function removeInboxItem(tx, conversationId, id) {
  const items = (await tx.doc(InboxDoc, conversationId)).items;
  const index3 = items.findIndex((item) => item.id === id);
  if (index3 >= 0)
    items.splice(index3, 1);
}
async function withdrawQueuedInputs(tx, conversationId) {
  const items = (await tx.doc(InboxDoc, conversationId)).items;
  for (let index3 = items.length - 1; index3 >= 0; index3--) {
    const item = items[index3];
    if (item.mode === "write")
      continue;
    tx.settleSubmission(item.id, { status: "unanswered", reason: "aborted" });
    items.splice(index3, 1);
  }
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/json.js
function assignJson(target, key, value) {
  const slots = target;
  const current = slots[key];
  if (isRecord(current) && isRecord(value)) {
    for (const name of Object.keys(current))
      if (!Object.hasOwn(value, name))
        delete current[name];
    for (const [name, child] of Object.entries(value))
      assignJson(current, name, child);
    return;
  }
  if (Array.isArray(current) && Array.isArray(value) && current.length <= value.length) {
    const items = current;
    for (let index3 = 0; index3 < value.length; index3++) {
      if (index3 < items.length)
        assignJson(items, index3, value[index3]);
      else
        items.push(value[index3]);
    }
    return;
  }
  if (current !== value)
    slots[key] = value;
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/prompt.js
function replaySections(messages) {
  const shown = /* @__PURE__ */ new Map();
  for (const message of messages) {
    if (message.role !== "system" || message.sections === void 0)
      continue;
    for (const [key, value] of Object.entries(message.sections)) {
      if (value === null)
        shown.delete(key);
      else
        shown.set(key, value);
    }
  }
  return shown;
}
async function renderSections(sections, input, shown, report, context) {
  const desired = /* @__PURE__ */ new Map();
  for (const section2 of sections) {
    let text;
    try {
      text = await section2.render(input, context);
    } catch (error) {
      if (context.abortSignal?.aborted)
        throw error;
      report(error);
      const kept = shown.get(section2.key);
      if (kept !== void 0)
        desired.set(section2.key, kept);
      continue;
    }
    if (text === void 0)
      continue;
    desired.set(section2.key, section2.tag === false ? text : `<${section2.key}>
${text}
</${section2.key}>`);
  }
  return desired;
}
function planSystemEntries(view, desired, tools, timestamp) {
  const head = view.head;
  if (head !== void 0 && !view.entries.some((entry) => SystemEntry.is(entry) && entry.id > head.id)) {
    const edits = view.entries.filter((entry) => SystemEntry.is(entry)).map((entry) => ({ target: entry.id, action: "omit" }));
    const baseline = systemEntry(Object.fromEntries(desired), { toolsRemoved: [], toolsAdded: tools.map(toToolDeclaration) }, timestamp);
    return [edits.length === 0 ? baseline : { ...baseline, edits }];
  }
  const sections = planSections(replaySections(view.messages), desired);
  const changes = planTools(getCurrentTools(view.messages), tools);
  if (changes.toolsRemoved.length === 0 && changes.toolsAdded.length === 0) {
    return sections.map((patch) => systemEntry(patch, void 0, timestamp));
  }
  if (sections.length === 0)
    return [systemEntry(void 0, changes, timestamp)];
  return sections.map((patch, index3) => systemEntry(patch, index3 === sections.length - 1 ? changes : void 0, timestamp));
}
function planTools(offered, desired) {
  const wanted = new Map(desired.map((tool) => [tool.name, tool]));
  const kept = offered.filter((tool) => {
    const next = wanted.get(tool.name);
    return next !== void 0 && declarationsEqual(tool, next);
  });
  const keptNames = new Set(kept.map((tool) => tool.name));
  const added = desired.filter((tool) => !keptNames.has(tool.name));
  const replayed = [...kept, ...added];
  if (replayed.some((tool, index3) => tool.name !== desired[index3].name)) {
    return {
      toolsRemoved: offered.map((tool) => ({ name: tool.name })),
      toolsAdded: desired.map(toToolDeclaration)
    };
  }
  return {
    toolsRemoved: offered.filter((tool) => !keptNames.has(tool.name)).map((tool) => ({ name: tool.name })),
    toolsAdded: added.map(toToolDeclaration)
  };
}
function planSections(shown, desired) {
  const patchedOrder = [
    ...[...shown.keys()].filter((key) => desired.has(key)),
    ...[...desired.keys()].filter((key) => !shown.has(key))
  ];
  const desiredOrder = [...desired.keys()];
  if (patchedOrder.some((key, index3) => key !== desiredOrder[index3])) {
    return [Object.fromEntries([...shown.keys()].map((key) => [key, null])), Object.fromEntries(desired)];
  }
  const patch = {};
  for (const [key, value] of shown) {
    const next = desired.get(key);
    if (next !== value)
      patch[key] = next ?? null;
  }
  for (const [key, value] of desired)
    if (!shown.has(key))
      patch[key] = value;
  return Object.keys(patch).length === 0 ? [] : [patch];
}
function systemEntry(sections, tools, timestamp) {
  const message = {
    role: "system",
    content: "",
    ...sections === void 0 ? {} : { sections },
    ...tools === void 0 || tools.toolsRemoved.length === 0 ? {} : { toolsRemoved: tools.toolsRemoved },
    ...tools === void 0 || tools.toolsAdded.length === 0 ? {} : { toolsAdded: tools.toolsAdded },
    timestamp
  };
  return { model: [message] };
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/_refine.mjs
function IsRefine2(value) {
  return guard_exports.HasPropertyKey(value, "~refine") && guard_exports.IsArray(value["~refine"]) && guard_exports.Every(value["~refine"], 0, (value2) => guard_exports.IsObject(value2) && guard_exports.HasPropertyKey(value2, "check") && guard_exports.HasPropertyKey(value2, "error") && guard_exports.IsFunction(value2.check) && guard_exports.IsFunction(value2.error));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/schema.mjs
function IsSchemaObject(value) {
  return guard_exports.IsObject(value) && !guard_exports.IsArray(value);
}
function IsSchemaBoolean(value) {
  return guard_exports.IsBoolean(value);
}
function IsSchema2(value) {
  return IsSchemaObject(value) || IsSchemaBoolean(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/additionalItems.mjs
function IsAdditionalItems(schema) {
  return guard_exports.HasPropertyKey(schema, "additionalItems") && IsSchema2(schema.additionalItems);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/additionalProperties.mjs
function IsAdditionalProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "additionalProperties") && IsSchema2(schema.additionalProperties);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/allOf.mjs
function IsAllOf(schema) {
  return guard_exports.HasPropertyKey(schema, "allOf") && guard_exports.IsArray(schema.allOf) && schema.allOf.every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/anchor.mjs
function IsAnchor(schema) {
  return guard_exports.HasPropertyKey(schema, "$anchor") && guard_exports.IsString(schema.$anchor);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/anyOf.mjs
function IsAnyOf(schema) {
  return guard_exports.HasPropertyKey(schema, "anyOf") && guard_exports.IsArray(schema.anyOf) && schema.anyOf.every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/const.mjs
function IsConst(value) {
  return guard_exports.HasPropertyKey(value, "const");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/contains.mjs
function IsContains(schema) {
  return guard_exports.HasPropertyKey(schema, "contains") && IsSchema2(schema.contains);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/default.mjs
function IsDefault(schema) {
  return guard_exports.HasPropertyKey(schema, "default");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/dependencies.mjs
function IsDependencies(schema) {
  return guard_exports.HasPropertyKey(schema, "dependencies") && guard_exports.IsObject(schema.dependencies) && Object.values(schema.dependencies).every((value) => IsSchema2(value) || guard_exports.IsArray(value) && value.every((value2) => guard_exports.IsString(value2)));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/dependentRequired.mjs
function IsDependentRequired(schema) {
  return guard_exports.HasPropertyKey(schema, "dependentRequired") && guard_exports.IsObject(schema.dependentRequired) && Object.values(schema.dependentRequired).every((value) => guard_exports.IsArray(value) && value.every((value2) => guard_exports.IsString(value2)));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/dependentSchemas.mjs
function IsDependentSchemas(schema) {
  return guard_exports.HasPropertyKey(schema, "dependentSchemas") && guard_exports.IsObject(schema.dependentSchemas) && Object.values(schema.dependentSchemas).every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/dynamicAnchor.mjs
function IsDynamicAnchor(schema) {
  return guard_exports.HasPropertyKey(schema, "$dynamicAnchor") && guard_exports.IsString(schema.$dynamicAnchor);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/dynamicRef.mjs
function IsDynamicRef(schema) {
  return guard_exports.HasPropertyKey(schema, "$dynamicRef") && guard_exports.IsString(schema.$dynamicRef);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/else.mjs
function IsElse(schema) {
  return guard_exports.HasPropertyKey(schema, "else") && IsSchema2(schema.else);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/enum.mjs
function IsEnum2(schema) {
  return guard_exports.HasPropertyKey(schema, "enum") && guard_exports.IsArray(schema.enum);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/exclusiveMaximum.mjs
function IsExclusiveMaximum(schema) {
  return guard_exports.HasPropertyKey(schema, "exclusiveMaximum") && (guard_exports.IsNumber(schema.exclusiveMaximum) || guard_exports.IsBigInt(schema.exclusiveMaximum));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/exclusiveMinimum.mjs
function IsExclusiveMinimum(schema) {
  return guard_exports.HasPropertyKey(schema, "exclusiveMinimum") && (guard_exports.IsNumber(schema.exclusiveMinimum) || guard_exports.IsBigInt(schema.exclusiveMinimum));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/format.mjs
function IsFormat(schema) {
  return guard_exports.HasPropertyKey(schema, "format") && guard_exports.IsString(schema.format);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/id.mjs
function IsId(schema) {
  return guard_exports.HasPropertyKey(schema, "$id") && guard_exports.IsString(schema.$id);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/if.mjs
function IsIf(schema) {
  return guard_exports.HasPropertyKey(schema, "if") && IsSchema2(schema.if);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/items.mjs
function IsItems(schema) {
  return guard_exports.HasPropertyKey(schema, "items") && (IsSchema2(schema.items) || guard_exports.IsArray(schema.items) && schema.items.every((value) => {
    return IsSchema2(value);
  }));
}
function IsItemsSized(schema) {
  return IsItems(schema) && guard_exports.IsArray(schema.items);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/maximum.mjs
function IsMaximum(schema) {
  return guard_exports.HasPropertyKey(schema, "maximum") && (guard_exports.IsNumber(schema.maximum) || guard_exports.IsBigInt(schema.maximum));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/maxContains.mjs
function IsMaxContains(schema) {
  return guard_exports.HasPropertyKey(schema, "maxContains") && guard_exports.IsNumber(schema.maxContains);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/maxItems.mjs
function IsMaxItems(schema) {
  return guard_exports.HasPropertyKey(schema, "maxItems") && guard_exports.IsNumber(schema.maxItems);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/maxLength.mjs
function IsMaxLength(schema) {
  return guard_exports.HasPropertyKey(schema, "maxLength") && guard_exports.IsNumber(schema.maxLength);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/maxProperties.mjs
function IsMaxProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "maxProperties") && guard_exports.IsNumber(schema.maxProperties);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/minimum.mjs
function IsMinimum(schema) {
  return guard_exports.HasPropertyKey(schema, "minimum") && (guard_exports.IsNumber(schema.minimum) || guard_exports.IsBigInt(schema.minimum));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/minContains.mjs
function IsMinContains(schema) {
  return guard_exports.HasPropertyKey(schema, "minContains") && guard_exports.IsNumber(schema.minContains);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/minItems.mjs
function IsMinItems(schema) {
  return guard_exports.HasPropertyKey(schema, "minItems") && guard_exports.IsNumber(schema.minItems);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/minLength.mjs
function IsMinLength(schema) {
  return guard_exports.HasPropertyKey(schema, "minLength") && guard_exports.IsNumber(schema.minLength);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/minProperties.mjs
function IsMinProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "minProperties") && guard_exports.IsNumber(schema.minProperties);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/multipleOf.mjs
function IsMultipleOf(schema) {
  return guard_exports.HasPropertyKey(schema, "multipleOf") && (guard_exports.IsNumber(schema.multipleOf) || guard_exports.IsBigInt(schema.multipleOf));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/not.mjs
function IsNot(schema) {
  return guard_exports.HasPropertyKey(schema, "not") && IsSchema2(schema.not);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/oneOf.mjs
function IsOneOf(schema) {
  return guard_exports.HasPropertyKey(schema, "oneOf") && guard_exports.IsArray(schema.oneOf) && schema.oneOf.every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/pattern.mjs
function IsPattern(schema) {
  return guard_exports.HasPropertyKey(schema, "pattern") && (guard_exports.IsString(schema.pattern) || schema.pattern instanceof RegExp);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/patternProperties.mjs
function IsPatternProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "patternProperties") && guard_exports.IsObject(schema.patternProperties) && Object.values(schema.patternProperties).every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/prefixItems.mjs
function IsPrefixItems(schema) {
  return guard_exports.HasPropertyKey(schema, "prefixItems") && guard_exports.IsArray(schema.prefixItems) && schema.prefixItems.every((schema2) => IsSchema2(schema2));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/properties.mjs
function IsProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "properties") && guard_exports.IsObject(schema.properties) && Object.values(schema.properties).every((value) => IsSchema2(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/propertyNames.mjs
function IsPropertyNames(schema) {
  return guard_exports.HasPropertyKey(schema, "propertyNames") && (guard_exports.IsObject(schema.propertyNames) || IsSchema2(schema.propertyNames));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/recursiveAnchor.mjs
function IsRecursiveAnchor(schema) {
  return guard_exports.HasPropertyKey(schema, "$recursiveAnchor") && guard_exports.IsBoolean(schema.$recursiveAnchor);
}
function IsRecursiveAnchorTrue(schema) {
  return IsRecursiveAnchor(schema) && guard_exports.IsEqual(schema.$recursiveAnchor, true);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/recursiveRef.mjs
function IsRecursiveRef(schema) {
  return guard_exports.HasPropertyKey(schema, "$recursiveRef") && guard_exports.IsString(schema.$recursiveRef);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/ref.mjs
function IsRef2(schema) {
  return guard_exports.HasPropertyKey(schema, "$ref") && guard_exports.IsString(schema.$ref);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/required.mjs
function IsRequired(schema) {
  return guard_exports.HasPropertyKey(schema, "required") && guard_exports.IsArray(schema.required) && schema.required.every((value) => guard_exports.IsString(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/then.mjs
function IsThen(schema) {
  return guard_exports.HasPropertyKey(schema, "then") && IsSchema2(schema.then);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/type.mjs
function IsType(schema) {
  return guard_exports.HasPropertyKey(schema, "type") && (guard_exports.IsString(schema.type) || guard_exports.IsArray(schema.type) && schema.type.every((value) => guard_exports.IsString(value)));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/uniqueItems.mjs
function IsUniqueItems(schema) {
  return guard_exports.HasPropertyKey(schema, "uniqueItems") && guard_exports.IsBoolean(schema.uniqueItems);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/unevaluatedItems.mjs
function IsUnevaluatedItems(schema) {
  return guard_exports.HasPropertyKey(schema, "unevaluatedItems") && IsSchema2(schema.unevaluatedItems);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/types/unevaluatedProperties.mjs
function IsUnevaluatedProperties(schema) {
  return guard_exports.HasPropertyKey(schema, "unevaluatedProperties") && IsSchema2(schema.unevaluatedProperties);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_context.mjs
function HasUnevaluatedFromObject(value) {
  return IsUnevaluatedItems(value) || IsUnevaluatedProperties(value) || guard_exports.Some(guard_exports.Keys(value), (key) => HasUnevaluatedFromUnknown(value[key]));
}
function HasUnevaluatedFromArray(value) {
  return guard_exports.Some(value, (value2) => HasUnevaluatedFromUnknown(value2));
}
function HasUnevaluatedFromUnknown(value) {
  return guard_exports.IsArray(value) ? HasUnevaluatedFromArray(value) : guard_exports.IsObject(value) ? HasUnevaluatedFromObject(value) : false;
}
function HasUnevaluated(context, schema) {
  return HasUnevaluatedFromUnknown(schema) || guard_exports.Some(guard_exports.Keys(context), (key) => HasUnevaluatedFromUnknown(context[key]));
}
var BuildContext = class {
  constructor(hasUnevaluated) {
    this.hasUnevaluated = hasUnevaluated;
  }
  UseUnevaluated() {
    return this.hasUnevaluated;
  }
  // ----------------------------------------------------------------
  // Stack
  // ----------------------------------------------------------------
  Push() {
    return emit_exports.Call(emit_exports.Member("context", "Push"), []);
  }
  Pop() {
    return emit_exports.Call(emit_exports.Member("context", "Pop"), []);
  }
  // ----------------------------------------------------------------
  // Top
  // ----------------------------------------------------------------
  AddIndex(index3) {
    return emit_exports.Call(emit_exports.Member("context", "AddIndex"), [index3]);
  }
  AddKey(key) {
    return emit_exports.Call(emit_exports.Member("context", "AddKey"), [key]);
  }
  Merge(results) {
    return emit_exports.Call(emit_exports.Member("context", "Merge"), [results]);
  }
};
var CheckContext = class {
  constructor() {
    const indices = /* @__PURE__ */ new Set();
    const keys = /* @__PURE__ */ new Set();
    this.stack = [{ indices, keys }];
  }
  // ----------------------------------------------------------------
  // Stack
  // ----------------------------------------------------------------
  Push() {
    const indices = /* @__PURE__ */ new Set();
    const keys = /* @__PURE__ */ new Set();
    this.stack.push({ indices, keys });
    return true;
  }
  Pop() {
    this.stack.pop();
    return true;
  }
  // ----------------------------------------------------------------
  // Top
  // ----------------------------------------------------------------
  AddIndex(index3) {
    this.GetIndices().add(index3);
    return true;
  }
  AddKey(key) {
    this.GetKeys().add(key);
    return true;
  }
  GetIndices() {
    const top = this.stack[this.stack.length - 1];
    return top.indices;
  }
  GetKeys() {
    const top = this.stack[this.stack.length - 1];
    return top.keys;
  }
  Merge(results) {
    for (const context of results) {
      context.GetIndices().forEach((value) => this.GetIndices().add(value));
      context.GetKeys().forEach((value) => this.GetKeys().add(value));
    }
    return true;
  }
};
var ErrorContext = class extends CheckContext {
  constructor() {
    super();
    this.errors = [];
  }
  AtCapacity() {
    return this.errors.length >= settings_exports.Get().maxErrors;
  }
  AddError(error) {
    if (!this.AtCapacity())
      this.errors.push(error);
    return false;
  }
  GetErrors() {
    return this.errors;
  }
};

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_externals.mjs
var state = {
  identifier: "External",
  variables: []
};
function CreateVariable(value) {
  const call = `External[${state.variables.length}]`;
  state.variables.push(value);
  return call;
}
function ResetExternal() {
  state.variables = [];
}
function GetExternal() {
  return { ...state };
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_refine.mjs
function BuildRefine(_stack, _context, schema, value) {
  const refinements = CreateVariable(schema["~refine"].map((refinement) => refinement));
  return emit_exports.Every(refinements, emit_exports.Constant(0), ["refinement", "_"], emit_exports.Call(emit_exports.Member("refinement", "check"), [value]));
}
function CheckRefine(_stack, _context, schema, value) {
  return guard_exports.Every(schema["~refine"], 0, (refinement, _) => refinement.check(value));
}
function ErrorRefine(_stack, context, schemaPath, instancePath, schema, value) {
  return guard_exports.EveryAll(schema["~refine"], 0, (refinement, index3) => {
    return refinement.check(value) || context.AddError({
      keyword: "~refine",
      schemaPath,
      instancePath,
      params: { index: index3, message: refinement.error(value) }
    });
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_unique.mjs
var index = 0;
function Unique() {
  return `var_${index++}`;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/additionalItems.mjs
function IsValid(schema) {
  return IsItems(schema) && guard_exports.IsArray(schema.items);
}
function BuildAdditionalItemsStandard(stack, context, schema, value) {
  const [item, index3] = [Unique(), Unique()];
  const isSchema = BuildSchemaPushStack(stack, context, schema.additionalItems, item);
  const isLength = emit_exports.IsLessThan(index3, emit_exports.Constant(schema.items.length));
  const addIndex = context.AddIndex(index3);
  return emit_exports.Every(value, emit_exports.Constant(0), [item, index3], emit_exports.Or(isLength, emit_exports.And(isSchema, addIndex)));
}
function BuildAdditionalItemsFast(stack, context, schema, value) {
  const [item, index3] = [Unique(), Unique()];
  const isSchema = BuildSchemaPushStack(stack, context, schema.additionalItems, item);
  const isLength = emit_exports.IsLessThan(index3, emit_exports.Constant(schema.items.length));
  return emit_exports.Every(value, emit_exports.Constant(0), [item, index3], emit_exports.Or(isLength, isSchema));
}
function BuildAdditionalItems(stack, context, schema, value) {
  if (!IsValid(schema))
    return emit_exports.Constant(true);
  return context.UseUnevaluated() ? BuildAdditionalItemsStandard(stack, context, schema, value) : BuildAdditionalItemsFast(stack, context, schema, value);
}
function CheckAdditionalItems(stack, context, schema, value) {
  if (!IsValid(schema))
    return true;
  const isAdditionalItems = guard_exports.Every(value, 0, (item, index3) => {
    return guard_exports.IsLessThan(index3, schema.items.length) || CheckSchemaPushStack(stack, context, schema.additionalItems, item) && context.AddIndex(index3);
  });
  return isAdditionalItems;
}
function ErrorAdditionalItems(stack, context, schemaPath, instancePath, schema, value) {
  if (!IsValid(schema))
    return true;
  const isAdditionalItems = guard_exports.Every(value, 0, (item, index3) => {
    const nextSchemaPath = `${schemaPath}/additionalItems`;
    const nextInstancePath = `${instancePath}/${index3}`;
    return guard_exports.IsLessThan(index3, schema.items.length) || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema.additionalItems, item) && context.AddIndex(index3);
  });
  return isAdditionalItems;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_regexp.mjs
function UnicodeRegExp(pattern) {
  return new RegExp(pattern, "u");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/additionalProperties.mjs
function IsAdditionalPropertiesIgnored(context, additionalProperties) {
  return !context.UseUnevaluated() && (guard_exports.IsEqual(additionalProperties, true) || guard_exports.IsObject(additionalProperties) && guard_exports.IsEqual(guard_exports.Keys(additionalProperties).length, 0));
}
function GetPropertyKeyAsPattern(key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return `^${escaped}$`;
}
function GetPropertiesPattern(schema) {
  const patterns = [];
  if (IsPatternProperties(schema))
    patterns.push(...guard_exports.Keys(schema.patternProperties));
  if (IsProperties(schema))
    patterns.push(...guard_exports.Keys(schema.properties).map(GetPropertyKeyAsPattern));
  return guard_exports.IsEqual(patterns.length, 0) ? "(?!)" : `(${patterns.join("|")})`;
}
function CanAdditionalPropertiesFast(_context, schema, _value) {
  return IsRequired(schema) && IsProperties(schema) && !IsPatternProperties(schema) && guard_exports.IsEqual(schema.additionalProperties, false) && guard_exports.IsEqual(guard_exports.Keys(schema.properties).length, schema.required.length);
}
function BuildAdditionalPropertiesFast(_context, schema, value) {
  return emit_exports.IsEqual(emit_exports.Member(emit_exports.Call(emit_exports.Member("Object", "getOwnPropertyNames"), [value]), "length"), emit_exports.Constant(schema.required.length));
}
function BuildAdditionalPropertiesStandard(stack, context, schema, value) {
  const [key, _index] = [Unique(), Unique()];
  const regexp = CreateVariable(UnicodeRegExp(GetPropertiesPattern(schema)));
  const isSchema = BuildSchemaPushStack(stack, context, schema.additionalProperties, `${value}[${key}]`);
  const isKey = emit_exports.Call(emit_exports.Member(regexp, "test"), [key]);
  const addKey = context.AddKey(key);
  const guarded = context.UseUnevaluated() ? emit_exports.Or(isKey, emit_exports.And(isSchema, addKey)) : emit_exports.Or(isKey, isSchema);
  const result = emit_exports.Every(emit_exports.Keys(value), emit_exports.Constant(0), [key, _index], guarded);
  return result;
}
function BuildAdditionalProperties(stack, context, schema, value) {
  if (IsAdditionalPropertiesIgnored(context, schema.additionalProperties))
    return emit_exports.Constant(true);
  return CanAdditionalPropertiesFast(context, schema, value) ? BuildAdditionalPropertiesFast(context, schema, value) : BuildAdditionalPropertiesStandard(stack, context, schema, value);
}
function CheckAdditionalProperties(stack, context, schema, value) {
  const regexp = UnicodeRegExp(GetPropertiesPattern(schema));
  const isAdditionalProperties = guard_exports.Every(guard_exports.Keys(value), 0, (key, _index) => {
    return regexp.test(key) || CheckSchemaPushStack(stack, context, schema.additionalProperties, value[key]) && context.AddKey(key);
  });
  return isAdditionalProperties;
}
function ErrorAdditionalProperties(stack, context, schemaPath, instancePath, schema, value) {
  const regexp = UnicodeRegExp(GetPropertiesPattern(schema));
  const additionalProperties = [];
  const isAdditionalProperties = guard_exports.EveryAll(guard_exports.Keys(value), 0, (key, _index) => {
    const nextSchemaPath = `${schemaPath}/additionalProperties`;
    const nextInstancePath = `${instancePath}/${key}`;
    const isAdditionalProperty = regexp.test(key) || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema.additionalProperties, value[key]) && context.AddKey(key);
    if (!isAdditionalProperty)
      additionalProperties.push(key);
    return isAdditionalProperty;
  });
  return isAdditionalProperties || context.AddError({
    keyword: "additionalProperties",
    schemaPath,
    instancePath,
    params: { additionalProperties }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_reducer.mjs
function Reducer(stack, context, schemas, value, check) {
  const results = emit_exports.ConstDeclaration("results", "[]");
  const context_n = schemas.map((_schema, index3) => emit_exports.ConstDeclaration(`context_${index3}`, emit_exports.New("CheckContext", [])));
  const condition_n = schemas.map((schema, index3) => emit_exports.ConstDeclaration(`condition_${index3}`, emit_exports.Call(emit_exports.ArrowFunction(["context"], BuildSchema(stack, context, schema, value)), [`context_${index3}`])));
  const checks = schemas.map((_schema, index3) => emit_exports.If(`condition_${index3}`, emit_exports.Call(emit_exports.Member("results", "push"), [`context_${index3}`])));
  const returns = emit_exports.Return(emit_exports.And(check, context.Merge("results")));
  return emit_exports.Call(emit_exports.ArrowFunction([], emit_exports.Statements([results, ...context_n, ...condition_n, ...checks, returns])), []);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/allOf.mjs
function BuildAllOfStandard(stack, context, schema, value) {
  return Reducer(stack, context, schema.allOf, value, emit_exports.IsEqual(emit_exports.Member("results", "length"), emit_exports.Constant(schema.allOf.length)));
}
function BuildAllOfFast(stack, context, schema, value) {
  return emit_exports.ReduceAnd(schema.allOf.map((schema2) => BuildSchema(stack, context, schema2, value)));
}
function BuildAllOf(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildAllOfStandard(stack, context, schema, value) : BuildAllOfFast(stack, context, schema, value);
}
function CheckAllOf(stack, context, schema, value) {
  const results = schema.allOf.reduce((result, schema2) => {
    const nextContext = new CheckContext();
    return CheckSchema(stack, nextContext, schema2, value) ? [...result, nextContext] : result;
  }, []);
  return guard_exports.IsEqual(results.length, schema.allOf.length) && context.Merge(results);
}
function ErrorAllOf(stack, context, schemaPath, instancePath, schema, value) {
  const failedContexts = [];
  const results = schema.allOf.reduce((result, schema2, index3) => {
    const nextSchemaPath = `${schemaPath}/allOf/${index3}`;
    const nextContext = new ErrorContext();
    const isSchema = ErrorSchema(stack, nextContext, nextSchemaPath, instancePath, schema2, value);
    if (!isSchema)
      failedContexts.push(nextContext);
    return isSchema ? [...result, nextContext] : result;
  }, []);
  const isAllOf = guard_exports.IsEqual(results.length, schema.allOf.length) && context.Merge(results);
  if (!isAllOf)
    failedContexts.forEach((failed) => failed.GetErrors().forEach((error) => context.AddError(error)));
  return isAllOf;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/anyOf.mjs
function BuildAnyOfStandard(stack, context, schema, value) {
  return Reducer(stack, context, schema.anyOf, value, emit_exports.IsGreaterThan(emit_exports.Member("results", "length"), emit_exports.Constant(0)));
}
function BuildAnyOfFast(stack, context, schema, value) {
  return emit_exports.ReduceOr(schema.anyOf.map((schema2) => BuildSchema(stack, context, schema2, value)));
}
function BuildAnyOf(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildAnyOfStandard(stack, context, schema, value) : BuildAnyOfFast(stack, context, schema, value);
}
function CheckAnyOf(stack, context, schema, value) {
  const results = schema.anyOf.reduce((result, schema2) => {
    const nextContext = new CheckContext();
    return CheckSchema(stack, nextContext, schema2, value) ? [...result, nextContext] : result;
  }, []);
  return guard_exports.IsGreaterThan(results.length, 0) && context.Merge(results);
}
function ErrorAnyOf(stack, context, schemaPath, instancePath, schema, value) {
  const failedContexts = [];
  const results = schema.anyOf.reduce((result, schema2, index3) => {
    const nextContext = new ErrorContext();
    const nextSchemaPath = `${schemaPath}/anyOf/${index3}`;
    const isSchema = ErrorSchema(stack, nextContext, nextSchemaPath, instancePath, schema2, value);
    if (!isSchema)
      failedContexts.push(nextContext);
    return isSchema ? [...result, nextContext] : result;
  }, []);
  const isAnyOf = guard_exports.IsGreaterThan(results.length, 0) && context.Merge(results);
  if (!isAnyOf)
    failedContexts.forEach((failed) => failed.GetErrors().forEach((error) => context.AddError(error)));
  return isAnyOf || context.AddError({
    keyword: "anyOf",
    schemaPath,
    instancePath,
    params: {}
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/boolean.mjs
function BuildSchemaBoolean(_stack, _context, schema, _value) {
  return schema ? emit_exports.Constant(true) : emit_exports.Constant(false);
}
function CheckSchemaBoolean(_stack, _context, schema, _value) {
  return schema;
}
function ErrorSchemaBoolean(stack, context, schemaPath, instancePath, schema, value) {
  return CheckSchemaBoolean(stack, context, schema, value) || context.AddError({
    keyword: "boolean",
    schemaPath,
    instancePath,
    params: {}
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/const.mjs
function BuildConst(_stack, _context, schema, value) {
  return guard_exports.IsValueLike(schema.const) ? emit_exports.IsEqual(value, emit_exports.Constant(schema.const)) : emit_exports.IsDeepEqual(value, CreateVariable(schema.const));
}
function CheckConst(_stack, _context, schema, value) {
  return guard_exports.IsValueLike(schema.const) ? guard_exports.IsEqual(value, schema.const) : guard_exports.IsDeepEqual(value, schema.const);
}
function ErrorConst(stack, context, schemaPath, instancePath, schema, value) {
  return CheckConst(stack, context, schema, value) || context.AddError({
    keyword: "const",
    schemaPath,
    instancePath,
    params: { allowedValue: schema.const }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/contains.mjs
function IsValid2(schema) {
  return !(IsMinContains(schema) && guard_exports.IsEqual(schema.minContains, 0));
}
function BuildContainsStandard(stack, context, schema, value) {
  const [item, index3] = [Unique(), Unique()];
  const isLength = emit_exports.Not(emit_exports.IsEqual(emit_exports.Member(value, "length"), emit_exports.Constant(0)));
  const isSome = emit_exports.SomeAll(value, [item, index3], emit_exports.And(BuildSchema(stack, context, schema.contains, item), context.AddIndex(index3)));
  return emit_exports.And(isLength, isSome);
}
function BuildContainsFast(stack, context, schema, value) {
  const [item] = [Unique()];
  const isLength = emit_exports.Not(emit_exports.IsEqual(emit_exports.Member(value, "length"), emit_exports.Constant(0)));
  const isSome = emit_exports.Some(value, [item, "_"], BuildSchema(stack, context, schema.contains, item));
  return emit_exports.And(isLength, isSome);
}
function BuildContains(stack, context, schema, value) {
  if (!IsValid2(schema))
    return emit_exports.Constant(true);
  return context.UseUnevaluated() ? BuildContainsStandard(stack, context, schema, value) : BuildContainsFast(stack, context, schema, value);
}
function CheckContains(stack, context, schema, value) {
  if (!IsValid2(schema))
    return true;
  return !guard_exports.IsEqual(value.length, 0) && guard_exports.SomeAll(value, (item, index3) => {
    return CheckSchema(stack, context, schema.contains, item) && context.AddIndex(index3);
  });
}
function ErrorContains(stack, context, schemaPath, instancePath, schema, value) {
  return CheckContains(stack, context, schema, value) || context.AddError({
    keyword: "contains",
    schemaPath,
    instancePath,
    params: { minContains: 1 }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/dependencies.mjs
function BuildDependencies(stack, context, schema, value) {
  const isLength = emit_exports.IsEqual(emit_exports.Member(emit_exports.Keys(value), "length"), emit_exports.Constant(0));
  const isEveryDependency = emit_exports.ReduceAnd(guard_exports.Entries(schema.dependencies).map(([key, schema2]) => {
    const notKey = emit_exports.Not(emit_exports.HasPropertyKey(value, emit_exports.Constant(key)));
    const isSchema = BuildSchema(stack, context, schema2, value);
    const isEveryKey = (schema3) => emit_exports.ReduceAnd(schema3.map((key2) => emit_exports.HasPropertyKey(value, emit_exports.Constant(key2))));
    return emit_exports.Or(notKey, guard_exports.IsArray(schema2) ? isEveryKey(schema2) : isSchema);
  }));
  return emit_exports.Or(isLength, isEveryDependency);
}
function CheckDependencies(stack, context, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEvery = guard_exports.Every(guard_exports.Entries(schema.dependencies), 0, ([key, schema2]) => {
    return !guard_exports.HasPropertyKey(value, key) || (guard_exports.IsArray(schema2) ? schema2.every((key2) => guard_exports.HasPropertyKey(value, key2)) : CheckSchema(stack, context, schema2, value));
  });
  return isLength || isEvery;
}
function ErrorDependencies(stack, context, schemaPath, instancePath, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEvery = guard_exports.EveryAll(guard_exports.Entries(schema.dependencies), 0, ([key, schema2]) => {
    const nextSchemaPath = `${schemaPath}/dependencies/${key}`;
    return !guard_exports.HasPropertyKey(value, key) || (guard_exports.IsArray(schema2) ? schema2.every((dependency) => guard_exports.HasPropertyKey(value, dependency) || context.AddError({
      keyword: "dependencies",
      schemaPath,
      instancePath,
      params: { property: key, dependencies: schema2 }
    })) : ErrorSchema(stack, context, nextSchemaPath, instancePath, schema2, value));
  });
  return isLength || isEvery;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/dependentRequired.mjs
function BuildDependentRequired(_stack, _context, schema, value) {
  const isLength = emit_exports.IsEqual(emit_exports.Member(emit_exports.Keys(value), "length"), emit_exports.Constant(0));
  const isEvery = emit_exports.ReduceAnd(guard_exports.Entries(schema.dependentRequired).map(([key, keys]) => {
    const notKey = emit_exports.Not(emit_exports.HasPropertyKey(value, emit_exports.Constant(key)));
    const everyKey = emit_exports.ReduceAnd(keys.map((key2) => emit_exports.HasPropertyKey(value, emit_exports.Constant(key2))));
    return emit_exports.Or(notKey, everyKey);
  }));
  return emit_exports.Or(isLength, isEvery);
}
function CheckDependentRequired(_stack, _context, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEvery = guard_exports.Every(guard_exports.Entries(schema.dependentRequired), 0, ([key, keys]) => {
    return !guard_exports.HasPropertyKey(value, key) || keys.every((key2) => guard_exports.HasPropertyKey(value, key2));
  });
  return isLength || isEvery;
}
function ErrorDependentRequired(_stack, context, schemaPath, instancePath, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEveryEntry = guard_exports.EveryAll(guard_exports.Entries(schema.dependentRequired), 0, ([key, keys]) => {
    return !guard_exports.HasPropertyKey(value, key) || guard_exports.EveryAll(keys, 0, (dependency) => guard_exports.HasPropertyKey(value, dependency) || context.AddError({
      keyword: "dependentRequired",
      schemaPath,
      instancePath,
      params: { property: key, dependencies: keys }
    }));
  });
  return isLength || isEveryEntry;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/dependentSchemas.mjs
function BuildDependentSchemas(stack, context, schema, value) {
  const isLength = emit_exports.IsEqual(emit_exports.Member(emit_exports.Keys(value), "length"), emit_exports.Constant(0));
  const isEvery = emit_exports.ReduceAnd(guard_exports.Entries(schema.dependentSchemas).map(([key, schema2]) => {
    const notKey = emit_exports.Not(emit_exports.HasPropertyKey(value, emit_exports.Constant(key)));
    const isSchema = BuildSchema(stack, context, schema2, value);
    return emit_exports.Or(notKey, isSchema);
  }));
  return emit_exports.Or(isLength, isEvery);
}
function CheckDependentSchemas(stack, context, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEvery = guard_exports.Every(guard_exports.Entries(schema.dependentSchemas), 0, ([key, schema2]) => {
    return !guard_exports.HasPropertyKey(value, key) || CheckSchema(stack, context, schema2, value);
  });
  return isLength || isEvery;
}
function ErrorDependentSchemas(stack, context, schemaPath, instancePath, schema, value) {
  const isLength = guard_exports.IsEqual(guard_exports.Keys(value).length, 0);
  const isEvery = guard_exports.EveryAll(guard_exports.Entries(schema.dependentSchemas), 0, ([key, schema2]) => {
    const nextSchemaPath = `${schemaPath}/dependentSchemas/${key}`;
    return !guard_exports.HasPropertyKey(value, key) || ErrorSchema(stack, context, nextSchemaPath, instancePath, schema2, value);
  });
  return isLength || isEvery;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/dynamicRef.mjs
function BuildDynamicRef(stack, context, schema, value) {
  const target = stack.DynamicRef(schema) ?? false;
  return CreateFunction(stack, context, target, value);
}
function CheckDynamicRef(stack, context, schema, value) {
  const target = stack.DynamicRef(schema) ?? false;
  return IsSchema2(target) && CheckSchema(stack, context, target, value);
}
function ErrorDynamicRef(stack, context, _schemaPath, instancePath, schema, value) {
  const target = stack.DynamicRef(schema) ?? false;
  return IsSchema2(target) && ErrorSchema(stack, context, "#", instancePath, target, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/enum.mjs
function BuildEnum(_stack, _context, schema, value) {
  return emit_exports.ReduceOr(schema.enum.map((option) => {
    if (guard_exports.IsValueLike(option))
      return emit_exports.IsEqual(value, emit_exports.Constant(option));
    const variable = CreateVariable(option);
    return emit_exports.IsDeepEqual(value, variable);
  }));
}
function CheckEnum(_stack, _context, schema, value) {
  return guard_exports.Some(schema.enum, (option) => guard_exports.IsValueLike(option) ? guard_exports.IsEqual(value, option) : guard_exports.IsDeepEqual(value, option));
}
function ErrorEnum(stack, context, schemaPath, instancePath, schema, value) {
  return CheckEnum(stack, context, schema, value) || context.AddError({
    keyword: "enum",
    schemaPath,
    instancePath,
    params: { allowedValues: schema.enum }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/exclusiveMaximum.mjs
function BuildExclusiveMaximum(_stack, _context, schema, value) {
  return emit_exports.IsLessThan(value, emit_exports.Constant(schema.exclusiveMaximum));
}
function CheckExclusiveMaximum(_stack, _context, schema, value) {
  return guard_exports.IsLessThan(value, schema.exclusiveMaximum);
}
function ErrorExclusiveMaximum(stack, context, schemaPath, instancePath, schema, value) {
  return CheckExclusiveMaximum(stack, context, schema, value) || context.AddError({
    keyword: "exclusiveMaximum",
    schemaPath,
    instancePath,
    params: { comparison: "<", limit: schema.exclusiveMaximum }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/exclusiveMinimum.mjs
function BuildExclusiveMinimum(_stack, _context, schema, value) {
  return emit_exports.IsGreaterThan(value, emit_exports.Constant(schema.exclusiveMinimum));
}
function CheckExclusiveMinimum(_stack, _context, schema, value) {
  return guard_exports.IsGreaterThan(value, schema.exclusiveMinimum);
}
function ErrorExclusiveMinimum(stack, context, schemaPath, instancePath, schema, value) {
  return CheckExclusiveMinimum(stack, context, schema, value) || context.AddError({
    keyword: "exclusiveMinimum",
    schemaPath,
    instancePath,
    params: { comparison: ">", limit: schema.exclusiveMinimum }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/format.mjs
var format_exports = {};
__export(format_exports, {
  Clear: () => Clear,
  Entries: () => Entries,
  Get: () => Get2,
  Has: () => Has,
  IsDate: () => IsDate,
  IsDateTime: () => IsDateTime,
  IsDuration: () => IsDuration,
  IsEmail: () => IsEmail,
  IsHostname: () => IsHostname2,
  IsIPv4: () => IsIPv4,
  IsIPv6: () => IsIPv6,
  IsIdnEmail: () => IsIdnEmail,
  IsIdnHostname: () => IsIdnHostname2,
  IsIri: () => IsIri,
  IsIriReference: () => IsIriReference,
  IsJsonPointer: () => IsJsonPointer,
  IsJsonPointerUriFragment: () => IsJsonPointerUriFragment,
  IsRegex: () => IsRegex,
  IsRelativeJsonPointer: () => IsRelativeJsonPointer,
  IsTime: () => IsTime,
  IsUri: () => IsUri,
  IsUriReference: () => IsUriReference,
  IsUriTemplate: () => IsUriTemplate,
  IsUrl: () => IsUrl,
  IsUuid: () => IsUuid,
  Reset: () => Reset,
  Set: () => Set2,
  Test: () => Test
});

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/date.mjs
var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
function IsLeapYear(year) {
  return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
}
function IsDate(value) {
  const matches = DATE.exec(value);
  if (!matches)
    return false;
  const year = +matches[1];
  const month = +matches[2];
  const day = +matches[3];
  return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && IsLeapYear(year) ? 29 : DAYS[month]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/time.mjs
var TIME = /^(\d\d):(\d\d):(\d\d)(?:\.\d+)?(?:([Zz])|([+-])(\d\d):(\d\d))?$/;
function IsTime(value, strictTimeZone = true) {
  const matches = TIME.exec(value);
  if (!matches)
    return false;
  if (strictTimeZone && !matches[4] && !matches[5])
    return false;
  const hr = +matches[1];
  const min = +matches[2];
  const sec = +matches[3];
  if (hr > 23 || min > 59 || sec > 60)
    return false;
  if (matches[5]) {
    const tzH2 = +matches[6];
    const tzM2 = +matches[7];
    if (tzH2 > 23 || tzM2 > 59)
      return false;
  }
  if (sec < 60)
    return true;
  const tzSign = matches[5] === "-" ? -1 : 1;
  const tzH = +(matches[6] || 0);
  const tzM = +(matches[7] || 0);
  const totalUtcMin = hr * 60 + min - tzSign * (tzH * 60 + tzM);
  return (totalUtcMin % 1440 + 1440) % 1440 === 1439;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/date_time.mjs
function IsDateTime(value) {
  const dateTime = value.split(/T/i);
  return dateTime.length === 2 && IsDate(dateTime[0]) && IsTime(dateTime[1]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/duration.mjs
var Duration = /^P((\d+Y(\d+M(\d+D)?)?|\d+M(\d+D)?|\d+D)(T(\d+H(\d+M(\d+S)?)?|\d+M(\d+S)?|\d+S))?|T(\d+H(\d+M(\d+S)?)?|\d+M(\d+S)?|\d+S)|\d+W)$/;
function IsDuration(value) {
  return Duration.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/email.mjs
var Email = /^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[^"\\]|\\[\x20-\x7e])*")@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*|\[(?:IPv6:[a-f0-9:]+|(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3})\])$/i;
function IsEmail(value) {
  return Email.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/pattern/pattern.mjs
var RE_RULE_HYPHEN_PLACEMENT = new RegExp("^(?!-).*(?<!-)$");
var RE_RULE_NOT_RESERVED_ACE = /^(?!..--)/;
var RE_ASCII_LDH = /^[a-zA-Z0-9-]*$/;
var RE_ASCII = new RegExp("^\\p{ASCII}*$", "u");
var RE_NON_ASCII = /[^\p{ASCII}]/u;
var RE_ASCII_DIGIT = /[0-9]/;
var RE_ARABIC_INDIC_DIGIT = /[\u{0660}-\u{0669}]/u;
var RE_EXT_ARABIC_INDIC_DIGIT = /[\u{06f0}-\u{06f9}]/u;
var RE_COMMON_SEPARATOR = /[\u{002e}\u{002c}\u{003a}\u{002f}]/u;
var RE_EUROPEAN_SEPARATOR = /[\u{002d}\u{002b}]/u;
var RE_MARK_NONSPACING = new RegExp("\\p{Mn}", "u");
var RE_MARK_SPACING_COMBINING = new RegExp("\\p{Mc}", "u");
var RE_MARK_ENCLOSING = new RegExp("\\p{Me}", "u");
var RE_COMBINING_MARK = /[\p{Mn}\p{Mc}\p{Me}]/u;
var RE_LETTER = new RegExp("\\p{L}", "u");
var RE_NUMBER_DECIMAL = new RegExp("\\p{Nd}", "u");
var RE_SCRIPT_GREEK = new RegExp("\\p{Script=Greek}", "u");
var RE_SCRIPT_HEBREW = new RegExp("\\p{Script=Hebrew}", "u");
var RE_SCRIPT_JAPANESE = /[\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}]/u;
var RE_SCRIPT_ARABIC_LETTER = /[\p{Script=Arabic}\p{Script=Syriac}\p{Script=Thaana}\p{Script=Mandaic}]/u;
var RE_VIRAMA = /[\u{094d}\u{09cd}\u{0a4d}\u{0acd}\u{0b4d}\u{0bcd}\u{0c4d}\u{0ccd}\u{0d3b}\u{0d3c}\u{0d4d}\u{0dca}\u{1b44}\u{1baa}\u{1bab}\u{a9c0}\u{11046}\u{1107f}\u{110b9}\u{11133}\u{11134}\u{111c0}\u{11235}\u{1134d}\u{11442}\u{114c2}\u{115bf}\u{1163f}\u{116b6}\u{11c3f}\u{11d44}\u{11d45}]/u;
var RE_RFC5892_DISALLOWED = /[\u{0640}\u{07fa}\u{302e}\u{302f}\u{3031}\u{3032}\u{3033}\u{3034}\u{3035}\u{303b}]/u;
var RE_CONTEXTO_EXCEPTIONS = /[\u{00b7}\u{0375}\u{05f3}\u{05f4}\u{200c}\u{200d}\u{30fb}]/u;
var RE_PVALID_EXCEPTIONS = /[\u{00df}\u{03c2}\u{06fd}\u{06fe}\u{0f0b}\u{3007}]/u;
var RE_EUROPEAN_NUMBER = new RegExp([
  RE_ASCII_DIGIT,
  RE_EXT_ARABIC_INDIC_DIGIT
].map((regexp) => regexp.source).join("|"), "u");
var RE_PERMITTED_CATEGORY = new RegExp([
  RE_LETTER,
  RE_EUROPEAN_SEPARATOR,
  RE_COMMON_SEPARATOR,
  RE_NUMBER_DECIMAL,
  RE_MARK_NONSPACING,
  RE_MARK_SPACING_COMBINING,
  RE_CONTEXTO_EXCEPTIONS,
  RE_PVALID_EXCEPTIONS
].map((regexp) => regexp.source).join("|"), "u");

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/label/ascii.mjs
function IsAsciiLabel(value) {
  return RE_RULE_HYPHEN_PLACEMENT.test(value) && RE_RULE_NOT_RESERVED_ACE.test(value) && RE_ASCII_LDH.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/format/puny.mjs
var PUNYCODE_BASE = 36;
var PUNYCODE_TMIN = 1;
var PUNYCODE_TMAX = 26;
var PUNYCODE_SKEW = 38;
var PUNYCODE_DAMP = 700;
var PUNYCODE_INITIAL_BIAS = 72;
var PUNYCODE_INITIAL_N = 128;
function ThrowDontCare() {
  throw null;
}
function IsAcePrefixed(value) {
  return value.toLowerCase().startsWith("xn--");
}
function Adapt(delta, numPoints, firstTime) {
  delta = firstTime ? Math.floor(delta / PUNYCODE_DAMP) : delta >> 1;
  delta += Math.floor(delta / numPoints);
  let k = 0;
  while (delta > (PUNYCODE_BASE - PUNYCODE_TMIN) * PUNYCODE_TMAX >> 1) {
    delta = Math.floor(delta / (PUNYCODE_BASE - PUNYCODE_TMIN));
    k += PUNYCODE_BASE;
  }
  return k + Math.floor((PUNYCODE_BASE - PUNYCODE_TMIN + 1) * delta / (delta + PUNYCODE_SKEW));
}
function Decode(value) {
  const output = [];
  let n = PUNYCODE_INITIAL_N;
  let i = 0;
  let bias = PUNYCODE_INITIAL_BIAS;
  const delimIdx = value.lastIndexOf("-");
  if (delimIdx > 0) {
    for (let j = 0; j < delimIdx; j++) {
      const cp = value.charCodeAt(j);
      if (cp >= 128)
        ThrowDontCare();
      output.push(cp);
    }
  }
  let inIdx = delimIdx < 0 ? 0 : delimIdx + 1;
  while (inIdx < value.length) {
    const oldi = i;
    let w = 1;
    let k = PUNYCODE_BASE;
    while (true) {
      if (inIdx >= value.length)
        ThrowDontCare();
      const ch = value.charCodeAt(inIdx++);
      let digit;
      if (ch >= 97 && ch <= 122)
        digit = ch - 97;
      else if (ch >= 48 && ch <= 57)
        digit = ch - 48 + 26;
      else
        ThrowDontCare();
      i += digit * w;
      const t = k <= bias ? PUNYCODE_TMIN : k >= bias + PUNYCODE_TMAX ? PUNYCODE_TMAX : k - bias;
      if (digit < t)
        break;
      w *= PUNYCODE_BASE - t;
      k += PUNYCODE_BASE;
    }
    const outLen = output.length + 1;
    bias = Adapt(i - oldi, outLen, oldi === 0);
    n += Math.floor(i / outLen);
    i %= outLen;
    output.splice(i, 0, n);
    i++;
  }
  return String.fromCodePoint(...output);
}
function DigitToChar(digit) {
  return digit < 26 ? String.fromCharCode(digit + 97) : String.fromCharCode(digit - 26 + 48);
}
var RE_REPLACE_NON_ASCII = new RegExp(RE_NON_ASCII.source, "gu");
function Encode(input) {
  const basic = input.replace(RE_REPLACE_NON_ASCII, "");
  const basicLength = basic.length;
  const result = basicLength > 0 ? [basic, "-"] : [];
  const codePoints = Array.from(input, (char) => char.codePointAt(0));
  let n = PUNYCODE_INITIAL_N;
  let delta = 0;
  let bias = PUNYCODE_INITIAL_BIAS;
  let handledCPCount = basicLength;
  while (handledCPCount < codePoints.length) {
    let m = Infinity;
    for (const cp of codePoints) {
      if (cp >= n && cp < m)
        m = cp;
    }
    delta += (m - n) * (handledCPCount + 1);
    n = m;
    for (const cp of codePoints) {
      if (cp < n)
        delta++;
      if (cp === n) {
        let q = delta;
        for (let k = PUNYCODE_BASE; ; k += PUNYCODE_BASE) {
          const t = k <= bias ? PUNYCODE_TMIN : k >= bias + PUNYCODE_TMAX ? PUNYCODE_TMAX : k - bias;
          if (q < t)
            break;
          const digit = t + (q - t) % (PUNYCODE_BASE - t);
          result.push(DigitToChar(digit));
          q = Math.floor((q - t) / (PUNYCODE_BASE - t));
        }
        result.push(DigitToChar(q));
        bias = Adapt(delta, handledCPCount + 1, handledCPCount === basicLength);
        delta = 0;
        handledCPCount++;
      }
    }
    delta++;
    n++;
  }
  return result.join("");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/format/bidi.mjs
var RE_RTL_ALLOWED = /^(?:R|AL|AN|EN|ES|CS|ET|ON|BN|NSM)$/;
var RE_LTR_ALLOWED = /^(?:L|EN|ES|CS|ET|ON|BN|NSM)$/;
var RE_RTL_CLASSES = /^(?:R|AL|AN)$/;
function HasBidiChars(value) {
  if (IsAcePrefixed(value)) {
    try {
      return HasRightToLeftCharacters(Decode(value.slice(4).toLowerCase()));
    } catch {
      return false;
    }
  }
  return HasRightToLeftCharacters(value);
}
function GetBidiClass(codePoint) {
  const char = String.fromCodePoint(codePoint);
  return RE_EUROPEAN_NUMBER.test(char) ? "EN" : RE_ARABIC_INDIC_DIGIT.test(char) ? "AN" : (
    // Pattern.RE_EUROPEAN_SEPARATOR.test(char) ? 'ES' : // (no-spec-coverage)
    // Pattern.RE_COMMON_SEPARATOR.test(char) ? 'CS' : // (no-spec-coverage)
    RE_MARK_NONSPACING.test(char) ? "NSM" : RE_SCRIPT_HEBREW.test(char) ? "R" : RE_SCRIPT_ARABIC_LETTER.test(char) ? "AL" : RE_LETTER.test(char) ? "L" : "ON"
  );
}
function HasRightToLeftCharacters(value) {
  for (const ch of value)
    if (RE_RTL_CLASSES.test(GetBidiClass(ch.codePointAt(0))))
      return true;
  return false;
}
function SatisfiesBidiRule(value) {
  let isRtl = false;
  let allowed = RE_LTR_ALLOWED;
  let sawEN = false;
  let sawAN = false;
  let isFirst = true;
  for (const ch of value) {
    const bidiClass = GetBidiClass(ch.codePointAt(0));
    if (isFirst) {
      if (bidiClass !== "L" && bidiClass !== "R" && bidiClass !== "AL")
        return false;
      isRtl = bidiClass === "R" || bidiClass === "AL";
      allowed = isRtl ? RE_RTL_ALLOWED : RE_LTR_ALLOWED;
      isFirst = false;
    }
    if (!allowed.test(bidiClass))
      return false;
    if (bidiClass === "EN")
      sawEN = true;
    else if (bidiClass === "AN")
      sawAN = true;
  }
  if (isRtl && sawEN && sawAN)
    return false;
  return true;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/label/unicode.mjs
function ExceedsMaxALabelLength(value) {
  return RE_NON_ASCII.test(value) && Encode(value).length + 4 > 63;
}
function HasInvalidHyphens(chars) {
  if (chars[0] === "-" || chars[chars.length - 1] === "-")
    return true;
  return chars.slice(2).join("").startsWith("--");
}
function IsUnicodeLabel(value) {
  if (ExceedsMaxALabelLength(value))
    return false;
  if (HasRightToLeftCharacters(value) && !SatisfiesBidiRule(value))
    return false;
  const chars = [...value];
  const codePoints = chars.map((c) => c.codePointAt(0));
  const length = codePoints.length;
  if (HasInvalidHyphens(chars))
    return false;
  if (RE_COMBINING_MARK.test(chars[0]))
    return false;
  let hasJapanese = false;
  for (let i = 0; i < length; i++) {
    const codePoint = codePoints[i];
    const char = chars[i];
    if (RE_RFC5892_DISALLOWED.test(char))
      return false;
    if (!RE_PERMITTED_CATEGORY.test(char))
      return false;
    if (RE_SCRIPT_JAPANESE.test(char))
      hasJapanese = true;
    const prev = codePoints[i - 1], next = codePoints[i + 1];
    switch (codePoint) {
      case 183:
        if (prev !== 108 || next !== 108)
          return false;
        break;
      // MIDDLE DOT (Catalan)
      case 885:
        if (!next || !RE_SCRIPT_GREEK.test(chars[i + 1]))
          return false;
        break;
      // Greek KERAIA
      case 1523:
      case 1524:
        if (!prev || !RE_SCRIPT_HEBREW.test(chars[i - 1]))
          return false;
        break;
      // Hebrew GERESH
      case 8204:
        if (!prev || prev < 128 && !RE_VIRAMA.test(chars[i - 1]))
          return false;
        break;
      case 8205:
        if (!prev || !RE_VIRAMA.test(chars[i - 1]))
          return false;
        break;
      case 12539:
        break;
    }
  }
  if (value.includes("・") && !hasJapanese)
    return false;
  return true;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/label/puny.mjs
function IsPunyLabel(value) {
  if (!IsAcePrefixed(value))
    return false;
  try {
    const body = value.slice(4).toLowerCase();
    if (body.lastIndexOf("-") === 0)
      return false;
    const decoded = Decode(body);
    if (!RE_NON_ASCII.test(decoded))
      return false;
    return IsUnicodeLabel(decoded);
  } catch {
    return false;
  }
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/hostname.mjs
function IsValidLabelLength(value) {
  return value.length > 0 && value.length <= 63;
}
function IsLabel(value) {
  return IsValidLabelLength(value) && (IsPunyLabel(value) || IsAsciiLabel(value));
}
function IsHostname(value) {
  if (value.length === 0 || value.length > 253)
    return false;
  if (value.charCodeAt(value.length - 1) === 46)
    return false;
  return value.split(".").every((label) => IsLabel(label));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idna/idn-hostname.mjs
function IsValidLabelLength2(value) {
  return value.length > 0 && value.length <= 63;
}
function IsLabel2(value) {
  return IsValidLabelLength2(value) && (IsPunyLabel(value) || IsUnicodeLabel(value));
}
function NormalizeHostname(value) {
  return value.replace(/[\uff01-\uff5e]/g, (char) => String.fromCharCode(char.charCodeAt(0) - 65248)).normalize("NFC").replace(/[\u00ad\u034f\u180b-\u180d\u200b\ufe00-\ufe0f\u{e0100}-\u{e01ef}]/gu, "").replace(/[\u002E\u3002\uFF0E\uFF61]/g, ".");
}
function IsIdnHostname(value) {
  if (value.length === 0 || value.includes(" "))
    return false;
  const normalized = NormalizeHostname(value);
  if (normalized.length > 253)
    return false;
  const labels = normalized.split(".");
  const hasBidiChars = labels.some((label) => HasBidiChars(label));
  return labels.every((label) => IsLabel2(label) && (!hasBidiChars || SatisfiesBidiRule(label)));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/hostname.mjs
function IsHostname2(value) {
  return IsHostname(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idn_email.mjs
var IdnEmail = new RegExp('^(?:[A-Za-z0-9!#$%&\'*+\\/=?^_`{|}~\\u{0080}-\\u{10FFFF}-]+(?:\\.[A-Za-z0-9!#$%&\'*+\\/=?^_`{|}~\\u{0080}-\\u{10FFFF}-]+)*|"(?:[^"\\\\]|\\\\.)*")@[\\p{L}\\p{N}](?:[\\p{L}\\p{N}-]{0,62})(?<!-)(?:\\.[\\p{L}\\p{N}](?:[\\p{L}\\p{N}-]{0,62})(?<!-))*$', "iu");
function IsIdnEmail(value) {
  return IdnEmail.test(value.normalize("NFC"));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/idn_hostname.mjs
function IsIdnHostname2(value) {
  return IsIdnHostname(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/ipv4.mjs
var IPv4 = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
function IsIPv4(value) {
  return IPv4.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/ipv6.mjs
var IPv6 = /^(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:)?[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)$/i;
function IsIPv6(value) {
  return IPv6.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/iri_reference.mjs
var InvalidIriChars = /[\x00-\x20\x7F\\]|%(?![0-9a-fA-F]{2})/;
var MalformedScheme = /^[a-zA-Z][a-zA-Z0-9+\-.]*\/\//;
function IsIriReference(value) {
  return !InvalidIriChars.test(value) && !MalformedScheme.test(value) && URL.canParse(value, "http://example.com");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/iri.mjs
var IpvFutureMatchMaxLength = 2048;
var IpvFutureMatch = /\[[vV][0-9a-fA-F]+\.[^\]]+\]/;
var InvalidIriChars2 = /[\x00-\x20<>\^`{|}\\]/;
var InvalidPercentEncoding = /%(?![0-9a-fA-F]{2})/;
function NarrowIpvFuture(value) {
  return value.length < IpvFutureMatchMaxLength ? value.replace(IpvFutureMatch, "[::1]") : value;
}
function IsIri(value) {
  if (InvalidIriChars2.test(value))
    return false;
  if (InvalidPercentEncoding.test(value))
    return false;
  return URL.canParse(NarrowIpvFuture(value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/json_pointer_uri_fragment.mjs
var JsonPointerUriFragment = /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i;
function IsJsonPointerUriFragment(value) {
  return JsonPointerUriFragment.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/json_pointer.mjs
var JsonPointer = /^(?:\/(?:[^~/]|~0|~1)*)*$/;
function IsJsonPointer(value) {
  return JsonPointer.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/regex.mjs
function IsRegex(value) {
  try {
    new RegExp(value, "u");
    return true;
  } catch {
    return false;
  }
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/relative_json_pointer.mjs
var RelativeJsonPointer = /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/;
function IsRelativeJsonPointer(value) {
  return RelativeJsonPointer.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/uri_reference.mjs
var UriReference = /^(?:[a-z][a-z0-9+\-.]*:(?:\/\/(?:(?:[-a-z0-9._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:[\da-f]{1,4}:){6}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|::(?:[\da-f]{1,4}:){5}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:[\da-f]{1,4})?::(?:[\da-f]{1,4}:){4}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,1}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){3}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,2}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){2}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,3}[\da-f]{1,4})?::[\da-f]{1,4}:(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,4}[\da-f]{1,4})?::(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,5}[\da-f]{1,4})?::[\da-f]{1,4}|(?:(?:[\da-f]{1,4}:){0,6}[\da-f]{1,4})?::)|v[0-9a-f]+\.[-a-z0-9._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)|(?:[-a-z0-9._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:\/\/(?:(?:[-a-z0-9._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:[\da-f]{1,4}:){6}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|::(?:[\da-f]{1,4}:){5}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:[\da-f]{1,4})?::(?:[\da-f]{1,4}:){4}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,1}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){3}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,2}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){2}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,3}[\da-f]{1,4})?::[\da-f]{1,4}:(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,4}[\da-f]{1,4})?::(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,5}[\da-f]{1,4})?::[\da-f]{1,4}|(?:(?:[\da-f]{1,4}:){0,6}[\da-f]{1,4})?::)|v[0-9a-f]+\.[-a-z0-9._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)|(?:[-a-z0-9._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[-a-z0-9._~!$&'()*+,;=@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?)(?:\?(?:[-a-z0-9._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[-a-z0-9._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
function IsUriReference(value) {
  return UriReference.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/uri_template.mjs
var UriTemplate = /^(?:(?:[^\x00-\x20"<>%\\^`{|}\x7f]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?:\.(?:[a-z0-9_]|%[0-9a-f]{2})+)*(?::[1-9]\d{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?:\.(?:[a-z0-9_]|%[0-9a-f]{2})+)*(?::[1-9]\d{0,3}|\*)?)*\})*$/i;
function IsUriTemplate(value) {
  return UriTemplate.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/uri.mjs
var Uri = /^[a-z][a-z0-9+\-.]*:(?:\/\/(?:(?:[-a-z0-9._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:[\da-f]{1,4}:){6}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|::(?:[\da-f]{1,4}:){5}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:[\da-f]{1,4})?::(?:[\da-f]{1,4}:){4}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,1}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){3}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,2}[\da-f]{1,4})?::(?:[\da-f]{1,4}:){2}(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,3}[\da-f]{1,4})?::[\da-f]{1,4}:(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,4}[\da-f]{1,4})?::(?:[\da-f]{1,4}:[\da-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d))|(?:(?:[\da-f]{1,4}:){0,5}[\da-f]{1,4})?::[\da-f]{1,4}|(?:(?:[\da-f]{1,4}:){0,6}[\da-f]{1,4})?::)|v[0-9a-f]+\.[-a-z0-9._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)|(?:[-a-z0-9._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[-a-z0-9._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[-a-z0-9._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[-a-z0-9._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
function IsUri(value) {
  return Uri.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/url.mjs
function IsUrl(value) {
  return URL.canParse(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/uuid.mjs
var Uuid = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
function IsUuid(value) {
  return Uuid.test(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/format/_registry.mjs
var formats = /* @__PURE__ */ new Map();
function Clear() {
  formats.clear();
}
function Entries() {
  return [...formats.entries()];
}
function Set2(format, check) {
  formats.set(format, check);
}
function Has(format) {
  return formats.has(format);
}
function Get2(format) {
  return formats.get(format);
}
function Test(format, value) {
  return formats.get(format)?.(value) ?? true;
}
function Reset() {
  Clear();
  formats.set("date-time", IsDateTime);
  formats.set("date", IsDate);
  formats.set("duration", IsDuration);
  formats.set("email", IsEmail);
  formats.set("hostname", IsHostname2);
  formats.set("idn-email", IsIdnEmail);
  formats.set("idn-hostname", IsIdnHostname2);
  formats.set("ipv4", IsIPv4);
  formats.set("ipv6", IsIPv6);
  formats.set("iri-reference", IsIriReference);
  formats.set("iri", IsIri);
  formats.set("json-pointer-uri-fragment", IsJsonPointerUriFragment);
  formats.set("json-pointer", IsJsonPointer);
  formats.set("regex", IsRegex);
  formats.set("relative-json-pointer", IsRelativeJsonPointer);
  formats.set("time", IsTime);
  formats.set("uri-reference", IsUriReference);
  formats.set("uri-template", IsUriTemplate);
  formats.set("uri", IsUri);
  formats.set("url", IsUrl);
  formats.set("uuid", IsUuid);
}
Reset();

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/format.mjs
function BuildFormat(_stack, _context, schema, value) {
  return emit_exports.Call(emit_exports.Member("Format", "Test"), [emit_exports.Constant(schema.format), value]);
}
function CheckFormat(_stack, _context, schema, value) {
  return format_exports.Test(schema.format, value);
}
function ErrorFormat(stack, context, schemaPath, instancePath, schema, value) {
  return CheckFormat(stack, context, schema, value) || context.AddError({
    keyword: "format",
    schemaPath,
    instancePath,
    params: { format: schema.format }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/if.mjs
function BuildIf(stack, context, schema, value) {
  const thenSchema = IsThen(schema) ? schema.then : true;
  const elseSchema = IsElse(schema) ? schema.else : true;
  return emit_exports.Ternary(BuildSchema(stack, context, schema.if, value), BuildSchema(stack, context, thenSchema, value), BuildSchema(stack, context, elseSchema, value));
}
function CheckIf(stack, context, schema, value) {
  const thenSchema = IsThen(schema) ? schema.then : true;
  const elseSchema = IsElse(schema) ? schema.else : true;
  return CheckSchema(stack, context, schema.if, value) ? CheckSchema(stack, context, thenSchema, value) : CheckSchema(stack, context, elseSchema, value);
}
function ErrorIf(stack, context, schemaPath, instancePath, schema, value) {
  const thenSchema = IsThen(schema) ? schema.then : true;
  const elseSchema = IsElse(schema) ? schema.else : true;
  const trueContext = new ErrorContext();
  const isIf = ErrorSchema(stack, trueContext, `${schemaPath}/if`, instancePath, schema.if, value) ? ErrorSchema(stack, trueContext, `${schemaPath}/then`, instancePath, thenSchema, value) || context.AddError({
    keyword: "if",
    schemaPath,
    instancePath,
    params: { failingKeyword: "then" }
  }) : ErrorSchema(stack, context, `${schemaPath}/else`, instancePath, elseSchema, value) || context.AddError({
    keyword: "if",
    schemaPath,
    instancePath,
    params: { failingKeyword: "else" }
  });
  if (isIf)
    context.Merge([trueContext]);
  return isIf;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/items.mjs
function BuildItemsSizedStandard(stack, context, schema, value) {
  return emit_exports.ReduceAnd(schema.items.map((schema2, index3) => {
    const isLength = emit_exports.IsLessEqualThan(emit_exports.Member(value, "length"), emit_exports.Constant(index3));
    const isSchema = BuildSchemaPushStack(stack, context, schema2, `${value}[${index3}]`);
    const addIndex = context.AddIndex(emit_exports.Constant(index3));
    return emit_exports.Or(isLength, emit_exports.And(isSchema, addIndex));
  }));
}
function BuildItemsSizedFast(stack, context, schema, value) {
  return emit_exports.ReduceAnd(schema.items.map((schema2, index3) => {
    const isLength = emit_exports.IsLessEqualThan(emit_exports.Member(value, "length"), emit_exports.Constant(index3));
    const isSchema = BuildSchemaPushStack(stack, context, schema2, `${value}[${index3}]`);
    return emit_exports.Or(isLength, isSchema);
  }));
}
function BuildItemsSized(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildItemsSizedStandard(stack, context, schema, value) : BuildItemsSizedFast(stack, context, schema, value);
}
function CheckItemsSized(stack, context, schema, value) {
  return guard_exports.Every(schema.items, 0, (schema2, index3) => {
    return guard_exports.IsLessEqualThan(value.length, index3) || CheckSchemaPushStack(stack, context, schema2, value[index3]) && context.AddIndex(index3);
  });
}
function ErrorItemsSized(stack, context, schemaPath, instancePath, schema, value) {
  return guard_exports.EveryAll(schema.items, 0, (schema2, index3) => {
    const nextSchemaPath = `${schemaPath}/items/${index3}`;
    const nextInstancePath = `${instancePath}/${index3}`;
    return guard_exports.IsLessEqualThan(value.length, index3) || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema2, value[index3]) && context.AddIndex(index3);
  });
}
function BuildItemsUnsizedStandard(stack, context, schema, value) {
  const offset = IsPrefixItems(schema) ? schema.prefixItems.length : 0;
  const isSchema = BuildSchemaPushStack(stack, context, schema.items, "element");
  const addIndex = context.AddIndex("index");
  return emit_exports.Every(value, emit_exports.Constant(offset), ["element", "index"], emit_exports.And(isSchema, addIndex));
}
function BuildItemsUnsizedFast(stack, context, schema, value) {
  const offset = IsPrefixItems(schema) ? schema.prefixItems.length : 0;
  const isSchema = BuildSchemaPushStack(stack, context, schema.items, "element");
  return emit_exports.Every(value, emit_exports.Constant(offset), ["element", "index"], isSchema);
}
function BuildItemsUnsized(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildItemsUnsizedStandard(stack, context, schema, value) : BuildItemsUnsizedFast(stack, context, schema, value);
}
function CheckItemsUnsized(stack, context, schema, value) {
  const offset = IsPrefixItems(schema) ? schema.prefixItems.length : 0;
  return guard_exports.Every(value, offset, (element, index3) => {
    return CheckSchemaPushStack(stack, context, schema.items, element) && context.AddIndex(index3);
  });
}
function ErrorItemsUnsized(stack, context, schemaPath, instancePath, schema, value) {
  const offset = IsPrefixItems(schema) ? schema.prefixItems.length : 0;
  return guard_exports.EveryAll(value, offset, (element, index3) => {
    const nextSchemaPath = `${schemaPath}/items`;
    const nextInstancePath = `${instancePath}/${index3}`;
    return ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema.items, element) && context.AddIndex(index3);
  });
}
function BuildItems(stack, context, schema, value) {
  return IsItemsSized(schema) ? BuildItemsSized(stack, context, schema, value) : BuildItemsUnsized(stack, context, schema, value);
}
function CheckItems(stack, context, schema, value) {
  return IsItemsSized(schema) ? CheckItemsSized(stack, context, schema, value) : CheckItemsUnsized(stack, context, schema, value);
}
function ErrorItems(stack, context, schemaPath, instancePath, schema, value) {
  return IsItemsSized(schema) ? ErrorItemsSized(stack, context, schemaPath, instancePath, schema, value) : ErrorItemsUnsized(stack, context, schemaPath, instancePath, schema, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/maxContains.mjs
function IsValid3(schema) {
  return IsContains(schema);
}
function BuildMaxContains(stack, context, schema, value) {
  if (!IsValid3(schema))
    return emit_exports.Constant(true);
  const [item] = [Unique()];
  const count = emit_exports.Counted(value, [item, "_"], BuildSchema(stack, context, schema.contains, item));
  return emit_exports.IsLessEqualThan(count, emit_exports.Constant(schema.maxContains));
}
function CheckMaxContains(stack, context, schema, value) {
  if (!IsValid3(schema))
    return true;
  const count = guard_exports.Counted(value, (item) => CheckSchema(stack, context, schema.contains, item));
  return guard_exports.IsLessEqualThan(count, schema.maxContains);
}
function ErrorMaxContains(stack, context, schemaPath, instancePath, schema, value) {
  const minContains = IsMinContains(schema) ? schema.minContains : 1;
  return CheckMaxContains(stack, context, schema, value) || context.AddError({
    keyword: "contains",
    schemaPath,
    instancePath,
    params: { minContains, maxContains: schema.maxContains }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/maximum.mjs
function BuildMaximum(_stack, _context, schema, value) {
  return emit_exports.IsLessEqualThan(value, emit_exports.Constant(schema.maximum));
}
function CheckMaximum(_stack, _context, schema, value) {
  return guard_exports.IsLessEqualThan(value, schema.maximum);
}
function ErrorMaximum(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMaximum(stack, context, schema, value) || context.AddError({
    keyword: "maximum",
    schemaPath,
    instancePath,
    params: { comparison: "<=", limit: schema.maximum }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/maxItems.mjs
function BuildMaxItems(_stack, _context, schema, value) {
  return emit_exports.IsLessEqualThan(emit_exports.Member(value, "length"), emit_exports.Constant(schema.maxItems));
}
function CheckMaxItems(_stack, _context, schema, value) {
  return guard_exports.IsLessEqualThan(value.length, schema.maxItems);
}
function ErrorMaxItems(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMaxItems(stack, context, schema, value) || context.AddError({
    keyword: "maxItems",
    schemaPath,
    instancePath,
    params: { limit: schema.maxItems }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/maxLength.mjs
function BuildMaxLength(_stack, _context, schema, value) {
  return emit_exports.IsMaxLength(value, emit_exports.Constant(schema.maxLength));
}
function CheckMaxLength(_stack, _context, schema, value) {
  return guard_exports.IsMaxLength(value, schema.maxLength);
}
function ErrorMaxLength(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMaxLength(stack, context, schema, value) || context.AddError({
    keyword: "maxLength",
    schemaPath,
    instancePath,
    params: { limit: schema.maxLength }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/maxProperties.mjs
function BuildMaxProperties(_stack, _context, schema, value) {
  return emit_exports.IsLessEqualThan(emit_exports.Member(emit_exports.Keys(value), "length"), emit_exports.Constant(schema.maxProperties));
}
function CheckMaxProperties(_stack, _context, schema, value) {
  return guard_exports.IsLessEqualThan(guard_exports.Keys(value).length, schema.maxProperties);
}
function ErrorMaxProperties(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMaxProperties(stack, context, schema, value) || context.AddError({
    keyword: "maxProperties",
    schemaPath,
    instancePath,
    params: { limit: schema.maxProperties }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/minContains.mjs
function IsValid4(schema) {
  return IsContains(schema);
}
function BuildMinContainsStandard(stack, context, schema, value) {
  const [item, index3] = [Unique(), Unique()];
  const count = emit_exports.Counted(value, [item, index3], emit_exports.And(BuildSchema(stack, context, schema.contains, item), context.AddIndex(index3)));
  return emit_exports.IsGreaterEqualThan(count, emit_exports.Constant(schema.minContains));
}
function BuildMinContainsFast(stack, context, schema, value) {
  const [item] = [Unique()];
  const count = emit_exports.Counted(value, [item, "_"], BuildSchema(stack, context, schema.contains, item));
  return emit_exports.IsGreaterEqualThan(count, emit_exports.Constant(schema.minContains));
}
function BuildMinContains(stack, context, schema, value) {
  if (!IsValid4(schema))
    return emit_exports.Constant(true);
  return context.UseUnevaluated() ? BuildMinContainsStandard(stack, context, schema, value) : BuildMinContainsFast(stack, context, schema, value);
}
function CheckMinContains(stack, context, schema, value) {
  if (!IsValid4(schema))
    return true;
  const count = guard_exports.Counted(value, (item, index3) => CheckSchema(stack, context, schema.contains, item) && context.AddIndex(index3));
  return guard_exports.IsGreaterEqualThan(count, schema.minContains);
}
function ErrorMinContains(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMinContains(stack, context, schema, value) || context.AddError({
    keyword: "contains",
    schemaPath,
    instancePath,
    params: { minContains: schema.minContains }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/minimum.mjs
function BuildMinimum(_stack, _context, schema, value) {
  return emit_exports.IsGreaterEqualThan(value, emit_exports.Constant(schema.minimum));
}
function CheckMinimum(_stack, _context, schema, value) {
  return guard_exports.IsGreaterEqualThan(value, schema.minimum);
}
function ErrorMinimum(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMinimum(stack, context, schema, value) || context.AddError({
    keyword: "minimum",
    schemaPath,
    instancePath,
    params: { comparison: ">=", limit: schema.minimum }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/minItems.mjs
function BuildMinItems(_stack, _context, schema, value) {
  return emit_exports.IsGreaterEqualThan(emit_exports.Member(value, "length"), emit_exports.Constant(schema.minItems));
}
function CheckMinItems(_stack, _context, schema, value) {
  return guard_exports.IsGreaterEqualThan(value.length, schema.minItems);
}
function ErrorMinItems(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMinItems(stack, context, schema, value) || context.AddError({
    keyword: "minItems",
    schemaPath,
    instancePath,
    params: { limit: schema.minItems }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/minLength.mjs
function BuildMinLength(_stack, _context, schema, value) {
  return emit_exports.IsMinLength(value, emit_exports.Constant(schema.minLength));
}
function CheckMinLength(_stack, _context, schema, value) {
  return guard_exports.IsMinLength(value, schema.minLength);
}
function ErrorMinLength(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMinLength(stack, context, schema, value) || context.AddError({
    keyword: "minLength",
    schemaPath,
    instancePath,
    params: { limit: schema.minLength }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/minProperties.mjs
function BuildMinProperties(_stack, _context, schema, value) {
  return emit_exports.IsGreaterEqualThan(emit_exports.Member(emit_exports.Keys(value), "length"), emit_exports.Constant(schema.minProperties));
}
function CheckMinProperties(_stack, _context, schema, value) {
  return guard_exports.IsGreaterEqualThan(guard_exports.Keys(value).length, schema.minProperties);
}
function ErrorMinProperties(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMinProperties(stack, context, schema, value) || context.AddError({
    keyword: "minProperties",
    schemaPath,
    instancePath,
    params: { limit: schema.minProperties }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/multipleOf.mjs
function BuildMultipleOf(_stack, _context, schema, value) {
  return emit_exports.MultipleOf(value, emit_exports.Constant(schema.multipleOf));
}
function CheckMultipleOf(_stack, _context, schema, value) {
  return guard_exports.IsMultipleOf(value, schema.multipleOf);
}
function ErrorMultipleOf(stack, context, schemaPath, instancePath, schema, value) {
  return CheckMultipleOf(stack, context, schema, value) || context.AddError({
    keyword: "multipleOf",
    schemaPath,
    instancePath,
    params: { multipleOf: schema.multipleOf }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/not.mjs
function BuildNotStandard(stack, context, schema, value) {
  return Reducer(stack, context, [schema.not], value, emit_exports.Not(emit_exports.IsEqual(emit_exports.Member("results", "length"), emit_exports.Constant(1))));
}
function BuildNotFast(stack, context, schema, value) {
  return emit_exports.Not(BuildSchema(stack, context, schema.not, value));
}
function BuildNot(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildNotStandard(stack, context, schema, value) : BuildNotFast(stack, context, schema, value);
}
function CheckNot(stack, context, schema, value) {
  const nextContext = new CheckContext();
  const isSchema = !CheckSchema(stack, nextContext, schema.not, value);
  const isNot = isSchema && context.Merge([nextContext]);
  return isNot;
}
function ErrorNot(stack, context, schemaPath, instancePath, schema, value) {
  return CheckNot(stack, context, schema, value) || context.AddError({
    keyword: "not",
    schemaPath,
    instancePath,
    params: {}
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/oneOf.mjs
function BuildOneOfStandard(stack, context, schema, value) {
  return Reducer(stack, context, schema.oneOf, value, emit_exports.IsEqual(emit_exports.Member("results", "length"), emit_exports.Constant(1)));
}
function BuildOneOfFast(stack, context, schema, value) {
  const [result] = [Unique()];
  const results = emit_exports.ArrayLiteral(schema.oneOf.map((schema2) => BuildSchema(stack, context, schema2, value)));
  const count = emit_exports.Counted(results, [result, "_"], emit_exports.IsEqual(result, emit_exports.Constant(true)));
  return emit_exports.IsEqual(count, emit_exports.Constant(1));
}
function BuildOneOf(stack, context, schema, value) {
  return context.UseUnevaluated() ? BuildOneOfStandard(stack, context, schema, value) : BuildOneOfFast(stack, context, schema, value);
}
function CheckOneOf(stack, context, schema, value) {
  const passedContexts = schema.oneOf.reduce((result, schema2) => {
    const nextContext = new CheckContext();
    return CheckSchema(stack, nextContext, schema2, value) ? [...result, nextContext] : result;
  }, []);
  return guard_exports.IsEqual(passedContexts.length, 1) && context.Merge(passedContexts);
}
function ErrorOneOf(stack, context, schemaPath, instancePath, schema, value) {
  const failedContexts = [];
  const passingSchemas = [];
  const passedContexts = schema.oneOf.reduce((result, schema2, index3) => {
    const nextContext = new ErrorContext();
    const nextSchemaPath = `${schemaPath}/oneOf/${index3}`;
    const isSchema = ErrorSchema(stack, nextContext, nextSchemaPath, instancePath, schema2, value);
    if (isSchema)
      passingSchemas.push(index3);
    if (!isSchema)
      failedContexts.push(nextContext);
    return isSchema ? [...result, nextContext] : result;
  }, []);
  const isOneOf = guard_exports.IsEqual(passedContexts.length, 1) && context.Merge(passedContexts);
  if (!isOneOf && guard_exports.IsEqual(passingSchemas.length, 0))
    failedContexts.forEach((failed) => failed.GetErrors().forEach((error) => context.AddError(error)));
  return isOneOf || context.AddError({
    keyword: "oneOf",
    schemaPath,
    instancePath,
    params: { passingSchemas }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/pattern.mjs
function BuildPattern(_stack, _context, schema, value) {
  const regexp = CreateVariable(guard_exports.IsString(schema.pattern) ? UnicodeRegExp(schema.pattern) : schema.pattern);
  return emit_exports.Call(emit_exports.Member(regexp, "test"), [value]);
}
function CheckPattern(_stack, _context, schema, value) {
  const regexp = guard_exports.IsString(schema.pattern) ? UnicodeRegExp(schema.pattern) : schema.pattern;
  return regexp.test(value);
}
function ErrorPattern(stack, context, schemaPath, instancePath, schema, value) {
  return CheckPattern(stack, context, schema, value) || context.AddError({
    keyword: "pattern",
    schemaPath,
    instancePath,
    params: { pattern: schema.pattern }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/patternProperties.mjs
function BuildPatternProperties(stack, context, schema, value) {
  return emit_exports.ReduceAnd(guard_exports.Entries(schema.patternProperties).map(([pattern, schema2]) => {
    const [key, prop] = [Unique(), Unique()];
    const regexp = CreateVariable(UnicodeRegExp(pattern));
    const notKey = emit_exports.Not(emit_exports.Call(emit_exports.Member(regexp, "test"), [key]));
    const isSchema = BuildSchemaPushStack(stack, context, schema2, prop);
    const addKey = context.AddKey(key);
    const guarded = context.UseUnevaluated() ? emit_exports.Or(notKey, emit_exports.And(isSchema, addKey)) : emit_exports.Or(notKey, isSchema);
    return emit_exports.Every(emit_exports.Entries(value), emit_exports.Constant(0), [`[${key}, ${prop}]`, "_"], guarded);
  }));
}
function CheckPatternProperties(stack, context, schema, value) {
  return guard_exports.Every(guard_exports.Entries(schema.patternProperties), 0, ([pattern, schema2]) => {
    const regexp = UnicodeRegExp(pattern);
    return guard_exports.Every(guard_exports.Entries(value), 0, ([key, prop]) => {
      return !regexp.test(key) || CheckSchemaPushStack(stack, context, schema2, prop) && context.AddKey(key);
    });
  });
}
function ErrorPatternProperties(stack, context, schemaPath, instancePath, schema, value) {
  return guard_exports.EveryAll(guard_exports.Entries(schema.patternProperties), 0, ([pattern, schema2]) => {
    const nextSchemaPath = `${schemaPath}/patternProperties/${pattern}`;
    const regexp = UnicodeRegExp(pattern);
    return guard_exports.EveryAll(guard_exports.Entries(value), 0, ([key, value2]) => {
      const nextInstancePath = `${instancePath}/${key}`;
      const notKey = !regexp.test(key);
      return notKey || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema2, value2) && context.AddKey(key);
    });
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/prefixItems.mjs
function BuildPrefixItems(stack, context, schema, value) {
  return emit_exports.ReduceAnd(schema.prefixItems.map((schema2, index3) => {
    const isLength = emit_exports.IsLessEqualThan(emit_exports.Member(value, "length"), emit_exports.Constant(index3));
    const isSchema = BuildSchemaPushStack(stack, context, schema2, `${value}[${index3}]`);
    const addIndex = context.AddIndex(emit_exports.Constant(index3));
    const guarded = context.UseUnevaluated() ? emit_exports.And(isSchema, addIndex) : isSchema;
    return emit_exports.Or(isLength, guarded);
  }));
}
function CheckPrefixItems(stack, context, schema, value) {
  return guard_exports.IsEqual(value.length, 0) || guard_exports.Every(schema.prefixItems, 0, (schema2, index3) => {
    return guard_exports.IsLessEqualThan(value.length, index3) || CheckSchemaPushStack(stack, context, schema2, value[index3]) && context.AddIndex(index3);
  });
}
function ErrorPrefixItems(stack, context, schemaPath, instancePath, schema, value) {
  return guard_exports.IsEqual(value.length, 0) || guard_exports.EveryAll(schema.prefixItems, 0, (schema2, index3) => {
    const nextSchemaPath = `${schemaPath}/prefixItems/${index3}`;
    const nextInstancePath = `${instancePath}/${index3}`;
    return guard_exports.IsLessEqualThan(value.length, index3) || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema2, value[index3]) && context.AddIndex(index3);
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_exact_optional.mjs
function IsExactOptional(required, key) {
  return required.includes(key) || settings_exports.Get().exactOptionalPropertyTypes;
}
function InexactOptionalBuild(value, key) {
  return emit_exports.IsUndefined(emit_exports.Member(value, key));
}
function InexactOptionalCheck(value, key) {
  return guard_exports.IsUndefined(value[key]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/properties.mjs
function BuildProperties(stack, context, schema, value) {
  const required = IsRequired(schema) ? schema.required : [];
  const everyKey = guard_exports.Entries(schema.properties).map(([key, schema2]) => {
    const notKey = emit_exports.Not(emit_exports.HasPropertyKey(value, emit_exports.Constant(key)));
    const isSchema = BuildSchemaPushStack(stack, context, schema2, emit_exports.Member(value, key));
    const addKey = context.AddKey(emit_exports.Constant(key));
    const guarded = context.UseUnevaluated() ? emit_exports.And(isSchema, addKey) : isSchema;
    const isProperty = required.includes(key) ? guarded : emit_exports.Or(notKey, guarded);
    return IsExactOptional(required, key) ? isProperty : emit_exports.Or(InexactOptionalBuild(value, key), isProperty);
  });
  return emit_exports.ReduceAnd(everyKey);
}
function CheckProperties(stack, context, schema, value) {
  const required = IsRequired(schema) ? schema.required : [];
  const isProperties = guard_exports.Every(guard_exports.Entries(schema.properties), 0, ([key, schema2]) => {
    const isProperty = !guard_exports.HasPropertyKey(value, key) || CheckSchemaPushStack(stack, context, schema2, value[key]) && context.AddKey(key);
    return IsExactOptional(required, key) ? isProperty : InexactOptionalCheck(value, key) || isProperty;
  });
  return isProperties;
}
function ErrorProperties(stack, context, schemaPath, instancePath, schema, value) {
  const required = IsRequired(schema) ? schema.required : [];
  const isProperties = guard_exports.EveryAll(guard_exports.Entries(schema.properties), 0, ([key, schema2]) => {
    const nextSchemaPath = `${schemaPath}/properties/${key}`;
    const nextInstancePath = `${instancePath}/${key}`;
    const isProperty = () => !guard_exports.HasPropertyKey(value, key) || ErrorSchemaPushStack(stack, context, nextSchemaPath, nextInstancePath, schema2, value[key]) && context.AddKey(key);
    return IsExactOptional(required, key) ? isProperty() : InexactOptionalCheck(value, key) || isProperty();
  });
  return isProperties;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/propertyNames.mjs
function BuildPropertyNames(stack, context, schema, value) {
  const [key, _index] = [Unique(), Unique()];
  return emit_exports.Every(emit_exports.Keys(value), emit_exports.Constant(0), [key, _index], BuildSchema(stack, context, schema.propertyNames, key));
}
function CheckPropertyNames(stack, context, schema, value) {
  return guard_exports.Every(guard_exports.Keys(value), 0, (key, _index) => CheckSchema(stack, context, schema.propertyNames, key));
}
function ErrorPropertyNames(stack, context, schemaPath, instancePath, schema, value) {
  const propertyNames = [];
  const isPropertyNames = guard_exports.EveryAll(guard_exports.Keys(value), 0, (key, _index) => {
    const nextInstancePath = `${instancePath}/${key}`;
    const nextSchemaPath = `${schemaPath}/propertyNames`;
    const isPropertyName = ErrorSchema(stack, context, nextSchemaPath, nextInstancePath, schema.propertyNames, key);
    if (!isPropertyName)
      propertyNames.push(key);
    return isPropertyName;
  });
  return isPropertyNames || context.AddError({
    keyword: "propertyNames",
    schemaPath,
    instancePath,
    params: { propertyNames }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/recursiveRef.mjs
function BuildRecursiveRef(stack, context, schema, value) {
  const target = stack.RecursiveRef(schema) ?? false;
  return CreateFunction(stack, context, target, value);
}
function CheckRecursiveRef(stack, context, schema, value) {
  const target = stack.RecursiveRef(schema) ?? false;
  return IsSchema2(target) && CheckSchema(stack, context, target, value);
}
function ErrorRecursiveRef(stack, context, _schemaPath, instancePath, schema, value) {
  const target = stack.RecursiveRef(schema) ?? false;
  return IsSchema2(target) && ErrorSchema(stack, context, "#", instancePath, target, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/ref.mjs
function BuildRefStandard(stack, context, target, value) {
  const interior = emit_exports.ArrowFunction(["context", "value"], CreateFunction(stack, context, target, "value"));
  const exterior = emit_exports.ArrowFunction(["context", "value"], emit_exports.Statements([
    emit_exports.ConstDeclaration("nextContext", emit_exports.New("CheckContext", [])),
    emit_exports.ConstDeclaration("result", emit_exports.Call(interior, ["nextContext", "value"])),
    emit_exports.If("result", context.Merge("[nextContext]")),
    emit_exports.Return("result")
  ]));
  return emit_exports.Call(exterior, ["context", value]);
}
function BuildRefFast(stack, context, target, value) {
  return CreateFunction(stack, context, target, value);
}
function BuildRef(stack, context, schema, value) {
  const target = stack.Ref(schema) ?? false;
  return context.UseUnevaluated() ? BuildRefStandard(stack, context, target, value) : BuildRefFast(stack, context, target, value);
}
function CheckRef(stack, context, schema, value) {
  const target = stack.Ref(schema) ?? false;
  const nextContext = new CheckContext();
  const result = IsSchema2(target) && CheckSchema(stack, nextContext, target, value);
  if (result)
    context.Merge([nextContext]);
  return result;
}
function ErrorRef(stack, context, _schemaPath, instancePath, schema, value) {
  const target = stack.Ref(schema) ?? false;
  const nextContext = new ErrorContext();
  const result = IsSchema2(target) && ErrorSchema(stack, nextContext, "#", instancePath, target, value);
  if (result)
    context.Merge([nextContext]);
  if (!result)
    nextContext.GetErrors().forEach((error) => context.AddError(error));
  return result;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/required.mjs
function BuildRequired(_stack, _context, schema, value) {
  return emit_exports.ReduceAnd(schema.required.map((key) => emit_exports.HasPropertyKey(value, emit_exports.Constant(key))));
}
function CheckRequired(_stack, _context, schema, value) {
  return guard_exports.Every(schema.required, 0, (key) => guard_exports.HasPropertyKey(value, key));
}
function ErrorRequired(_stack, context, schemaPath, instancePath, schema, value) {
  const requiredProperties = [];
  const isRequired = guard_exports.EveryAll(schema.required, 0, (key) => {
    const hasKey = guard_exports.HasPropertyKey(value, key);
    if (!hasKey)
      requiredProperties.push(key);
    return hasKey;
  });
  return isRequired || context.AddError({
    keyword: "required",
    schemaPath,
    instancePath,
    params: { requiredProperties }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/type.mjs
function BuildTypeName(_stack, _context, type, value) {
  return (
    // jsonschema
    guard_exports.IsEqual(type, "object") ? emit_exports.IsObjectNotArray(value) : guard_exports.IsEqual(type, "array") ? emit_exports.IsArray(value) : guard_exports.IsEqual(type, "boolean") ? emit_exports.IsBoolean(value) : guard_exports.IsEqual(type, "integer") ? emit_exports.IsInteger(value) : guard_exports.IsEqual(type, "number") ? emit_exports.IsNumber(value) : guard_exports.IsEqual(type, "null") ? emit_exports.IsNull(value) : guard_exports.IsEqual(type, "string") ? emit_exports.IsString(value) : (
      // xschema
      guard_exports.IsEqual(type, "bigint") ? emit_exports.IsBigInt(value) : guard_exports.IsEqual(type, "constructor") ? emit_exports.IsConstructor(value) : guard_exports.IsEqual(type, "function") ? emit_exports.IsFunction(value) : guard_exports.IsEqual(type, "symbol") ? emit_exports.IsSymbol(value) : guard_exports.IsEqual(type, "undefined") ? emit_exports.IsUndefined(value) : guard_exports.IsEqual(type, "void") ? emit_exports.IsUndefined(value) : emit_exports.Constant(true)
    )
  );
}
function CheckTypeName(_stack, _context, type, _schema, value) {
  return (
    // jsonschema
    guard_exports.IsEqual(type, "object") ? guard_exports.IsObjectNotArray(value) : guard_exports.IsEqual(type, "array") ? guard_exports.IsArray(value) : guard_exports.IsEqual(type, "boolean") ? guard_exports.IsBoolean(value) : guard_exports.IsEqual(type, "integer") ? guard_exports.IsInteger(value) : guard_exports.IsEqual(type, "number") ? guard_exports.IsNumber(value) : guard_exports.IsEqual(type, "null") ? guard_exports.IsNull(value) : guard_exports.IsEqual(type, "string") ? guard_exports.IsString(value) : (
      // xschema
      guard_exports.IsEqual(type, "bigint") ? guard_exports.IsBigInt(value) : guard_exports.IsEqual(type, "constructor") ? guard_exports.IsConstructor(value) : guard_exports.IsEqual(type, "function") ? guard_exports.IsFunction(value) : guard_exports.IsEqual(type, "symbol") ? guard_exports.IsSymbol(value) : guard_exports.IsEqual(type, "undefined") ? guard_exports.IsUndefined(value) : guard_exports.IsEqual(type, "void") ? guard_exports.IsUndefined(value) : true
    )
  );
}
function BuildTypeNames(stack, context, typenames, value) {
  return emit_exports.ReduceOr(typenames.map((type) => BuildTypeName(stack, context, type, value)));
}
function CheckTypeNames(stack, context, types, schema, value) {
  return guard_exports.Some(types, (type) => CheckTypeName(stack, context, type, schema, value));
}
function BuildType(stack, context, schema, value) {
  return guard_exports.IsArray(schema.type) ? BuildTypeNames(stack, context, schema.type, value) : BuildTypeName(stack, context, schema.type, value);
}
function CheckType(stack, context, schema, value) {
  return guard_exports.IsArray(schema.type) ? CheckTypeNames(stack, context, schema.type, schema, value) : CheckTypeName(stack, context, schema.type, schema, value);
}
function ErrorType(stack, context, schemaPath, instancePath, schema, value) {
  const isType = guard_exports.IsArray(schema.type) ? CheckTypeNames(stack, context, schema.type, schema, value) : CheckTypeName(stack, context, schema.type, schema, value);
  return isType || context.AddError({
    keyword: "type",
    schemaPath,
    instancePath,
    params: { type: schema.type }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/unevaluatedItems.mjs
function BuildUnevaluatedItems(stack, context, schema, value) {
  const [index3, item] = [Unique(), Unique()];
  const indices = emit_exports.Call(emit_exports.Member("context", "GetIndices"), []);
  const hasIndex = emit_exports.Call(emit_exports.Member("indices", "has"), [index3]);
  const isSchema = BuildSchema(stack, context, schema.unevaluatedItems, item);
  const addIndex = emit_exports.Call(emit_exports.Member("context", "AddIndex"), [index3]);
  const isEvery = emit_exports.Every(value, emit_exports.Constant(0), [item, index3], emit_exports.And(emit_exports.Or(hasIndex, isSchema), addIndex));
  return emit_exports.Call(emit_exports.ArrowFunction(["context"], emit_exports.Statements([
    emit_exports.ConstDeclaration("indices", indices),
    emit_exports.Return(isEvery)
  ])), ["context"]);
}
function CheckUnevaluatedItems(stack, context, schema, value) {
  const indices = context.GetIndices();
  return guard_exports.Every(value, 0, (item, index3) => {
    return (indices.has(index3) || CheckSchema(stack, context, schema.unevaluatedItems, item)) && context.AddIndex(index3);
  });
}
function ErrorUnevaluatedItems(stack, context, schemaPath, instancePath, schema, value) {
  const indices = context.GetIndices();
  const unevaluatedItems = [];
  const isUnevaluatedItems = guard_exports.EveryAll(value, 0, (item, index3) => {
    const nextContext = new ErrorContext();
    const isEvaluatedItem = (indices.has(index3) || ErrorSchema(stack, nextContext, schemaPath, instancePath, schema.unevaluatedItems, item)) && context.AddIndex(index3);
    if (!isEvaluatedItem)
      unevaluatedItems.push(index3);
    return isEvaluatedItem;
  });
  return isUnevaluatedItems || context.AddError({
    keyword: "unevaluatedItems",
    schemaPath,
    instancePath,
    params: { unevaluatedItems }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/unevaluatedProperties.mjs
function BuildUnevaluatedProperties(stack, context, schema, value) {
  const [key, prop] = [Unique(), Unique()];
  const keys = emit_exports.Call(emit_exports.Member("context", "GetKeys"), []);
  const hasKey = emit_exports.Call(emit_exports.Member("keys", "has"), [key]);
  const addKey = emit_exports.Call(emit_exports.Member("context", "AddKey"), [key]);
  const isSchema = BuildSchema(stack, context, schema.unevaluatedProperties, prop);
  const isEvery = emit_exports.Every(emit_exports.Entries(value), emit_exports.Constant(0), [`[${key}, ${prop}]`, "_"], emit_exports.Or(hasKey, emit_exports.And(isSchema, addKey)));
  return emit_exports.Call(emit_exports.ArrowFunction(["context"], emit_exports.Statements([
    emit_exports.ConstDeclaration("keys", keys),
    emit_exports.Return(isEvery)
  ])), ["context"]);
}
function CheckUnevaluatedProperties(stack, context, schema, value) {
  const keys = context.GetKeys();
  return guard_exports.Every(guard_exports.Entries(value), 0, ([key, prop]) => {
    return keys.has(key) || CheckSchema(stack, context, schema.unevaluatedProperties, prop) && context.AddKey(key);
  });
}
function ErrorUnevaluatedProperties(stack, context, schemaPath, instancePath, schema, value) {
  const keys = context.GetKeys();
  const unevaluatedProperties = [];
  const isUnevaluatedProperties = guard_exports.EveryAll(guard_exports.Entries(value), 0, ([key, prop]) => {
    const nextContext = new ErrorContext();
    const isEvaluatedProperty = keys.has(key) || ErrorSchema(stack, nextContext, schemaPath, instancePath, schema.unevaluatedProperties, prop) && context.AddKey(key);
    if (!isEvaluatedProperty)
      unevaluatedProperties.push(key);
    return isEvaluatedProperty;
  });
  return isUnevaluatedProperties || context.AddError({
    keyword: "unevaluatedProperties",
    schemaPath,
    instancePath,
    params: { unevaluatedProperties }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/uniqueItems.mjs
function IsValid5(schema) {
  return !guard_exports.IsEqual(schema.uniqueItems, false);
}
function BuildUniqueItems(_stack, _context, schema, value) {
  if (!IsValid5(schema))
    return emit_exports.Constant(true);
  const set = emit_exports.Member(emit_exports.New("Set", [emit_exports.Call(emit_exports.Member(value, "map"), [emit_exports.Member("Hashing", "Hash")])]), "size");
  const isLength = emit_exports.Member(value, "length");
  return emit_exports.IsEqual(set, isLength);
}
function CheckUniqueItems(_stack, _context, schema, value) {
  if (!IsValid5(schema))
    return true;
  const set = new Set(value.map(hash_exports.Hash)).size;
  const isLength = value.length;
  return guard_exports.IsEqual(set, isLength);
}
function ErrorUniqueItems(_stack, context, schemaPath, instancePath, schema, value) {
  if (!IsValid5(schema))
    return true;
  const set = /* @__PURE__ */ new Set();
  const duplicateItems = value.reduce((result, value2, index3) => {
    const hash = hash_exports.Hash(value2);
    if (set.has(hash))
      return [...result, index3];
    set.add(hash);
    return result;
  }, []);
  const isUniqueItems = guard_exports.IsEqual(duplicateItems.length, 0);
  return isUniqueItems || context.AddError({
    keyword: "uniqueItems",
    schemaPath,
    instancePath,
    params: { duplicateItems }
  });
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/schema.mjs
function HasTypeName(schema, typename) {
  return IsType(schema) && (guard_exports.IsArray(schema.type) && guard_exports.IsGreaterThan(schema.type.length, 0) && guard_exports.Every(schema.type, 0, (type) => guard_exports.IsEqual(type, typename)) || guard_exports.IsEqual(schema.type, typename));
}
function HasObjectType(schema) {
  return HasTypeName(schema, "object");
}
function HasObjectKeywords(schema) {
  return IsSchemaObject(schema) && (IsAdditionalProperties(schema) || IsDependencies(schema) || IsDependentRequired(schema) || IsDependentSchemas(schema) || IsProperties(schema) || IsPatternProperties(schema) || IsPropertyNames(schema) || IsMinProperties(schema) || IsMaxProperties(schema) || IsRequired(schema) || IsUnevaluatedProperties(schema));
}
function HasArrayType(schema) {
  return HasTypeName(schema, "array");
}
function HasArrayKeywords(schema) {
  return IsSchemaObject(schema) && (IsAdditionalItems(schema) || IsItems(schema) || IsContains(schema) || IsMaxContains(schema) || IsMaxItems(schema) || IsMinContains(schema) || IsMinItems(schema) || IsPrefixItems(schema) || IsUnevaluatedItems(schema) || IsUniqueItems(schema));
}
function HasStringType(schema) {
  return HasTypeName(schema, "string");
}
function HasStringKeywords(schema) {
  return IsSchemaObject(schema) && (IsMinLength(schema) || IsMaxLength(schema) || IsFormat(schema) || IsPattern(schema));
}
function HasNumberType(schema) {
  return HasTypeName(schema, "number") || HasTypeName(schema, "bigint");
}
function HasNumberKeywords(schema) {
  return IsSchemaObject(schema) && (IsMinimum(schema) || IsMaximum(schema) || IsExclusiveMaximum(schema) || IsExclusiveMinimum(schema) || IsMultipleOf(schema));
}
function BuildSchemaPushStack(stack, context, schema, value) {
  return context.UseUnevaluated() ? emit_exports.And(emit_exports.And(context.Push(), BuildSchema(stack, context, schema, value)), context.Pop()) : BuildSchema(stack, context, schema, value);
}
function BuildSchema(stack, context, schema, value) {
  stack.Push(schema);
  const conditions = [];
  if (IsSchemaBoolean(schema))
    return BuildSchemaBoolean(stack, context, schema, value);
  if (IsType(schema))
    conditions.push(BuildType(stack, context, schema, value));
  if (HasObjectKeywords(schema)) {
    const constraints = [];
    if (IsRequired(schema))
      constraints.push(BuildRequired(stack, context, schema, value));
    if (IsAdditionalProperties(schema))
      constraints.push(BuildAdditionalProperties(stack, context, schema, value));
    if (IsDependencies(schema))
      constraints.push(BuildDependencies(stack, context, schema, value));
    if (IsDependentRequired(schema))
      constraints.push(BuildDependentRequired(stack, context, schema, value));
    if (IsDependentSchemas(schema))
      constraints.push(BuildDependentSchemas(stack, context, schema, value));
    if (IsPatternProperties(schema))
      constraints.push(BuildPatternProperties(stack, context, schema, value));
    if (IsProperties(schema))
      constraints.push(BuildProperties(stack, context, schema, value));
    if (IsPropertyNames(schema))
      constraints.push(BuildPropertyNames(stack, context, schema, value));
    if (IsMinProperties(schema))
      constraints.push(BuildMinProperties(stack, context, schema, value));
    if (IsMaxProperties(schema))
      constraints.push(BuildMaxProperties(stack, context, schema, value));
    const reduced = emit_exports.ReduceAnd(constraints);
    const guarded = emit_exports.Or(emit_exports.Not(emit_exports.IsObjectNotArray(value)), reduced);
    conditions.push(HasObjectType(schema) ? reduced : guarded);
  }
  if (HasArrayKeywords(schema)) {
    const constraints = [];
    if (IsAdditionalItems(schema))
      constraints.push(BuildAdditionalItems(stack, context, schema, value));
    if (IsContains(schema))
      constraints.push(BuildContains(stack, context, schema, value));
    if (IsItems(schema))
      constraints.push(BuildItems(stack, context, schema, value));
    if (IsMaxContains(schema))
      constraints.push(BuildMaxContains(stack, context, schema, value));
    if (IsMaxItems(schema))
      constraints.push(BuildMaxItems(stack, context, schema, value));
    if (IsMinContains(schema))
      constraints.push(BuildMinContains(stack, context, schema, value));
    if (IsMinItems(schema))
      constraints.push(BuildMinItems(stack, context, schema, value));
    if (IsPrefixItems(schema))
      constraints.push(BuildPrefixItems(stack, context, schema, value));
    if (IsUniqueItems(schema))
      constraints.push(BuildUniqueItems(stack, context, schema, value));
    const reduced = emit_exports.ReduceAnd(constraints);
    const guarded = emit_exports.Or(emit_exports.Not(emit_exports.IsArray(value)), reduced);
    conditions.push(HasArrayType(schema) ? reduced : guarded);
  }
  if (HasStringKeywords(schema)) {
    const constraints = [];
    if (IsMaxLength(schema))
      constraints.push(BuildMaxLength(stack, context, schema, value));
    if (IsMinLength(schema))
      constraints.push(BuildMinLength(stack, context, schema, value));
    if (IsFormat(schema))
      constraints.push(BuildFormat(stack, context, schema, value));
    if (IsPattern(schema))
      constraints.push(BuildPattern(stack, context, schema, value));
    const reduced = emit_exports.ReduceAnd(constraints);
    const guarded = emit_exports.Or(emit_exports.Not(emit_exports.IsString(value)), reduced);
    conditions.push(HasStringType(schema) ? reduced : guarded);
  }
  if (HasNumberKeywords(schema)) {
    const constraints = [];
    if (IsExclusiveMaximum(schema))
      constraints.push(BuildExclusiveMaximum(stack, context, schema, value));
    if (IsExclusiveMinimum(schema))
      constraints.push(BuildExclusiveMinimum(stack, context, schema, value));
    if (IsMaximum(schema))
      constraints.push(BuildMaximum(stack, context, schema, value));
    if (IsMinimum(schema))
      constraints.push(BuildMinimum(stack, context, schema, value));
    if (IsMultipleOf(schema))
      constraints.push(BuildMultipleOf(stack, context, schema, value));
    const reduced = emit_exports.ReduceAnd(constraints);
    const guarded = emit_exports.Or(emit_exports.Not(emit_exports.Or(emit_exports.IsNumber(value), emit_exports.IsBigInt(value))), reduced);
    conditions.push(HasNumberType(schema) ? reduced : guarded);
  }
  if (IsRef2(schema))
    conditions.push(BuildRef(stack, context, schema, value));
  if (IsRecursiveRef(schema))
    conditions.push(BuildRecursiveRef(stack, context, schema, value));
  if (IsDynamicRef(schema))
    conditions.push(BuildDynamicRef(stack, context, schema, value));
  if (IsConst(schema))
    conditions.push(BuildConst(stack, context, schema, value));
  if (IsEnum2(schema))
    conditions.push(BuildEnum(stack, context, schema, value));
  if (IsIf(schema))
    conditions.push(BuildIf(stack, context, schema, value));
  if (IsNot(schema))
    conditions.push(BuildNot(stack, context, schema, value));
  if (IsAllOf(schema))
    conditions.push(BuildAllOf(stack, context, schema, value));
  if (IsAnyOf(schema))
    conditions.push(BuildAnyOf(stack, context, schema, value));
  if (IsOneOf(schema))
    conditions.push(BuildOneOf(stack, context, schema, value));
  if (IsUnevaluatedItems(schema))
    conditions.push(emit_exports.Or(emit_exports.Not(emit_exports.IsArray(value)), BuildUnevaluatedItems(stack, context, schema, value)));
  if (IsUnevaluatedProperties(schema))
    conditions.push(emit_exports.Or(emit_exports.Not(emit_exports.IsObject(value)), BuildUnevaluatedProperties(stack, context, schema, value)));
  if (IsRefine2(schema))
    conditions.push(BuildRefine(stack, context, schema, value));
  const result = emit_exports.ReduceAnd(conditions);
  stack.Pop(schema);
  return result;
}
function CheckSchemaPushStack(stack, context, schema, value) {
  return context.Push() && CheckSchema(stack, context, schema, value) && context.Pop();
}
function CheckSchema(stack, context, schema, value) {
  stack.Push(schema);
  const result = IsSchemaBoolean(schema) ? CheckSchemaBoolean(stack, context, schema, value) : (!IsType(schema) || CheckType(stack, context, schema, value)) && (!(guard_exports.IsObject(value) && !guard_exports.IsArray(value)) || (!IsRequired(schema) || CheckRequired(stack, context, schema, value)) && (!IsAdditionalProperties(schema) || CheckAdditionalProperties(stack, context, schema, value)) && (!IsDependencies(schema) || CheckDependencies(stack, context, schema, value)) && (!IsDependentRequired(schema) || CheckDependentRequired(stack, context, schema, value)) && (!IsDependentSchemas(schema) || CheckDependentSchemas(stack, context, schema, value)) && (!IsPatternProperties(schema) || CheckPatternProperties(stack, context, schema, value)) && (!IsProperties(schema) || CheckProperties(stack, context, schema, value)) && (!IsPropertyNames(schema) || CheckPropertyNames(stack, context, schema, value)) && (!IsMinProperties(schema) || CheckMinProperties(stack, context, schema, value)) && (!IsMaxProperties(schema) || CheckMaxProperties(stack, context, schema, value))) && (!guard_exports.IsArray(value) || (!IsAdditionalItems(schema) || CheckAdditionalItems(stack, context, schema, value)) && (!IsContains(schema) || CheckContains(stack, context, schema, value)) && (!IsItems(schema) || CheckItems(stack, context, schema, value)) && (!IsMaxContains(schema) || CheckMaxContains(stack, context, schema, value)) && (!IsMaxItems(schema) || CheckMaxItems(stack, context, schema, value)) && (!IsMinContains(schema) || CheckMinContains(stack, context, schema, value)) && (!IsMinItems(schema) || CheckMinItems(stack, context, schema, value)) && (!IsPrefixItems(schema) || CheckPrefixItems(stack, context, schema, value)) && (!IsUniqueItems(schema) || CheckUniqueItems(stack, context, schema, value))) && (!guard_exports.IsString(value) || (!IsMaxLength(schema) || CheckMaxLength(stack, context, schema, value)) && (!IsMinLength(schema) || CheckMinLength(stack, context, schema, value)) && (!IsFormat(schema) || CheckFormat(stack, context, schema, value)) && (!IsPattern(schema) || CheckPattern(stack, context, schema, value))) && (!(guard_exports.IsNumber(value) || guard_exports.IsBigInt(value)) || (!IsExclusiveMaximum(schema) || CheckExclusiveMaximum(stack, context, schema, value)) && (!IsExclusiveMinimum(schema) || CheckExclusiveMinimum(stack, context, schema, value)) && (!IsMaximum(schema) || CheckMaximum(stack, context, schema, value)) && (!IsMinimum(schema) || CheckMinimum(stack, context, schema, value)) && (!IsMultipleOf(schema) || CheckMultipleOf(stack, context, schema, value))) && (!IsRef2(schema) || CheckRef(stack, context, schema, value)) && (!IsRecursiveRef(schema) || CheckRecursiveRef(stack, context, schema, value)) && (!IsDynamicRef(schema) || CheckDynamicRef(stack, context, schema, value)) && (!IsConst(schema) || CheckConst(stack, context, schema, value)) && (!IsEnum2(schema) || CheckEnum(stack, context, schema, value)) && (!IsIf(schema) || CheckIf(stack, context, schema, value)) && (!IsNot(schema) || CheckNot(stack, context, schema, value)) && (!IsAllOf(schema) || CheckAllOf(stack, context, schema, value)) && (!IsAnyOf(schema) || CheckAnyOf(stack, context, schema, value)) && (!IsOneOf(schema) || CheckOneOf(stack, context, schema, value)) && (!IsUnevaluatedItems(schema) || (!guard_exports.IsArray(value) || CheckUnevaluatedItems(stack, context, schema, value))) && (!IsUnevaluatedProperties(schema) || (!guard_exports.IsObject(value) || CheckUnevaluatedProperties(stack, context, schema, value))) && (!IsRefine2(schema) || CheckRefine(stack, context, schema, value));
  stack.Pop(schema);
  return result;
}
function ErrorSchemaPushStack(stack, context, schemaPath, instancePath, schema, value) {
  return context.Push() && ErrorSchema(stack, context, schemaPath, instancePath, schema, value) && context.Pop();
}
function ErrorSchema(stack, context, schemaPath, instancePath, schema, value) {
  if (context.AtCapacity())
    return false;
  stack.Push(schema);
  const result = IsSchemaBoolean(schema) ? ErrorSchemaBoolean(stack, context, schemaPath, instancePath, schema, value) : !!(+(!IsType(schema) || ErrorType(stack, context, schemaPath, instancePath, schema, value)) & +(!(guard_exports.IsObject(value) && !guard_exports.IsArray(value)) || !!(+(!IsRequired(schema) || ErrorRequired(stack, context, schemaPath, instancePath, schema, value)) & +(!IsAdditionalProperties(schema) || ErrorAdditionalProperties(stack, context, schemaPath, instancePath, schema, value)) & +(!IsDependencies(schema) || ErrorDependencies(stack, context, schemaPath, instancePath, schema, value)) & +(!IsDependentRequired(schema) || ErrorDependentRequired(stack, context, schemaPath, instancePath, schema, value)) & +(!IsDependentSchemas(schema) || ErrorDependentSchemas(stack, context, schemaPath, instancePath, schema, value)) & +(!IsPatternProperties(schema) || ErrorPatternProperties(stack, context, schemaPath, instancePath, schema, value)) & +(!IsProperties(schema) || ErrorProperties(stack, context, schemaPath, instancePath, schema, value)) & +(!IsPropertyNames(schema) || ErrorPropertyNames(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMinProperties(schema) || ErrorMinProperties(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMaxProperties(schema) || ErrorMaxProperties(stack, context, schemaPath, instancePath, schema, value)))) & +(!guard_exports.IsArray(value) || !!(+(!IsAdditionalItems(schema) || ErrorAdditionalItems(stack, context, schemaPath, instancePath, schema, value)) & +(!IsContains(schema) || ErrorContains(stack, context, schemaPath, instancePath, schema, value)) & +(!IsItems(schema) || ErrorItems(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMaxContains(schema) || ErrorMaxContains(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMaxItems(schema) || ErrorMaxItems(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMinContains(schema) || ErrorMinContains(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMinItems(schema) || ErrorMinItems(stack, context, schemaPath, instancePath, schema, value)) & +(!IsPrefixItems(schema) || ErrorPrefixItems(stack, context, schemaPath, instancePath, schema, value)) & +(!IsUniqueItems(schema) || ErrorUniqueItems(stack, context, schemaPath, instancePath, schema, value)))) & +(!guard_exports.IsString(value) || !!(+(!IsMaxLength(schema) || ErrorMaxLength(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMinLength(schema) || ErrorMinLength(stack, context, schemaPath, instancePath, schema, value)) & +(!IsFormat(schema) || ErrorFormat(stack, context, schemaPath, instancePath, schema, value)) & +(!IsPattern(schema) || ErrorPattern(stack, context, schemaPath, instancePath, schema, value)))) & +(!(guard_exports.IsNumber(value) || guard_exports.IsBigInt(value)) || !!(+(!IsExclusiveMaximum(schema) || ErrorExclusiveMaximum(stack, context, schemaPath, instancePath, schema, value)) & +(!IsExclusiveMinimum(schema) || ErrorExclusiveMinimum(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMaximum(schema) || ErrorMaximum(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMinimum(schema) || ErrorMinimum(stack, context, schemaPath, instancePath, schema, value)) & +(!IsMultipleOf(schema) || ErrorMultipleOf(stack, context, schemaPath, instancePath, schema, value)))) & +(!IsRef2(schema) || ErrorRef(stack, context, schemaPath, instancePath, schema, value)) & +(!IsRecursiveRef(schema) || ErrorRecursiveRef(stack, context, schemaPath, instancePath, schema, value)) & +(!IsDynamicRef(schema) || ErrorDynamicRef(stack, context, schemaPath, instancePath, schema, value)) & +(!IsConst(schema) || ErrorConst(stack, context, schemaPath, instancePath, schema, value)) & +(!IsEnum2(schema) || ErrorEnum(stack, context, schemaPath, instancePath, schema, value)) & +(!IsIf(schema) || ErrorIf(stack, context, schemaPath, instancePath, schema, value)) & +(!IsNot(schema) || ErrorNot(stack, context, schemaPath, instancePath, schema, value)) & +(!IsAllOf(schema) || ErrorAllOf(stack, context, schemaPath, instancePath, schema, value)) & +(!IsAnyOf(schema) || ErrorAnyOf(stack, context, schemaPath, instancePath, schema, value)) & +(!IsOneOf(schema) || ErrorOneOf(stack, context, schemaPath, instancePath, schema, value)) & +(!IsUnevaluatedItems(schema) || (!guard_exports.IsArray(value) || ErrorUnevaluatedItems(stack, context, schemaPath, instancePath, schema, value))) & +(!IsUnevaluatedProperties(schema) || (!guard_exports.IsObject(value) || ErrorUnevaluatedProperties(stack, context, schemaPath, instancePath, schema, value)))) && (!IsRefine2(schema) || ErrorRefine(stack, context, schemaPath, instancePath, schema, value));
  stack.Pop(schema);
  return result;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_functions.mjs
var index2 = [0];
var names2 = /* @__PURE__ */ new Map();
var funcs = /* @__PURE__ */ new Map();
function NextName() {
  return `${index2[0]++}`;
}
function CreateName(schema, href) {
  if (!names2.has(schema))
    names2.set(schema, /* @__PURE__ */ new Map());
  const hrefs = names2.get(schema);
  if (hrefs.has(href))
    return hrefs.get(href);
  const name = NextName();
  hrefs.set(href, name);
  return name;
}
function CreateCallExpression(context, _schema, name, value) {
  return context.UseUnevaluated() ? emit_exports.Call(`check_${name}`, ["context", value]) : emit_exports.Call(`check_${name}`, [value]);
}
function CreateFunctionExpression(stack, context, schema, name) {
  const expression = BuildSchema(stack, context, schema, "value");
  return context.UseUnevaluated() ? emit_exports.ConstDeclaration(`check_${name}`, emit_exports.ArrowFunction(["context", "value"], expression)) : emit_exports.ConstDeclaration(`check_${name}`, emit_exports.ArrowFunction(["value"], expression));
}
function ResetFunctions() {
  index2[0] = 0;
  names2.clear();
  funcs.clear();
}
function GetFunctions() {
  return [...funcs.values()];
}
function CreateFunction(stack, context, schema, value) {
  const name = CreateName(schema, stack.LexicalBaseURL());
  const call = CreateCallExpression(context, schema, name, value);
  if (funcs.has(name))
    return call;
  funcs.set(name, "");
  funcs.set(name, CreateFunctionExpression(stack, context, schema, name));
  return call;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/resolve/resolve.mjs
var resolve_exports = {};
__export(resolve_exports, {
  Base: () => Base,
  DefaultBase: () => DefaultBase,
  DynamicRef: () => DynamicRef,
  Ref: () => Ref2,
  ResolveDynamicRef: () => ResolveDynamicRef,
  ResolveRecursiveRef: () => ResolveRecursiveRef,
  ResolveRef: () => ResolveRef,
  Resource: () => Resource
});

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/pointer/pointer.mjs
var pointer_exports = {};
__export(pointer_exports, {
  Delete: () => Delete,
  Get: () => Get3,
  Has: () => Has2,
  Indices: () => Indices,
  Set: () => Set3
});
function AssertNotRoot(indices) {
  if (indices.length === 0)
    throw Error("Cannot set root");
}
function AssertCanSet(value) {
  if (!guard_exports.IsObject(value))
    throw Error("Cannot set value");
}
function AssertIndex(index3) {
  if (guard_exports.IsUnsafePropertyKey(index3))
    throw Error("Pointer contains unsafe property key");
}
function AssertIndices(indices) {
  for (const index3 of indices)
    AssertIndex(index3);
}
function IsNumericIndex(index3) {
  return /^(0|[1-9]\d*)$/.test(index3);
}
function TakeIndexRight(indices) {
  return [
    indices.slice(0, indices.length - 1),
    indices.slice(indices.length - 1)[0]
  ];
}
function HasIndex(index3, value) {
  return guard_exports.IsObject(value) && guard_exports.HasPropertyKey(value, index3);
}
function GetIndex(index3, value) {
  return guard_exports.IsObject(value) && !guard_exports.IsUnsafePropertyKey(index3) ? value[index3] : void 0;
}
function GetIndices(indices, value) {
  return indices.reduce((value2, index3) => GetIndex(index3, value2), value);
}
function Indices(pointer) {
  if (guard_exports.IsEqual(pointer.length, 0))
    return [];
  const indices = pointer.split("/").map((index3) => index3.replace(/~1/g, "/").replace(/~0/g, "~"));
  return indices.length > 0 && indices[0] === "" ? indices.slice(1) : indices;
}
function Has2(value, pointer) {
  let current = value;
  return Indices(pointer).every((index3) => {
    if (!HasIndex(index3, current))
      return false;
    current = current[index3];
    return true;
  });
}
function Get3(value, pointer) {
  const indices = Indices(pointer);
  return GetIndices(indices, value);
}
function Set3(value, pointer, next) {
  const indices = Indices(pointer);
  AssertNotRoot(indices);
  AssertIndices(indices);
  const [head, index3] = TakeIndexRight(indices);
  const parent = GetIndices(head, value);
  AssertCanSet(parent);
  parent[index3] = next;
  return value;
}
function Delete(value, pointer) {
  const indices = Indices(pointer);
  AssertNotRoot(indices);
  AssertIndices(indices);
  const [head, index3] = TakeIndexRight(indices);
  const parent = GetIndices(head, value);
  AssertCanSet(parent);
  if (guard_exports.IsArray(parent) && IsNumericIndex(index3)) {
    parent.splice(+index3, 1);
  } else {
    delete parent[index3];
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/resolve/resolve.mjs
var DefaultBase = "https://json-schema.org";
function FindDynamicAnchor(schema, name) {
  if (guard_exports.IsObject(schema) && IsDynamicAnchor(schema) && guard_exports.IsEqual(schema.$dynamicAnchor, name)) {
    return schema;
  }
  if (guard_exports.IsObject(schema)) {
    for (const key of guard_exports.Keys(schema)) {
      const result = FindDynamicAnchor(schema[key], name);
      if (result)
        return result;
    }
  }
  return void 0;
}
function FindBase(schema, base, target) {
  if (guard_exports.IsEqual(schema, target))
    return base.href;
  const nextBase = IsSchemaObject(schema) && IsId(schema) ? new URL(schema.$id, base.href) : base;
  if (guard_exports.IsArray(schema)) {
    for (const item of schema) {
      const result = FindBase(item, nextBase, target);
      if (!guard_exports.IsUndefined(result))
        return result;
    }
  } else if (guard_exports.IsObject(schema)) {
    for (const key of guard_exports.Keys(schema)) {
      const result = FindBase(schema[key], nextBase, target);
      if (!guard_exports.IsUndefined(result))
        return result;
    }
  }
  return void 0;
}
function MatchId(schema, base, ref) {
  if (guard_exports.IsEqual(schema.$id, ref.hash))
    return schema;
  const absoluteRef = new URL(ref.href, base.href);
  if (guard_exports.IsEqual(base.pathname, absoluteRef.pathname))
    return ref.hash.startsWith("#") ? MatchHash(schema, ref) : schema;
  return void 0;
}
function MatchAnchor(schema, base, ref) {
  const absoluteAnchor = new URL(`#${schema.$anchor}`, base.href);
  const absoluteRef = new URL(ref.href, base.href);
  return guard_exports.IsEqual(absoluteAnchor.href, absoluteRef.href) ? schema : void 0;
}
function MatchDynamicAnchor(schema, base, ref) {
  const absoluteAnchor = new URL(`#${schema.$dynamicAnchor}`, base.href);
  const absoluteRef = new URL(ref.href, base.href);
  const isMatch = guard_exports.IsEqual(absoluteAnchor.href, absoluteRef.href);
  return isMatch ? schema : void 0;
}
function MatchHash(schema, ref) {
  if (ref.href.endsWith("#"))
    return schema;
  if (!ref.hash.startsWith("#"))
    return void 0;
  const fragment = decodeURIComponent(ref.hash.slice(1));
  if (!fragment.startsWith("/"))
    return void 0;
  const result = pointer_exports.Get(schema, fragment);
  return result;
}
function Match(schema, base, ref) {
  if (IsId(schema)) {
    const result = MatchId(schema, base, ref);
    if (!guard_exports.IsUndefined(result))
      return result;
  }
  if (IsAnchor(schema)) {
    const result = MatchAnchor(schema, base, ref);
    if (!guard_exports.IsUndefined(result))
      return result;
  }
  if (IsDynamicAnchor(schema)) {
    const result = MatchDynamicAnchor(schema, base, ref);
    if (!guard_exports.IsUndefined(result))
      return result;
  }
  return MatchHash(schema, ref);
}
function FromArray(schema, base, ref) {
  return schema.reduce((result, item) => {
    const match = FromValue(item, base, ref);
    return !guard_exports.IsUndefined(match) ? match : result;
  }, void 0);
}
function SkipProperty(key) {
  return guard_exports.IsEqual(key, "const") || guard_exports.IsEqual(key, "enum");
}
function FromObject(schema, base, ref) {
  return guard_exports.Keys(schema).reduce((result, key) => {
    if (SkipProperty(key))
      return result;
    const match = FromValue(schema[key], base, ref);
    return !guard_exports.IsUndefined(match) ? match : result;
  }, void 0);
}
function FromValue(schema, base, ref) {
  const nextBase = IsSchemaObject(schema) && IsId(schema) ? new URL(schema.$id, base.href) : base;
  if (IsSchemaObject(schema)) {
    const result = Match(schema, nextBase, ref);
    if (!guard_exports.IsUndefined(result))
      return result;
  }
  if (guard_exports.IsArray(schema))
    return FromArray(schema, nextBase, ref);
  if (guard_exports.IsObject(schema))
    return FromObject(schema, nextBase, ref);
  return void 0;
}
function Base(schema, base, target) {
  return FindBase(schema, new URL(base || ".", DefaultBase), target);
}
function Resource(context, schema, base, ref) {
  const result = Ref2(context, schema, base, ref, false);
  return IsSchemaObject(result) && IsId(result) ? result : void 0;
}
function CanonicalHref(url) {
  return url.href.split("#")[0];
}
function RefContext(context, ref) {
  return guard_exports.HasPropertyKey(context, ref) ? context[ref] : void 0;
}
function RefLocal(schema, base, ref) {
  return FromValue(schema, base, ref);
}
function RefRemote(context, base, ref) {
  const canonicalHref = CanonicalHref(ref);
  if (guard_exports.IsEqual(canonicalHref, CanonicalHref(base)))
    return void 0;
  if (!guard_exports.HasPropertyKey(context, canonicalHref))
    return void 0;
  const remoteSchema = context[canonicalHref];
  const remoteBase = IsSchemaObject(remoteSchema) && IsId(remoteSchema) ? new URL(remoteSchema.$id, canonicalHref) : new URL(canonicalHref);
  const result = guard_exports.IsEqual(ref.hash, "") ? remoteSchema : FromValue(remoteSchema, remoteBase, ref);
  return result;
}
function LegacyRetrievedResource(root, lexicalSchema, referenceBase, ref, schema) {
  if (!ref.$ref.startsWith("#"))
    return void 0;
  if (guard_exports.HasPropertyKey(root, "$schema"))
    return void 0;
  const targetBase = Base(lexicalSchema, referenceBase, schema);
  if (guard_exports.IsUndefined(targetBase) || guard_exports.IsEqual(targetBase, referenceBase))
    return void 0;
  return { target: schema, base: targetBase, root: lexicalSchema };
}
function RemoteRetrievedResource(context, canonical, schema) {
  const remoteRoot = context[canonical];
  if (!IsSchemaObject(remoteRoot))
    return void 0;
  return { target: schema, base: canonical, root: remoteRoot };
}
function FindRetrievedResource(stackframe, ref, schema, canonical, isRemote) {
  const remote = isRemote ? RemoteRetrievedResource(stackframe.context, canonical, schema) : void 0;
  if (!guard_exports.IsUndefined(remote))
    return remote;
  return LegacyRetrievedResource(stackframe.root, stackframe.lexicalSchema, stackframe.referenceBase, ref, schema);
}
function FindResolvedResource(context, root, referenceBase, canonical, schema, ids) {
  if (IsId(schema))
    return void 0;
  const resource = Resource(context, root, referenceBase, canonical);
  if (!resource || ids.includes(resource))
    return void 0;
  return { target: schema, resource };
}
function Ref2(remotes, schema, base, ref, applySchemaId = true) {
  const initialBase = new URL(base || ".", DefaultBase);
  const resolvedBase = applySchemaId && IsId(schema) ? new URL(schema.$id, initialBase) : initialBase;
  const initialRef = new URL(ref, resolvedBase.href);
  return RefContext(remotes, ref) ?? RefLocal(schema, resolvedBase, initialRef) ?? RefRemote(remotes, resolvedBase, initialRef);
}
function DynamicRef(context, root, base, schema, dynamicRef, dynamicAnchors) {
  const initialBase = new URL(base || ".", DefaultBase);
  const fragmentRoot = dynamicRef.$dynamicRef.startsWith("#") ? schema : root;
  const fragmentTarget = Ref2(context, fragmentRoot, base, dynamicRef.$dynamicRef, false);
  if (guard_exports.IsUndefined(fragmentTarget)) {
    const fragment2 = new URL(dynamicRef.$dynamicRef, initialBase).hash;
    if (!fragment2.startsWith("#/") && fragment2.startsWith("#")) {
      const name = decodeURIComponent(fragment2.slice(1));
      const anchorTarget2 = dynamicAnchors.find((anchor) => guard_exports.IsEqual(anchor.$dynamicAnchor, name)) ?? FindDynamicAnchor(root, name);
      return anchorTarget2;
    }
    return void 0;
  }
  if (!IsSchemaObject(fragmentTarget) || !IsDynamicAnchor(fragmentTarget))
    return fragmentTarget;
  const fragment = new URL(dynamicRef.$dynamicRef, initialBase).hash;
  if (fragment.startsWith("#/"))
    return fragmentTarget;
  const anchorTarget = dynamicAnchors.find((anchor) => guard_exports.IsEqual(anchor.$dynamicAnchor, fragmentTarget.$dynamicAnchor));
  return anchorTarget ?? fragmentTarget;
}
function ResolveRef(stackframe, ref) {
  const source = stackframe.inRetrievedFrame ? stackframe.lexicalSchema : stackframe.root;
  const refRoot = ref.$ref.startsWith("#") ? stackframe.lexicalSchema : source;
  const schema = Ref2(stackframe.context, refRoot, stackframe.referenceBase, ref.$ref, false);
  if (!schema || !IsSchemaObject(schema))
    return { schema };
  const canonical = new URL(ref.$ref, stackframe.referenceBase).href.split("#")[0];
  const isRemote = !guard_exports.IsEqual(canonical, stackframe.resourceBase);
  const retrievedResource = FindRetrievedResource(stackframe, ref, schema, canonical, isRemote);
  const resolvedResource = isRemote ? FindResolvedResource(stackframe.context, stackframe.root, stackframe.referenceBase, canonical, schema, stackframe.ids) : void 0;
  return { schema, retrievedResource, resolvedResource };
}
function ResolveRecursiveRef(stackframe, recursiveRef) {
  const refRoot = IsRecursiveAnchorTrue(stackframe.lexicalSchema) ? stackframe.recursiveAnchors[0] : stackframe.lexicalSchema;
  return Ref2(stackframe.context, refRoot, stackframe.lexicalBase, recursiveRef.$recursiveRef, false);
}
function ResolveDynamicRef(stackframe, dynamicRef) {
  return DynamicRef(stackframe.context, stackframe.root, stackframe.lexicalBase, stackframe.lexicalSchema, dynamicRef, stackframe.dynamicAnchors);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/engine/_stack.mjs
var __classPrivateFieldGet = function(receiver, state2, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state2 === "function" ? receiver !== state2 || !f : !state2.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state2.get(receiver);
};
var _Stack_instances;
var _Stack_StackFrame;
var _Stack_ApplyRefResult;
var _Stack_BuildBase;
var _Stack_ResourceBaseURL;
var _Stack_ReferenceBaseURL;
var _Stack_LexicalSchema;
var _Stack_RegisterResourceAnchorArray;
var _Stack_UnregisterResourceAnchorArray;
var _Stack_RegisterResourceAnchors;
var _Stack_UnregisterResourceAnchors;
var _Stack_RegisterResource;
var _Stack_UnregisterResource;
var _Stack_EnterResolvedResource;
var _Stack_ExitResolvedResource;
var Stack = class {
  constructor(context, schema) {
    _Stack_instances.add(this);
    this.context = context;
    this.schema = schema;
    this.ids = [];
    this.resourceIds = [];
    this.anchors = [];
    this.recursiveAnchors = [];
    this.dynamicAnchors = [];
    this.retrievedResources = /* @__PURE__ */ new Map();
    this.retrievedFrames = [];
    this.resolvedResources = /* @__PURE__ */ new Map();
    this.pendingResource = true;
  }
  // ----------------------------------------------------------------
  // LexicalBaseURL
  // ----------------------------------------------------------------
  LexicalBaseURL() {
    return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_BuildBase).call(this, this.ids);
  }
  // ----------------------------------------------------------------
  // Push
  // ----------------------------------------------------------------
  Push(schema) {
    if (!IsSchemaObject(schema))
      return;
    if (IsId(schema))
      __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResource).call(this, schema);
    if (IsAnchor(schema))
      this.anchors.push(schema);
    if (IsRecursiveAnchorTrue(schema))
      this.recursiveAnchors.push(schema);
    if (IsDynamicAnchor(schema))
      this.dynamicAnchors.push(schema);
    const retrievedResource = this.retrievedResources.get(schema);
    if (retrievedResource) {
      this.retrievedFrames.push({
        schema: retrievedResource.root,
        base: retrievedResource.base,
        idDepth: this.ids.length,
        resourceDepth: this.resourceIds.length
      });
    }
  }
  // ----------------------------------------------------------------
  // Pop
  // ----------------------------------------------------------------
  Pop(schema) {
    if (!IsSchemaObject(schema))
      return;
    if (IsId(schema))
      __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResource).call(this, schema);
    if (IsAnchor(schema))
      this.anchors.pop();
    if (IsRecursiveAnchorTrue(schema))
      this.recursiveAnchors.pop();
    if (IsDynamicAnchor(schema))
      this.dynamicAnchors.pop();
    if (this.retrievedResources.has(schema))
      this.retrievedFrames.pop();
    __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ExitResolvedResource).call(this, schema);
  }
  // ----------------------------------------------------------------
  // Ref
  // ----------------------------------------------------------------
  Ref(ref) {
    const result = resolve_exports.ResolveRef(__classPrivateFieldGet(this, _Stack_instances, "m", _Stack_StackFrame).call(this), ref);
    __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ApplyRefResult).call(this, result);
    return result.schema;
  }
  // ----------------------------------------------------------------
  // RecursiveRef
  // ----------------------------------------------------------------
  RecursiveRef(recursiveRef) {
    const result = resolve_exports.ResolveRecursiveRef(__classPrivateFieldGet(this, _Stack_instances, "m", _Stack_StackFrame).call(this), recursiveRef);
    if (result)
      this.pendingResource = true;
    return result;
  }
  // ----------------------------------------------------------------
  // DynamicRef
  // ----------------------------------------------------------------
  DynamicRef(dynamicRef) {
    const result = resolve_exports.ResolveDynamicRef(__classPrivateFieldGet(this, _Stack_instances, "m", _Stack_StackFrame).call(this), dynamicRef);
    if (result)
      this.pendingResource = true;
    return result;
  }
};
_Stack_instances = /* @__PURE__ */ new WeakSet(), _Stack_StackFrame = function _Stack_StackFrame2() {
  return {
    context: this.context,
    root: this.schema,
    ids: this.ids,
    lexicalSchema: __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_LexicalSchema).call(this),
    lexicalBase: this.LexicalBaseURL(),
    referenceBase: __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ReferenceBaseURL).call(this),
    resourceBase: __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ResourceBaseURL).call(this),
    recursiveAnchors: this.recursiveAnchors,
    dynamicAnchors: this.dynamicAnchors,
    inRetrievedFrame: this.retrievedFrames.length > 0
  };
}, _Stack_ApplyRefResult = function _Stack_ApplyRefResult2(result) {
  if (!guard_exports.IsUndefined(result.schema))
    this.pendingResource = true;
  if (!guard_exports.IsUndefined(result.resolvedResource)) {
    __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_EnterResolvedResource).call(this, result.resolvedResource.target, result.resolvedResource.resource);
  }
  if (!guard_exports.IsUndefined(result.retrievedResource)) {
    this.retrievedResources.set(result.retrievedResource.target, {
      base: result.retrievedResource.base,
      root: result.retrievedResource.root
    });
  }
}, _Stack_BuildBase = function _Stack_BuildBase2(stack) {
  const frame = this.retrievedFrames[this.retrievedFrames.length - 1];
  const base = frame ? new URL(frame.base) : new URL(resolve_exports.DefaultBase);
  const scoped = frame ? stack.slice(frame.idDepth) : stack;
  return scoped.reduce((result, schema) => new URL(schema.$id, result), base).href;
}, _Stack_ResourceBaseURL = function _Stack_ResourceBaseURL2() {
  const frame = this.retrievedFrames[this.retrievedFrames.length - 1];
  if (!frame)
    return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_BuildBase).call(this, this.resourceIds);
  return this.resourceIds.slice(frame.resourceDepth).reduce((result, schema) => new URL(schema.$id, result), new URL(frame.base)).href;
}, _Stack_ReferenceBaseURL = function _Stack_ReferenceBaseURL2() {
  if (this.retrievedFrames.length > 0)
    return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ResourceBaseURL).call(this);
  const lexical = this.ids[this.ids.length - 1];
  if (lexical && !/^[A-Za-z][A-Za-z0-9+.-]*:/.test(lexical.$id))
    return this.LexicalBaseURL();
  return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_ResourceBaseURL).call(this);
}, _Stack_LexicalSchema = function _Stack_LexicalSchema2() {
  const frame = this.retrievedFrames[this.retrievedFrames.length - 1];
  if (frame)
    return this.ids.length > frame.idDepth ? this.ids[this.ids.length - 1] : frame.schema;
  return this.ids.length > 0 ? this.ids[this.ids.length - 1] : this.schema;
}, _Stack_RegisterResourceAnchorArray = function _Stack_RegisterResourceAnchorArray2(schema) {
  schema.forEach((schema2) => __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResourceAnchors).call(this, schema2, false));
}, _Stack_UnregisterResourceAnchorArray = function _Stack_UnregisterResourceAnchorArray2(schema) {
  schema.forEach((schema2) => __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResourceAnchors).call(this, schema2, false));
}, _Stack_RegisterResourceAnchors = function _Stack_RegisterResourceAnchors2(schema, isRoot = true) {
  if (IsSchemaBoolean(schema))
    return;
  if (guard_exports.IsArray(schema))
    return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResourceAnchorArray).call(this, schema);
  if (!IsSchemaObject(schema))
    return;
  const current = schema;
  if (!isRoot && IsId(current))
    return;
  if (!isRoot && IsDynamicAnchor(current))
    this.dynamicAnchors.push(current);
  for (const key of guard_exports.Keys(current))
    __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResourceAnchors2).call(this, current[key], false);
}, _Stack_UnregisterResourceAnchors = function _Stack_UnregisterResourceAnchors2(schema, isRoot = true) {
  if (IsSchemaBoolean(schema))
    return;
  if (guard_exports.IsArray(schema))
    return __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResourceAnchorArray).call(this, schema);
  if (!IsSchemaObject(schema))
    return;
  const current = schema;
  if (!isRoot && IsId(current))
    return;
  if (!isRoot && IsDynamicAnchor(current))
    this.dynamicAnchors.pop();
  for (const key of guard_exports.Keys(current))
    __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResourceAnchors2).call(this, current[key], false);
}, _Stack_RegisterResource = function _Stack_RegisterResource2(schema) {
  this.ids.push(schema);
  const isResource = this.pendingResource;
  this.pendingResource = false;
  if (isResource)
    this.resourceIds.push(schema);
  __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResourceAnchors).call(this, schema, true);
}, _Stack_UnregisterResource = function _Stack_UnregisterResource2(schema) {
  this.ids.pop();
  const isResource = this.resourceIds.length > 0 && guard_exports.IsEqual(this.resourceIds[this.resourceIds.length - 1], schema);
  if (isResource)
    this.resourceIds.pop();
  __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResourceAnchors).call(this, schema, true);
}, _Stack_EnterResolvedResource = function _Stack_EnterResolvedResource2(target, resource) {
  __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_RegisterResource).call(this, resource);
  this.resolvedResources.set(target, resource);
}, _Stack_ExitResolvedResource = function _Stack_ExitResolvedResource2(target) {
  if (!this.resolvedResources.has(target))
    return;
  const resource = this.resolvedResources.get(target);
  __classPrivateFieldGet(this, _Stack_instances, "m", _Stack_UnregisterResource).call(this, resource);
  this.resolvedResources.delete(target);
};

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/build.mjs
function CreateCode(build) {
  const functions = build.Functions().join(";\n");
  const statements = build.UseUnevaluated() ? ["const context = new CheckContext({}, {})", `return ${build.Entry()}`] : [`return ${build.Entry()}`];
  return `${functions}; return (value) => { ${statements.join("; ")} }`;
}
function CreateEvaluatedCheck(build, code) {
  const factory = environment_exports.Evaluate("CheckContext", "Guard", "Format", "Hashing", build.External().identifier, code);
  return factory(CheckContext, guard_exports, format_exports, hash_exports, build.External().variables);
}
function CreateDynamicCheck(build) {
  const stack = new Stack(build.Context(), build.Schema());
  const context = new CheckContext();
  return (value) => CheckSchema(stack, context, build.Schema(), value);
}
function CreateCheck(build, code) {
  return environment_exports.CanEvaluate() ? CreateEvaluatedCheck(build, code) : CreateDynamicCheck(build);
}
var EvaluateResult = class {
  constructor(isAccelerated, code, check) {
    this.isAccelerated = isAccelerated;
    this.code = code;
    this.check = check;
  }
  IsAccelerated() {
    return this.isAccelerated;
  }
  Code() {
    return this.code;
  }
  Check(value) {
    return this.check(value);
  }
};
var BuildResult = class {
  constructor(context, schema, external, functions, entry, useUnevaluated) {
    this.context = context;
    this.schema = schema;
    this.external = external;
    this.functions = functions;
    this.entry = entry;
    this.useUnevaluated = useUnevaluated;
  }
  /** Returns the Context used for this build */
  Context() {
    return this.context;
  }
  /** Returns the Schema used for this build */
  Schema() {
    return this.schema;
  }
  /** Returns true if this build requires a Unevaluated context */
  UseUnevaluated() {
    return this.useUnevaluated;
  }
  /** Returns external variables */
  External() {
    return this.external;
  }
  /** Returns check functions */
  Functions() {
    return this.functions;
  }
  /** Return entry function call. */
  Entry() {
    return this.entry;
  }
  /** Evaluates the build into a validation function */
  Evaluate() {
    const code = CreateCode(this);
    const check = CreateCheck(this, code);
    return new EvaluateResult(environment_exports.CanEvaluate(), code, check);
  }
};
function Build(...args) {
  const [context, schema] = arguments_exports.Match(args, {
    2: (context2, schema2) => [context2, schema2],
    1: (schema2) => [{}, schema2]
  });
  ResetExternal();
  ResetFunctions();
  const stack = new Stack(context, schema);
  const build = new BuildContext(HasUnevaluated(context, schema));
  const call = CreateFunction(stack, build, schema, "value");
  const functions = GetFunctions();
  const externals = GetExternal();
  return new BuildResult(context, schema, externals, functions, call, build.UseUnevaluated());
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/errors.mjs
function Errors(...args) {
  const [context, schema, value] = arguments_exports.Match(args, {
    3: (context2, schema2, value2) => [context2, schema2, value2],
    2: (schema2, value2) => [{}, schema2, value2]
  });
  const stack = new Stack(context, schema);
  const errorContext = new ErrorContext();
  const result = ErrorSchema(stack, errorContext, "#", "", schema, value);
  const errors = errorContext.GetErrors();
  const locale = Get();
  const localized = errors.map((error) => ({ ...error, message: locale(error) }));
  return [result, localized];
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/schema/check.mjs
function Check(...args) {
  const [context, schema, value] = arguments_exports.Match(args, {
    3: (context2, schema2, value2) => [context2, schema2, value2],
    2: (schema2, value2) => [{}, schema2, value2]
  });
  const stack = new Stack(context, schema);
  const checkContext = new CheckContext();
  return CheckSchema(stack, checkContext, schema, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/check/check.mjs
function Check2(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  return Check(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/errors/errors.mjs
function Errors2(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  const [_, errors] = Errors(context, type, value);
  return errors;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/assert/assert.mjs
var AssertError = class extends Error {
  constructor(source, value, errors) {
    super(source);
    Object.defineProperty(this, "cause", {
      value: { source, errors, value },
      writable: false,
      configurable: false,
      enumerable: false
    });
  }
};
function Assert(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  const check = Check2(context, type, value);
  if (!check)
    throw new AssertError("Assert", value, Errors2(context, type, value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_array.mjs
function FromArray2(context, type, value) {
  if (!guard_exports.IsArray(value))
    return value;
  return value.map((value2) => FromType(context, type.items, value2));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_cyclic.mjs
function FromCyclic(context, type, value) {
  return FromType({ ...context, ...type.$defs }, Ref(type.$ref), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_intersect.mjs
function EvaluateIntersection(context, type) {
  const additionalProperties = guard_exports.HasPropertyKey(type, "unevaluatedProperties") ? { additionalProperties: type.unevaluatedProperties } : {};
  const instantiated = Instantiate(context, type);
  const evaluated = Evaluate(instantiated);
  return IsObject(evaluated) ? With(evaluated, additionalProperties) : evaluated;
}
function FromIntersect(context, type, value) {
  const evaluated = EvaluateIntersection(context, type);
  return FromType(context, evaluated, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/additional.mjs
function GetAdditionalProperties(type) {
  const additionalProperties = guard_exports.HasPropertyKey(type, "additionalProperties") ? type.additionalProperties : void 0;
  return additionalProperties;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_object.mjs
function FromObject2(context, type, value) {
  if (!guard_exports.IsObject(value) || guard_exports.IsArray(value))
    return value;
  const additionalProperties = GetAdditionalProperties(type);
  for (const key of guard_exports.Keys(value)) {
    if (guard_exports.HasPropertyKey(type.properties, key)) {
      value[key] = FromType(context, type.properties[key], value[key]);
      continue;
    }
    const unknownCheck = (
      // 1. additionalProperties: true
      guard_exports.IsBoolean(additionalProperties) && guard_exports.IsEqual(additionalProperties, true) || IsSchema(additionalProperties) && Check2(context, additionalProperties, value[key])
    );
    if (unknownCheck) {
      value[key] = FromType(context, additionalProperties, value[key]);
      continue;
    }
    delete value[key];
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_record.mjs
function FromRecord(context, type, value) {
  if (!guard_exports.IsObject(value))
    return value;
  const additionalProperties = GetAdditionalProperties(type);
  const [recordPattern, recordValue] = [new RegExp(RecordPattern(type)), RecordValue(type)];
  for (const key of guard_exports.Keys(value)) {
    if (recordPattern.test(key)) {
      value[key] = FromType(context, recordValue, value[key]);
      continue;
    }
    const unknownCheck = (
      // 1. additionalProperties: true
      guard_exports.IsBoolean(additionalProperties) && guard_exports.IsEqual(additionalProperties, true) || IsSchema(additionalProperties) && Check2(context, additionalProperties, value[key])
    );
    if (unknownCheck) {
      value[key] = FromType(context, additionalProperties, value[key]);
      continue;
    }
    delete value[key];
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_ref.mjs
function FromRef(context, type, value) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType(context, context[type.$ref], value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_tuple.mjs
function FromTuple(context, schema, value) {
  if (!guard_exports.IsArray(value))
    return value;
  const length = Math.min(value.length, schema.items.length);
  for (let index3 = 0; index3 < length; index3++) {
    value[index3] = FromType(context, schema.items[index3], value[index3]);
  }
  return guard_exports.IsGreaterThan(value.length, length) ? value.slice(0, length) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clone/clone.mjs
function Clone2(value) {
  return Clone(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_union.mjs
function FromUnion(context, type, value) {
  for (const schema of type.anyOf) {
    const clean = FromType(context, schema, Clone2(value));
    if (Check2(context, schema, clean))
      return clean;
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/from_type.mjs
function FromType(context, type, value) {
  return IsArray(type) ? FromArray2(context, type, value) : IsCyclic(type) ? FromCyclic(context, type, value) : IsIntersect(type) ? FromIntersect(context, type, value) : IsObject(type) ? FromObject2(context, type, value) : IsRecord(type) ? FromRecord(context, type, value) : IsRef(type) ? FromRef(context, type, value) : IsTuple(type) ? FromTuple(context, type, value) : IsUnion(type) ? FromUnion(context, type, value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/shared/union_priority_sort.mjs
function Modifiers(type, next) {
  for (const key of guard_default.Keys(type)) {
    if (guard_default.HasPropertyKey(next, key))
      continue;
    next[key] = type[key];
  }
  return next;
}
function FromProperties(properties) {
  const result = {};
  for (const key of guard_default.Keys(properties))
    result[key] = FromType2(properties[key]);
  return result;
}
function FromPriorityTypes(types) {
  return FromTypes(Priority(types));
}
function FromTypes(types) {
  return types.map((type) => FromType2(type));
}
function FromType2(type) {
  const next = IsArray(type) ? _Array_(FromType2(type.items), ArrayOptions(type)) : IsIntersect(type) ? Intersect(FromTypes(type.allOf)) : IsUnion(type) ? Union(FromPriorityTypes(type.anyOf)) : IsObject(type) ? _Object_(FromProperties(type.properties)) : IsRecord(type) ? Record(RecordKey(type), FromType2(RecordValue(type))) : IsTuple(type) ? Tuple(FromTypes(type.items)) : type;
  return Modifiers(type, next);
}
function UnionPrioritySort(type) {
  const result = FromType2(type);
  return result;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/clean/clean.mjs
function Clean(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  const sorted = settings_exports.Get().unionPrioritySort ? UnionPrioritySort(type) : type;
  return FromType(context, sorted, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try.mjs
var try_exports = {};
__export(try_exports, {
  Fail: () => Fail,
  IsOk: () => IsOk,
  Ok: () => Ok,
  TryArray: () => TryArray,
  TryBigInt: () => TryBigInt,
  TryBoolean: () => TryBoolean,
  TryNull: () => TryNull,
  TryNumber: () => TryNumber,
  TryString: () => TryString,
  TryUndefined: () => TryUndefined
});

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_result.mjs
function IsOk(value) {
  return guard_exports.IsObject(value) && guard_exports.HasPropertyKey(value, "value");
}
function Ok(value) {
  return { value };
}
function Fail() {
  return void 0;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_array.mjs
function TryArray(value) {
  return guard_exports.IsArray(value) ? Ok(value) : Ok([value]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_bigint.mjs
function FromBoolean(value) {
  return guard_exports.IsEqual(value, true) ? Ok(BigInt(1)) : Ok(BigInt(0));
}
var bigintPattern = /^-?(0|[1-9]\d*)n$/;
var decimalPattern = /^-?(0|[1-9]\d*)\.\d+$/;
var integerPattern = /^-?(0|[1-9]\d*)$/;
function IsStringBigIntLike(value) {
  return bigintPattern.test(value);
}
function IsStringDecimalLike(value) {
  return decimalPattern.test(value);
}
function IsStringIntegerLike(value) {
  return integerPattern.test(value);
}
function FromString(value) {
  const lowercase = value.toLowerCase();
  return IsStringBigIntLike(value) ? Ok(BigInt(value.slice(0, value.length - 1))) : IsStringDecimalLike(value) ? Ok(BigInt(value.split(".")[0])) : IsStringIntegerLike(value) ? Ok(BigInt(value)) : guard_exports.IsEqual(lowercase, "false") ? Ok(BigInt(0)) : guard_exports.IsEqual(lowercase, "true") ? Ok(BigInt(1)) : Fail();
}
function TryBigInt(value) {
  return guard_exports.IsBigInt(value) ? Ok(value) : guard_exports.IsBoolean(value) ? FromBoolean(value) : guard_exports.IsNumber(value) ? Ok(BigInt(Math.trunc(value))) : guard_exports.IsNull(value) ? Ok(BigInt(0)) : guard_exports.IsString(value) ? FromString(value) : guard_exports.IsUndefined(value) ? Ok(BigInt(0)) : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_boolean.mjs
function FromBigInt(value) {
  return guard_exports.IsEqual(value, BigInt(0)) ? Ok(false) : guard_exports.IsEqual(value, BigInt(1)) ? Ok(true) : Fail();
}
function FromNumber(value) {
  return guard_exports.IsEqual(value, 0) ? Ok(false) : guard_exports.IsEqual(value, 1) ? Ok(true) : Fail();
}
function FromString2(value) {
  return guard_exports.IsEqual(value.toLowerCase(), "false") ? Ok(false) : guard_exports.IsEqual(value.toLowerCase(), "true") ? Ok(true) : guard_exports.IsEqual(value, "0") ? Ok(false) : guard_exports.IsEqual(value, "1") ? Ok(true) : Fail();
}
function TryBoolean(value) {
  return guard_exports.IsBigInt(value) ? FromBigInt(value) : guard_exports.IsBoolean(value) ? Ok(value) : guard_exports.IsNumber(value) ? FromNumber(value) : guard_exports.IsNull(value) ? Ok(false) : guard_exports.IsString(value) ? FromString2(value) : guard_exports.IsUndefined(value) ? Ok(false) : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_null.mjs
function FromBigInt2(value) {
  return guard_exports.IsEqual(value, BigInt(0)) ? Ok(null) : Fail();
}
function FromBoolean2(value) {
  return guard_exports.IsEqual(value, false) ? Ok(null) : Fail();
}
function FromNumber2(value) {
  return guard_exports.IsEqual(value, 0) ? Ok(null) : Fail();
}
function FromString3(value) {
  const lowercase = value.toLowerCase();
  const predicate = guard_exports.IsEqual(lowercase, "undefined") || guard_exports.IsEqual(lowercase, "null") || guard_exports.IsEqual(value, "") || guard_exports.IsEqual(value, "0");
  return predicate ? Ok(null) : Fail();
}
function TryNull(value) {
  return guard_exports.IsBigInt(value) ? FromBigInt2(value) : guard_exports.IsBoolean(value) ? FromBoolean2(value) : guard_exports.IsNumber(value) ? FromNumber2(value) : guard_exports.IsNull(value) ? Ok(null) : guard_exports.IsString(value) ? FromString3(value) : guard_exports.IsUndefined(value) ? Ok(null) : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_number.mjs
var maxBigInt = BigInt(Number.MAX_SAFE_INTEGER);
var minBigInt = BigInt(Number.MIN_SAFE_INTEGER);
function FromBigInt3(value) {
  return value <= maxBigInt && value >= minBigInt ? Ok(Number(value)) : Fail();
}
function FromBoolean3(value) {
  return Ok(value ? 1 : 0);
}
function FromString4(value) {
  const coerced = +value;
  if (guard_exports.IsNumber(coerced))
    return Ok(coerced);
  const lowercase = value.toLowerCase();
  if (guard_exports.IsEqual(lowercase, "false"))
    return Ok(0);
  if (guard_exports.IsEqual(lowercase, "true"))
    return Ok(1);
  const result = TryBigInt(value);
  if (IsOk(result))
    return result.value <= maxBigInt && result.value >= minBigInt ? Ok(Number(result.value)) : Fail();
  return Fail();
}
function TryNumber(value) {
  return guard_exports.IsBigInt(value) ? FromBigInt3(value) : guard_exports.IsBoolean(value) ? FromBoolean3(value) : guard_exports.IsNumber(value) ? Ok(value) : guard_exports.IsNull(value) ? Ok(0) : guard_exports.IsString(value) ? FromString4(value) : guard_exports.IsUndefined(value) ? Ok(0) : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_string.mjs
function TryString(value) {
  return guard_exports.IsBigInt(value) ? Ok(value.toString()) : guard_exports.IsBoolean(value) ? Ok(value.toString()) : guard_exports.IsNumber(value) ? Ok(value.toString()) : guard_exports.IsNull(value) ? Ok("null") : guard_exports.IsString(value) ? Ok(value) : guard_exports.IsUndefined(value) ? Ok("") : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/try/try_undefined.mjs
function FromBigInt4(value) {
  return guard_exports.IsEqual(value, BigInt(0)) ? Ok(void 0) : Fail();
}
function FromBoolean4(value) {
  return guard_exports.IsEqual(value, false) ? Ok(void 0) : Fail();
}
function FromNumber3(value) {
  return guard_exports.IsEqual(value, 0) ? Ok(void 0) : Fail();
}
function FromString5(value) {
  const lowercase = value.toLowerCase();
  const predicate = guard_exports.IsEqual(lowercase, "undefined") || guard_exports.IsEqual(lowercase, "null") || guard_exports.IsEqual(value, "") || guard_exports.IsEqual(value, "0");
  return predicate ? Ok(void 0) : Fail();
}
function TryUndefined(value) {
  return guard_exports.IsBigInt(value) ? FromBigInt4(value) : guard_exports.IsBoolean(value) ? FromBoolean4(value) : guard_exports.IsNumber(value) ? FromNumber3(value) : guard_exports.IsNull(value) ? Ok(void 0) : guard_exports.IsString(value) ? FromString5(value) : guard_exports.IsUndefined(value) ? Ok(value) : Fail();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_array.mjs
function FromArray3(context, type, value) {
  const result = try_exports.TryArray(value);
  return result.value.map((value2) => FromType3(context, type.items, value2));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_bigint.mjs
function FromBigInt5(_context, _type, value) {
  const result = try_exports.TryBigInt(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_boolean.mjs
function FromBoolean5(_context, _type, value) {
  const result = try_exports.TryBoolean(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_cyclic.mjs
function FromCyclic2(context, type, value) {
  return FromType3({ ...context, ...type.$defs }, Ref(type.$ref), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_enum.mjs
function FromEnum(context, type, value) {
  return FromType3(context, Evaluate(type), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_integer.mjs
function FromInteger(_context, _type, value) {
  const result = try_exports.TryNumber(value);
  return try_exports.IsOk(result) ? Math.trunc(result.value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_intersect.mjs
function FromIntersect2(context, type, value) {
  const instantiated = Instantiate(context, type);
  const evaluated = Evaluate(instantiated);
  return FromType3(context, evaluated, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_literal.mjs
function FromLiteralBigInt(_context, type, value) {
  const result = try_exports.TryBigInt(value);
  return try_exports.IsOk(result) && guard_exports.IsEqual(type.const, result.value) ? result.value : value;
}
function FromLiteralBoolean(_context, type, value) {
  const result = try_exports.TryBoolean(value);
  return try_exports.IsOk(result) && guard_exports.IsEqual(type.const, result.value) ? result.value : value;
}
function FromLiteralNumber(_context, type, value) {
  const result = try_exports.TryNumber(value);
  return try_exports.IsOk(result) && guard_exports.IsEqual(type.const, result.value) ? result.value : value;
}
function FromLiteralString(_context, type, value) {
  const result = try_exports.TryString(value);
  return try_exports.IsOk(result) && guard_exports.IsEqual(type.const, result.value) ? result.value : value;
}
function FromLiteral(context, type, value) {
  if (guard_exports.IsEqual(type.const, value))
    return value;
  return IsLiteralBigInt(type) ? FromLiteralBigInt(context, type, value) : IsLiteralBoolean(type) ? FromLiteralBoolean(context, type, value) : IsLiteralNumber(type) ? FromLiteralNumber(context, type, value) : IsLiteralString(type) ? FromLiteralString(context, type, value) : Unreachable();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_null.mjs
function FromNull(_context, _type, value) {
  const result = try_exports.TryNull(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_number.mjs
function FromNumber4(_context, _type, value) {
  const result = try_exports.TryNumber(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_additional.mjs
function FromAdditionalProperties(context, entries, additionalProperties, value) {
  const keys = guard_exports.Keys(value);
  for (const [regexp, _] of entries) {
    for (const key of keys) {
      if (!regexp.test(key)) {
        value[key] = FromType3(context, additionalProperties, value[key]);
      }
    }
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/shared/optional_undefined.mjs
function IsOptionalUndefined(property, key, value) {
  return IsOptional(property) && guard_exports.IsUndefined(value[key]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_object.mjs
function FromProperties2(context, type, value) {
  const entries = guard_exports.EntriesRegExp(type.properties);
  const keys = guard_exports.Keys(value);
  for (const [regexp, property] of entries) {
    for (const key of keys) {
      if (!regexp.test(key) || IsOptionalUndefined(property, key, value))
        continue;
      value[key] = FromType3(context, property, value[key]);
    }
  }
  return guard_exports.HasPropertyKey(type, "additionalProperties") && guard_exports.IsObject(type.additionalProperties) ? FromAdditionalProperties(context, entries, type.additionalProperties, value) : value;
}
function FromObject3(context, type, value) {
  return guard_exports.IsObjectNotArray(value) ? FromProperties2(context, type, value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_record.mjs
function FromPatternProperties(context, type, value) {
  const entries = guard_exports.EntriesRegExp(type.patternProperties);
  const keys = guard_exports.Keys(value);
  for (const [regexp, schema] of entries) {
    for (const key of keys) {
      if (regexp.test(key)) {
        value[key] = FromType3(context, schema, value[key]);
      }
    }
  }
  return guard_exports.HasPropertyKey(type, "additionalProperties") && guard_exports.IsObject(type.additionalProperties) ? FromAdditionalProperties(context, entries, type.additionalProperties, value) : value;
}
function FromRecord2(context, type, value) {
  return guard_exports.IsObjectNotArray(value) ? FromPatternProperties(context, type, value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_ref.mjs
function FromRef2(context, type, value) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType3(context, context[type.$ref], value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_string.mjs
function FromString6(_context, _type, value) {
  const result = try_exports.TryString(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_template_literal.mjs
function FromTemplateLiteral(context, type, value) {
  return FromType3(context, Evaluate(type), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_tuple.mjs
function FromTuple2(context, type, value) {
  if (!guard_exports.IsArray(value))
    return value;
  for (let index3 = 0; index3 < Math.min(type.items.length, value.length); index3++) {
    value[index3] = FromType3(context, type.items[index3], value[index3]);
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_undefined.mjs
function FromUndefined(_context, _type, value) {
  const result = try_exports.TryUndefined(value);
  return try_exports.IsOk(result) ? result.value : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_union.mjs
function FromUnion2(context, type, value) {
  const matched = type.anyOf.some((type2) => Check2(context, type2, value));
  if (matched)
    return value;
  const candidates = type.anyOf.map((type2) => FromType3(context, type2, Clone2(value)));
  const selected = candidates.find((value2) => Check2(context, type, value2));
  return guard_exports.IsUndefined(selected) ? value : selected;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_void.mjs
function FromVoid(_context, _type, value) {
  const result = try_exports.TryUndefined(value);
  return try_exports.IsOk(result) ? void 0 : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/from_type.mjs
function FromType3(context, type, value) {
  return IsArray(type) ? FromArray3(context, type, value) : IsBigInt(type) ? FromBigInt5(context, type, value) : IsBoolean(type) ? FromBoolean5(context, type, value) : IsCyclic(type) ? FromCyclic2(context, type, value) : IsEnum(type) ? FromEnum(context, type, value) : IsInteger(type) ? FromInteger(context, type, value) : IsIntersect(type) ? FromIntersect2(context, type, value) : IsLiteral(type) ? FromLiteral(context, type, value) : IsNull(type) ? FromNull(context, type, value) : IsNumber(type) ? FromNumber4(context, type, value) : IsObject(type) ? FromObject3(context, type, value) : IsRecord(type) ? FromRecord2(context, type, value) : IsRef(type) ? FromRef2(context, type, value) : IsString(type) ? FromString6(context, type, value) : IsTemplateLiteral(type) ? FromTemplateLiteral(context, type, value) : IsTuple(type) ? FromTuple2(context, type, value) : IsUndefined(type) ? FromUndefined(context, type, value) : IsUnion(type) ? FromUnion2(context, type, value) : IsVoid(type) ? FromVoid(context, type, value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/convert/convert.mjs
function Convert(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  return FromType3(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_array.mjs
function FromArray4(context, type, value) {
  if (!guard_exports.IsArray(value))
    return value;
  for (let i = 0; i < value.length; i++) {
    value[i] = FromType4(context, type.items, value[i]);
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_cyclic.mjs
function FromCyclic3(context, type, value) {
  return FromType4({ ...context, ...type.$defs }, Ref(type.$ref), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_default.mjs
function FromDefault(type, value) {
  if (!guard_exports.IsUndefined(value))
    return value;
  return guard_exports.IsFunction(type.default) ? type.default() : Clone2(type.default);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_intersect.mjs
function FromIntersect3(context, type, value) {
  const instantiated = Instantiate(context, type);
  const evaluated = Evaluate(instantiated);
  return FromType4(context, evaluated, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_object.mjs
function FromObject4(context, type, value) {
  if (!guard_exports.IsObject(value))
    return value;
  const knownPropertyKeys = guard_exports.Keys(type.properties);
  for (const key of knownPropertyKeys) {
    const propertyValue = FromType4(context, type.properties[key], value[key]);
    const isUnassignableUndefined = guard_exports.IsUndefined(propertyValue) && (IsOptional(type.properties[key]) || !guard_exports.HasPropertyKey(type.properties[key], "default"));
    if (isUnassignableUndefined)
      continue;
    value[key] = propertyValue;
  }
  if (!IsAdditionalProperties(type) || guard_exports.IsBoolean(type.additionalProperties))
    return value;
  for (const key of guard_exports.Keys(value)) {
    if (knownPropertyKeys.includes(key))
      continue;
    value[key] = FromType4(context, type.additionalProperties, value[key]);
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_record.mjs
function FromRecord3(context, type, value) {
  if (!guard_exports.IsObject(value))
    return value;
  const [recordKey, recordValue] = [new RegExp(RecordPattern(type)), RecordValue(type)];
  for (const key of guard_exports.Keys(value)) {
    if (!(recordKey.test(key) && IsDefault(recordValue)))
      continue;
    value[key] = FromType4(context, recordValue, value[key]);
  }
  if (!IsAdditionalProperties(type))
    return value;
  for (const key of guard_exports.Keys(value)) {
    if (recordKey.test(key))
      continue;
    value[key] = FromType4(context, type.additionalProperties, value[key]);
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_ref.mjs
function FromRef3(context, type, value) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType4(context, context[type.$ref], value) : value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_tuple.mjs
function FromTuple3(context, schema, value) {
  if (!guard_exports.IsArray(value))
    return value;
  const [items, max] = [schema.items, Math.max(schema.items.length, value.length)];
  for (let i = 0; i < max; i++) {
    if (i < items.length)
      value[i] = FromType4(context, items[i], value[i]);
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_union.mjs
function FromUnion3(context, schema, value) {
  for (const inner of schema.anyOf) {
    const result = FromType4(context, inner, Clone2(value));
    if (Check2(context, inner, result)) {
      return result;
    }
  }
  return value;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/from_type.mjs
function FromType4(context, type, value) {
  const defaulted = IsDefault(type) ? FromDefault(type, value) : value;
  return IsArray(type) ? FromArray4(context, type, defaulted) : IsCyclic(type) ? FromCyclic3(context, type, defaulted) : IsIntersect(type) ? FromIntersect3(context, type, defaulted) : IsObject(type) ? FromObject4(context, type, defaulted) : IsRecord(type) ? FromRecord3(context, type, defaulted) : IsRef(type) ? FromRef3(context, type, defaulted) : IsTuple(type) ? FromTuple3(context, type, defaulted) : IsUnion(type) ? FromUnion3(context, type, defaulted) : defaulted;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/default/default.mjs
function Default(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  return FromType4(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/pipeline/pipeline.mjs
function Pipeline(pipeline) {
  return (...args) => {
    const [context, type, value] = arguments_exports.Match(args, {
      3: (context2, type2, value2) => [context2, type2, value2],
      2: (type2, value2) => [{}, type2, value2]
    });
    return pipeline.reduce((result, func) => func(context, type, result), value);
  };
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/callback.mjs
function Decode2(_context, type, value) {
  return type["~codec"].decode(value);
}
function Encode2(_context, type, value) {
  return type["~codec"].encode(value);
}
function Callback(direction, context, type, value) {
  if (!IsCodec(type))
    return value;
  return guard_exports.IsEqual(direction, "Decode") ? Decode2(context, type, value) : Encode2(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_array.mjs
function Decode3(direction, context, type, value) {
  if (!guard_exports.IsArray(value))
    return value;
  for (let i = 0; i < value.length; i++) {
    value[i] = FromType5(direction, context, type.items, value[i]);
  }
  return Callback(direction, context, type, value);
}
function Encode3(direction, context, type, value) {
  const exterior = Callback(direction, context, type, value);
  if (!guard_exports.IsArray(exterior))
    return exterior;
  for (let i = 0; i < exterior.length; i++) {
    exterior[i] = FromType5(direction, context, type.items, exterior[i]);
  }
  return exterior;
}
function FromArray5(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode3(direction, context, type, value) : Encode3(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_cyclic.mjs
function FromCyclic4(direction, context, type, value) {
  value = FromType5(direction, { ...context, ...type.$defs }, Ref(type.$ref), value);
  return Callback(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_intersect.mjs
function MergeInteriors(interiors) {
  return interiors.reduce((results, interior) => ({ ...results, ...interior }), {});
}
function NonMatchingInterior(value, interiors) {
  for (const interior of interiors)
    if (!guard_exports.IsDeepEqual(value, interior))
      return interior;
  return value;
}
function Decode4(direction, context, type, value) {
  if (guard_exports.IsEqual(type.allOf.length, 0))
    return Callback(direction, context, type, value);
  const interiors = type.allOf.map((schema) => FromType5(direction, context, schema, Clean(schema, Clone2(value))));
  const structural = interiors.every((result) => guard_exports.IsObject(result));
  const exterior = structural ? MergeInteriors(interiors) : NonMatchingInterior(value, interiors);
  return Callback(direction, context, type, exterior);
}
function Encode4(direction, context, type, value) {
  if (guard_exports.IsEqual(type.allOf.length, 0))
    return Callback(direction, context, type, value);
  const exterior = Callback(direction, context, type, value);
  const interiors = type.allOf.map((schema) => FromType5(direction, context, schema, Clean(schema, Clone2(exterior))));
  const structural = interiors.every((result) => guard_exports.IsObject(result));
  if (structural)
    return MergeInteriors(interiors);
  return NonMatchingInterior(exterior, interiors);
}
function FromIntersect4(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode4(direction, context, type, value) : Encode4(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_object.mjs
function Decode5(direction, context, type, value) {
  if (!guard_exports.IsObjectNotArray(value))
    return value;
  for (const key of guard_exports.Keys(type.properties)) {
    if (!guard_exports.HasPropertyKey(value, key) || IsOptionalUndefined(type.properties[key], key, value))
      continue;
    value[key] = FromType5(direction, context, type.properties[key], value[key]);
  }
  return Callback(direction, context, type, value);
}
function Encode5(direction, context, type, value) {
  const exterior = Callback(direction, context, type, value);
  if (!guard_exports.IsObjectNotArray(exterior))
    return exterior;
  for (const key of guard_exports.Keys(type.properties)) {
    if (!guard_exports.HasPropertyKey(exterior, key) || IsOptionalUndefined(type.properties[key], key, exterior))
      continue;
    exterior[key] = FromType5(direction, context, type.properties[key], exterior[key]);
  }
  return exterior;
}
function FromObject5(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode5(direction, context, type, value) : Encode5(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_record.mjs
function Decode6(direction, context, type, value) {
  if (!guard_exports.IsObjectNotArray(value))
    return value;
  const regexp = new RegExp(RecordPattern(type));
  for (const key of guard_exports.Keys(value)) {
    if (!regexp.test(key))
      continue;
    value[key] = FromType5(direction, context, RecordValue(type), value[key]);
  }
  return Callback(direction, context, type, value);
}
function Encode6(direction, context, type, value) {
  const exterior = Callback(direction, context, type, value);
  if (!guard_exports.IsObjectNotArray(exterior))
    return exterior;
  const regexp = new RegExp(RecordPattern(type));
  for (const key of guard_exports.Keys(exterior)) {
    if (!regexp.test(key))
      continue;
    exterior[key] = FromType5(direction, context, RecordValue(type), exterior[key]);
  }
  return exterior;
}
function FromRecord4(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode6(direction, context, type, value) : Encode6(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_ref.mjs
function ResolveRef2(direction, context, type, value) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType5(direction, context, context[type.$ref], value) : value;
}
function FromRef4(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Callback(direction, context, type, ResolveRef2(direction, context, type, value)) : ResolveRef2(direction, context, type, Callback(direction, context, type, value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_tuple.mjs
function Decode7(direction, context, type, value) {
  if (!guard_exports.IsArray(value))
    return value;
  for (let i = 0; i < Math.min(type.items.length, value.length); i++) {
    value[i] = FromType5(direction, context, type.items[i], value[i]);
  }
  return Callback(direction, context, type, value);
}
function Encode7(direction, context, type, value) {
  const exterior = Callback(direction, context, type, value);
  if (!guard_exports.IsArray(exterior))
    return value;
  for (let i = 0; i < Math.min(type.items.length, exterior.length); i++) {
    exterior[i] = FromType5(direction, context, type.items[i], exterior[i]);
  }
  return exterior;
}
function FromTuple4(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode7(direction, context, type, value) : Encode7(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_union.mjs
function Decode8(direction, context, type, value) {
  for (const schema of type.anyOf) {
    if (!Check2(context, schema, value))
      continue;
    const variant = FromType5(direction, context, schema, value);
    return Callback(direction, context, type, variant);
  }
  return value;
}
function Encode8(direction, context, type, value) {
  const exterior = Callback(direction, context, type, value);
  for (const schema of type.anyOf) {
    const variant = FromType5(direction, context, schema, Clone2(exterior));
    if (!Check2(context, schema, variant))
      continue;
    return variant;
  }
  return exterior;
}
function FromUnion4(direction, context, type, value) {
  return guard_exports.IsEqual(direction, "Decode") ? Decode8(direction, context, type, value) : Encode8(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/from_type.mjs
function FromType5(direction, context, type, value) {
  return IsArray(type) ? FromArray5(direction, context, type, value) : IsCyclic(type) ? FromCyclic4(direction, context, type, value) : IsIntersect(type) ? FromIntersect4(direction, context, type, value) : IsObject(type) ? FromObject5(direction, context, type, value) : IsRecord(type) ? FromRecord4(direction, context, type, value) : IsRef(type) ? FromRef4(direction, context, type, value) : IsTuple(type) ? FromTuple4(direction, context, type, value) : IsUnion(type) ? FromUnion4(direction, context, type, value) : Callback(direction, context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/decode.mjs
var DecodeError = class extends AssertError {
  constructor(value, errors) {
    super("Decode", value, errors);
  }
};
function Assert2(context, type, value) {
  if (!Check2(context, type, value))
    throw new DecodeError(value, Errors2(context, type, value));
  return value;
}
function DecodeUnsafe(context, type, value) {
  const sorted = settings_exports.Get().unionPrioritySort ? UnionPrioritySort(type) : type;
  return FromType5("Decode", context, sorted, value);
}
var Decoder = Pipeline([
  (_context, _type, value) => Clone2(value),
  (context, type, value) => Default(context, type, value),
  (context, type, value) => Convert(context, type, value),
  (context, type, value) => Clean(context, type, value),
  (context, type, value) => Assert2(context, type, value),
  (context, type, value) => DecodeUnsafe(context, type, value)
]);
function Decode9(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  return Decoder(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/encode.mjs
var EncodeError = class extends AssertError {
  constructor(value, errors) {
    super("Encode", value, errors);
  }
};
function Assert3(context, type, value) {
  if (!Check2(context, type, value))
    throw new EncodeError(value, Errors2(context, type, value));
  return value;
}
function EncodeUnsafe(context, type, value) {
  const sorted = settings_exports.Get().unionPrioritySort ? UnionPrioritySort(type) : type;
  return FromType5("Encode", context, sorted, value);
}
var Encoder = Pipeline([
  (_context, _type, value) => Clone2(value),
  (context, type, value) => EncodeUnsafe(context, type, value),
  (context, type, value) => Default(context, type, value),
  (context, type, value) => Convert(context, type, value),
  (context, type, value) => Clean(context, type, value),
  (context, type, value) => Assert3(context, type, value)
]);
function Encode9(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  return Encoder(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/codec/has.mjs
function FromArray6(context, type) {
  return IsCodec(type) || FromType6(context, type.items);
}
function FromCyclic5(context, type) {
  return IsCodec(type) || FromRef5({ ...context, ...type.$defs }, Ref(type.$ref));
}
function FromIntersect5(context, type) {
  return IsCodec(type) || type.allOf.some((type2) => FromType6(context, type2));
}
function FromObject6(context, type) {
  return IsCodec(type) || guard_exports.Keys(type.properties).some((key) => {
    return FromType6(context, type.properties[key]);
  });
}
function FromRecord5(context, type) {
  return IsCodec(type) || FromType6(context, RecordValue(type));
}
function FromRef5(context, type) {
  if (visited.has(type.$ref))
    return false;
  visited.add(type.$ref);
  return IsCodec(type) || guard_exports.HasPropertyKey(context, type.$ref) && FromType6(context, context[type.$ref]);
}
function FromTuple5(context, type) {
  return IsCodec(type) || type.items.some((type2) => FromType6(context, type2));
}
function FromUnion5(context, type) {
  return IsCodec(type) || type.anyOf.some((type2) => FromType6(context, type2));
}
function FromType6(context, type) {
  return IsArray(type) ? FromArray6(context, type) : IsCyclic(type) ? FromCyclic5(context, type) : IsIntersect(type) ? FromIntersect5(context, type) : IsObject(type) ? FromObject6(context, type) : IsRecord(type) ? FromRecord5(context, type) : IsRef(type) ? FromRef5(context, type) : IsTuple(type) ? FromTuple5(context, type) : IsUnion(type) ? FromUnion5(context, type) : IsCodec(type);
}
var visited = /* @__PURE__ */ new Set();
function HasCodec(...args) {
  const [context, type] = arguments_exports.Match(args, {
    2: (context2, type2) => [context2, type2],
    1: (type2) => [{}, type2]
  });
  visited.clear();
  return FromType6(context, type);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/error.mjs
var CreateError = class extends Error {
  constructor(type, message) {
    super(message);
    this.type = type;
  }
};

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_default.mjs
function FromDefault2(_context, schema) {
  return guard_exports.IsFunction(schema.default) ? schema.default(schema) : guard_exports.IsObject(schema.default) ? Clone2(schema.default) : schema.default;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_array.mjs
function FromArray7(context, type) {
  if (IsUniqueItems(type) && !IsDefault(type))
    throw new CreateError(type, "Arrays with uniqueItems constraints must specify a default annotation");
  const length = IsMinItems(type) ? type.minItems : 0;
  return Array.from({ length }, () => FromType7(context, type.items));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_bigint.mjs
function FromBigInt6(_context, type) {
  return IsExclusiveMinimum(type) ? BigInt(type.exclusiveMinimum) + BigInt(1) : IsMinimum(type) ? BigInt(type.minimum) : BigInt(0);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_boolean.mjs
function FromBoolean6(_context, _type) {
  return false;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_constructor.mjs
function FromConstructor(context, type) {
  const instanceType = FromType7(context, type.instanceType);
  return class {
    constructor() {
      Object.assign(this, instanceType);
    }
  };
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_cyclic.mjs
function FromCyclic6(context, type) {
  return FromType7({ ...context, ...type.$defs }, Ref(type.$ref));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_enum.mjs
function FromEnum2(context, type) {
  return FromType7(context, Evaluate(type));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_function.mjs
function FromFunction(context, type) {
  const returnType = FromType7(context, type.returnType);
  return () => returnType;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_integer.mjs
function FromInteger2(_context, type) {
  return IsExclusiveMinimum(type) && guard_exports.IsNumber(type.exclusiveMinimum) ? type.exclusiveMinimum + 1 : IsMinimum(type) ? type.minimum : 0;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_intersect.mjs
function FromIntersect6(context, type) {
  const instantiated = Instantiate(context, type);
  const evaluated = Evaluate(instantiated);
  return FromType7(context, evaluated);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_literal.mjs
function FromLiteral2(_context, type) {
  return type.const;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_never.mjs
function FromNever(_context, type) {
  throw new CreateError(type, "Cannot create TNever types");
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_null.mjs
function FromNull2(_context, _type) {
  return null;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_number.mjs
function FromNumber5(_context, type) {
  return IsExclusiveMinimum(type) && guard_exports.IsNumber(type.exclusiveMinimum) ? type.exclusiveMinimum + 1 : IsMinimum(type) ? type.minimum : 0;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_object.mjs
function FromObject7(context, type) {
  const required = guard_exports.IsUndefined(type.required) ? [] : type.required;
  return required.reduce((result, key) => {
    return { ...result, [key]: FromType7(context, type.properties[key]) };
  }, {});
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_record.mjs
function FromRecord6(_context, type) {
  if (IsMinProperties(type) && !IsDefault(type))
    throw new CreateError(type, "Record with the minProperties constraint must have a default annotation");
  return {};
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_ref.mjs
function FromRef6(context, type) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType7(context, context[type.$ref]) : (() => {
    throw new CreateError(type, "Unable to deref Ref");
  })();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_string.mjs
function FromString7(_context, type) {
  const needsDefault = (IsPattern(type) || IsFormat(type)) && !IsDefault(type);
  if (needsDefault)
    throw Error("Strings with format or pattern constraints must specify default");
  const minLength = IsMinLength(type) ? type.minLength : 0;
  return "".padEnd(minLength);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_symbol.mjs
function FromSymbol(_context, _type) {
  return /* @__PURE__ */ Symbol();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_template_literal.mjs
function FromTemplateLiteral2(context, type) {
  const decoded = TemplateLiteralDecode(type.pattern);
  if (IsString(decoded))
    throw new CreateError(type, "Unable to create TemplateLiteral due to infinite type expansion");
  return FromType7(context, decoded);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_tuple.mjs
function FromTuple6(context, type) {
  return Array.from({ length: type.minItems }, (_, i) => FromType7(context, type.items[i]));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_undefined.mjs
function FromUndefined2(_context, _type) {
  return void 0;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_union.mjs
function FromUnion6(context, type) {
  if (guard_exports.IsEqual(type.anyOf.length, 0)) {
    throw Error("Unable to create Union with no variants");
  }
  return FromType7(context, type.anyOf[0]);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_void.mjs
function FromVoid2(_context, _type) {
  return void 0;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/from_type.mjs
function FromType7(context, type) {
  return (
    // -----------------------------------------------------
    // Default
    // -----------------------------------------------------
    IsDefault(type) ? FromDefault2(context, type) : (
      // -----------------------------------------------------
      // Types
      // -----------------------------------------------------
      IsArray(type) ? FromArray7(context, type) : IsBigInt(type) ? FromBigInt6(context, type) : IsBoolean(type) ? FromBoolean6(context, type) : IsConstructor(type) ? FromConstructor(context, type) : IsCyclic(type) ? FromCyclic6(context, type) : IsEnum(type) ? FromEnum2(context, type) : IsFunction(type) ? FromFunction(context, type) : IsInteger(type) ? FromInteger2(context, type) : IsIntersect(type) ? FromIntersect6(context, type) : IsLiteral(type) ? FromLiteral2(context, type) : IsNever(type) ? FromNever(context, type) : IsNull(type) ? FromNull2(context, type) : IsNumber(type) ? FromNumber5(context, type) : IsObject(type) ? FromObject7(context, type) : IsRecord(type) ? FromRecord6(context, type) : IsRef(type) ? FromRef6(context, type) : IsString(type) ? FromString7(context, type) : IsSymbol(type) ? FromSymbol(context, type) : IsTemplateLiteral(type) ? FromTemplateLiteral2(context, type) : IsTuple(type) ? FromTuple6(context, type) : IsUndefined(type) ? FromUndefined2(context, type) : IsUnion(type) ? FromUnion6(context, type) : IsVoid(type) ? FromVoid2(context, type) : void 0
    )
  );
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/create/create.mjs
function Create(...args) {
  const [context, type] = arguments_exports.Match(args, {
    2: (context2, type2) => [context2, type2],
    1: (type2) => [{}, type2]
  });
  return FromType7(context, type);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/equal/equal.mjs
function Equal(left, right) {
  return guard_exports.IsDeepEqual(left, right);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/hash/hash.mjs
function Hash(value) {
  return hash_exports.Hash(value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/parse/parse.mjs
var ParseError = class extends AssertError {
  constructor(value, errors) {
    super("Parse", value, errors);
  }
};
function Assert4(context, type, value) {
  if (!Check2(context, type, value))
    throw new ParseError(value, Errors2(context, type, value));
  return value;
}
var Parser = Pipeline([
  (_context, _type, value) => Clone2(value),
  (context, type, value) => Default(context, type, value),
  (context, type, value) => Convert(context, type, value),
  (context, type, value) => Clean(context, type, value),
  (context, type, value) => Assert4(context, type, value)
]);
function Parse(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  const checked = Check2(context, type, value);
  if (checked)
    return value;
  if (settings_exports.Get().correctiveParse)
    return Parser(context, type, value);
  throw new ParseError(value, Errors2(context, type, value));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/delta/diff.mjs
function CreateUpdate(path, value) {
  return { type: "update", path, value };
}
function CreateInsert(path, value) {
  return { type: "insert", path, value };
}
function CreateDelete(path) {
  return { type: "delete", path };
}
function AssertCanDiffObject(value) {
  if (guard_exports.IsObject(value) && guard_exports.IsEqual(guard_exports.Symbols(value).length, 0))
    return;
  throw new Error("Cannot create diffs for objects with symbols keys");
}
function* FromObject8(path, left, right) {
  if (!guard_exports.IsObject(right) || guard_exports.IsArray(right))
    return yield CreateUpdate(path, right);
  AssertCanDiffObject(left);
  AssertCanDiffObject(right);
  const leftKeys = guard_exports.Keys(left);
  const rightKeys = guard_exports.Keys(right);
  for (const key of rightKeys) {
    if (guard_exports.HasPropertyKey(left, key))
      continue;
    if (guard_exports.IsUnsafePropertyKey(key))
      continue;
    yield CreateInsert(`${path}/${key}`, right[key]);
  }
  for (const key of leftKeys) {
    if (!guard_exports.HasPropertyKey(right, key))
      continue;
    if (guard_exports.IsUnsafePropertyKey(key))
      continue;
    if (Equal(left, right))
      continue;
    yield* FromValue2(`${path}/${key}`, left[key], right[key]);
  }
  for (const key of leftKeys) {
    if (guard_exports.HasPropertyKey(right, key))
      continue;
    if (guard_exports.IsUnsafePropertyKey(key))
      continue;
    yield CreateDelete(`${path}/${key}`);
  }
}
function* FromArray8(path, left, right) {
  if (!guard_exports.IsArray(right))
    return yield CreateUpdate(path, right);
  for (let i = 0; i < Math.min(left.length, right.length); i++) {
    yield* FromValue2(`${path}/${i}`, left[i], right[i]);
  }
  for (let i = 0; i < right.length; i++) {
    if (i < left.length)
      continue;
    yield CreateInsert(`${path}/${i}`, right[i]);
  }
  for (let i = left.length - 1; i >= 0; i--) {
    if (i < right.length)
      continue;
    yield CreateDelete(`${path}/${i}`);
  }
}
function* FromTypedArray(path, left, right) {
  const typeLeft = globalThis.Object.getPrototypeOf(left).constructor.name;
  const typeRight = globalThis.Object.getPrototypeOf(right).constructor.name;
  const predicate = globals_exports.IsTypeArray(right) && guard_exports.IsEqual(left.length, right.length) && guard_exports.IsEqual(typeLeft, typeRight);
  if (predicate) {
    for (let index3 = 0; index3 < Math.min(left.length, right.length); index3++) {
      yield* FromValue2(`${path}/${index3}`, left[index3], right[index3]);
    }
  } else {
    return yield CreateUpdate(path, right);
  }
}
function* FromUnknown(path, left, right) {
  if (left === right)
    return;
  yield CreateUpdate(path, right);
}
function* FromValue2(path, left, right) {
  return globals_exports.IsTypeArray(left) ? yield* FromTypedArray(path, left, right) : guard_exports.IsArray(left) ? yield* FromArray8(path, left, right) : guard_exports.IsObject(left) ? yield* FromObject8(path, left, right) : yield* FromUnknown(path, left, right);
}
function Diff(current, next) {
  return [...FromValue2("", current, next)];
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/delta/edit.mjs
var Insert = _Object_({
  type: Literal("insert"),
  path: String2(),
  value: Unknown()
});
var Update = Object({
  type: Literal("update"),
  path: String2(),
  value: Unknown()
});
var Delete2 = _Object_({
  type: Literal("delete"),
  path: String2()
});
var Edit = Union([Insert, Update, Delete2]);

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/delta/patch.mjs
function IsRoot(edits) {
  return edits.length > 0 && edits[0].path === "" && edits[0].type === "update";
}
function IsEmpty(edits) {
  return edits.length === 0;
}
function Patch(current, edits) {
  if (IsRoot(edits))
    return Clone2(edits[0].value);
  if (IsEmpty(edits))
    return Clone2(current);
  const clone2 = Clone2(current);
  for (const edit of edits) {
    switch (edit.type) {
      case "insert": {
        pointer_exports.Set(clone2, edit.path, edit.value);
        break;
      }
      case "update": {
        pointer_exports.Set(clone2, edit.path, edit.value);
        break;
      }
      case "delete": {
        pointer_exports.Delete(clone2, edit.path);
        break;
      }
    }
  }
  return clone2;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/error.mjs
var RepairError = class extends Error {
  constructor(context, type, value, message) {
    super(message);
    this.context = context;
    this.type = type;
    this.value = value;
  }
};

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_array.mjs
function MakeUnique(values) {
  const [hashes, result] = [/* @__PURE__ */ new Set(), []];
  for (const value of values) {
    const hash = Hash(value);
    if (hashes.has(hash))
      continue;
    hashes.add(hash);
    result.push(value);
  }
  return result;
}
function FromArray9(context, type, value) {
  if (Check2(context, type, value))
    return value;
  const created = guard_exports.IsArray(value) ? value : Create(context, type);
  const minimum = IsMinItems(type) && created.length < type.minItems ? [...created, ...Array.from({ length: type.minItems - created.length }, () => Create(context, type))] : created;
  const maximum = IsMaxItems(type) && minimum.length > type.maxItems ? minimum.slice(0, type.maxItems) : minimum;
  const repaired = maximum.map((value2) => FromType8(context, type.items, value2));
  if (!IsUniqueItems(type) || IsUniqueItems(type) && !guard_exports.IsEqual(type.uniqueItems, true))
    return repaired;
  const unique = MakeUnique(repaired);
  if (!Check2(context, type, unique))
    throw new RepairError(context, type, value, "Failed to repair Array due to uniqueItems constraint");
  return unique;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_enum.mjs
function FromEnum3(context, type, value) {
  return FromType8(context, Evaluate(type), value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_intersect.mjs
function FromIntersect7(context, type, value) {
  const instantiated = Instantiate(context, type);
  const evaluated = Evaluate(instantiated);
  return FromType8(context, evaluated, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_object.mjs
function FromObject9(context, type, value) {
  if (Check2(context, type, value))
    return value;
  if (!guard_exports.IsObjectNotArray(value))
    return Create(context, type);
  const required = new Set(guard_exports.IsUndefined(type.required) ? [] : type.required);
  const result = {};
  for (const [key, schema] of guard_exports.Entries(type.properties)) {
    if (!required.has(key) && guard_exports.IsUndefined(value[key]))
      continue;
    result[key] = key in value ? FromType8(context, schema, value[key]) : Create(context, schema);
  }
  const evaluatedKeys = guard_exports.Keys(type.properties);
  if (IsAdditionalProperties(type) && guard_exports.IsObject(type.additionalProperties)) {
    for (const key of guard_exports.Keys(value)) {
      if (evaluatedKeys.includes(key))
        continue;
      result[key] = FromType8(context, type.additionalProperties, value[key]);
    }
  }
  return result;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_record.mjs
function FromRecord7(context, type, value) {
  if (Check2(context, type, value))
    return value;
  if (guard_exports.IsNull(value) || !guard_exports.IsObject(value) || guard_exports.IsArray(value))
    return Create(context, type);
  const recordKey = new RegExp(RecordPattern(type));
  const recordValue = RecordValue(type);
  const evaluatedKeys = /* @__PURE__ */ new Set();
  const result = {};
  for (const [key, value_] of guard_exports.Entries(value)) {
    if (!recordKey.test(key))
      continue;
    result[key] = FromType8(context, recordValue, value_);
    evaluatedKeys.add(key);
  }
  if (IsAdditionalProperties(type)) {
    for (const key of guard_exports.Keys(value)) {
      if (evaluatedKeys.has(key))
        continue;
      result[key] = FromType8(context, type.additionalProperties, value[key]);
    }
  }
  return result;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_ref.mjs
function FromRef7(context, type, value) {
  return guard_exports.HasPropertyKey(context, type.$ref) ? FromType8(context, context[type.$ref], value) : (() => {
    throw new RepairError(context, type, value, "Unable to de-reference target type");
  })();
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_template_literal.mjs
function FromTemplateLiteral3(context, type, value) {
  const decoded = TemplateLiteralDecode(type.pattern);
  return FromType8(context, decoded, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_tuple.mjs
function FromTuple7(context, schema, value) {
  if (Check2(context, schema, value))
    return value;
  if (!guard_exports.IsArray(value))
    return Create(context, schema);
  return schema.items.map((schema2, index3) => FromType8(context, schema2, value[index3]));
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/shared/union_score_select.mjs
function Deref(context, type, value) {
  return IsRef(type) ? guard_exports.HasPropertyKey(context, type.$ref) ? Deref(context, context[type.$ref], value) : (() => {
    throw new Error("Unable to Deref target");
  })() : type;
}
function ScoreVariant(context, type, value) {
  if (!(IsObject(type) && guard_exports.IsObject(value)))
    return 0;
  const keys = guard_exports.Keys(value);
  const entries = guard_exports.Entries(type.properties);
  return entries.reduce((result, [key, schema]) => {
    const literal = IsLiteral(schema) && guard_exports.IsEqual(schema.const, value[key]) ? 100 : 0;
    const checks = Check2(context, schema, value[key]) ? 10 : 0;
    const exists = keys.includes(key) ? 1 : 0;
    return result + (literal + checks + exists);
  }, 0);
}
function UnionScoreSelect(context, type, value) {
  const schemas = type.anyOf.map((schema) => Deref(context, schema, value));
  let [select, best] = [schemas[0], 0];
  for (const schema of schemas) {
    const score = ScoreVariant(context, schema, value);
    if (score > best) {
      select = schema;
      best = score;
    }
  }
  return select;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_union.mjs
function RepairUnion(context, type, value) {
  const union = Union(Flatten(type.anyOf));
  const schema = UnionScoreSelect(context, union, value);
  return FromType8(context, schema, value);
}
function FromUnion7(context, type, value) {
  if (Check2(context, type, value))
    return Clone2(value);
  if (IsDefault(type))
    return Create(context, type);
  return RepairUnion(context, type, value);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_unknown.mjs
function FromUnknown2(context, type, value) {
  if (Check2(context, type, value))
    return value;
  const converted = Convert(context, type, value);
  if (Check2(context, type, converted))
    return converted;
  return Create(context, type);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/from_type.mjs
function AssertRepairableValue(context, type, value) {
  const unsupported = globals_exports.IsDate(value) || globals_exports.IsMap(value) || globals_exports.IsSet(value) || globals_exports.IsTypeArray(value) || guard_exports.IsConstructor(value) || guard_exports.IsFunction(value);
  if (unsupported) {
    throw new RepairError(context, type, value, "Value is not repairable");
  }
}
function AssertRepairableType(context, type, value) {
  const unsupported = IsConstructor(type) || IsFunction(type) || IsNever(type);
  if (unsupported) {
    throw new RepairError(context, type, value, "Type is not repairable");
  }
}
function CreateWhenUndefined(context, type, value) {
  return guard_exports.IsUndefined(value) && !IsUndefined(type) ? Create(context, type) : value;
}
function FinalizeRepair(context, type, repaired) {
  return IsRefine(type) ? Check2(context, type, repaired) ? repaired : Create(context, type) : repaired;
}
function FromType8(context, type, value) {
  AssertRepairableValue(context, type, value);
  AssertRepairableType(context, type, value);
  const candidate = CreateWhenUndefined(context, type, value);
  const repaired = IsArray(type) ? FromArray9(context, type, candidate) : IsEnum(type) ? FromEnum3(context, type, candidate) : IsIntersect(type) ? FromIntersect7(context, type, candidate) : IsObject(type) ? FromObject9(context, type, candidate) : IsRecord(type) ? FromRecord7(context, type, candidate) : IsRef(type) ? FromRef7(context, type, candidate) : IsTemplateLiteral(type) ? FromTemplateLiteral3(context, type, candidate) : IsTuple(type) ? FromTuple7(context, type, candidate) : IsUnion(type) ? FromUnion7(context, type, candidate) : FromUnknown2(context, type, candidate);
  return FinalizeRepair(context, type, repaired);
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/repair/repair.mjs
function Repair(...args) {
  const [context, type, value] = arguments_exports.Match(args, {
    3: (context2, type2, value2) => [context2, type2, value2],
    2: (type2, value2) => [{}, type2, value2]
  });
  const repaired = FromType8(context, type, value);
  Assert(context, type, repaired);
  return repaired;
}

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/value/value.mjs
var value_exports = {};
__export(value_exports, {
  Assert: () => Assert,
  Check: () => Check2,
  Clean: () => Clean,
  Clone: () => Clone2,
  Convert: () => Convert,
  Create: () => Create,
  Decode: () => Decode9,
  Default: () => Default,
  Diff: () => Diff,
  Encode: () => Encode9,
  Equal: () => Equal,
  Errors: () => Errors2,
  HasCodec: () => HasCodec,
  Hash: () => Hash,
  Parse: () => Parse,
  Patch: () => Patch,
  Pointer: () => pointer_exports,
  Repair: () => Repair
});

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/compile/validator.mjs
var Validator = class {
  /** Constructs a Validator. */
  constructor(context, type) {
    this.hasCodec = HasCodec(context, type);
    this.buildResult = Build(context, type);
    this.evaluateResult = this.buildResult.Evaluate();
  }
  // ----------------------------------------------------------------
  // IsAccelerated
  // ----------------------------------------------------------------
  /** Returns true if this Validator is using JIT acceleration. */
  IsAccelerated() {
    return this.evaluateResult.IsAccelerated();
  }
  // ----------------------------------------------------------------
  // Context & Type
  // ----------------------------------------------------------------
  /** Returns the Context for this validator. */
  Context() {
    return this.buildResult.Context();
  }
  /** Returns the underlying Type used to construct this Validator. */
  Type() {
    return this.buildResult.Schema();
  }
  // ----------------------------------------------------------------
  // Code
  // ----------------------------------------------------------------
  /** Returns the generated code for this validator. */
  Code() {
    return this.evaluateResult.Code();
  }
  // ----------------------------------------------------------------
  // Standard Validator
  // ----------------------------------------------------------------
  /** Performs a type-guard check on the provided value. */
  Check(value) {
    return this.evaluateResult.Check(value);
  }
  /** Validates a value and returns it. Will throw if invalid. */
  Parse(value) {
    const checked = this.Check(value);
    if (checked)
      return value;
    if (settings_exports.Get().correctiveParse)
      return Parser(this.Context(), this.Type(), value);
    throw new ParseError(value, this.Errors(value));
  }
  /** Returns an array of validation errors for the given value. */
  Errors(value) {
    if (this.IsAccelerated() && this.Check(value))
      return [];
    return Errors2(this.Context(), this.Type(), value);
  }
  // ----------------------------------------------------------------
  // Value.* Operations
  // ----------------------------------------------------------------
  /** Cleans a value using the Validator type. */
  Clean(value) {
    return Clean(this.Context(), this.Type(), value);
  }
  /** Converts a value using the Validator type. */
  Convert(value) {
    return Convert(this.Context(), this.Type(), value);
  }
  /** Creates a value using the Validator type. */
  Create() {
    return Create(this.Context(), this.Type());
  }
  /** Creates defaults using the Validator type. */
  Default(value) {
    return Default(this.Context(), this.Type(), value);
  }
  /** Decodes a value */
  Decode(value) {
    const result = this.hasCodec ? Decode9(this.Context(), this.Type(), value) : this.Parse(value);
    return result;
  }
  /** Encodes a value */
  Encode(value) {
    const result = this.hasCodec ? Encode9(this.Context(), this.Type(), value) : this.Parse(value);
    return result;
  }
};

// ../../node_modules/.pnpm/typebox@1.3.27/node_modules/typebox/build/compile/compile.mjs
function Compile(...args) {
  const [context, type] = arguments_exports.Match(args, {
    2: (context2, type2) => [context2, type2],
    1: (type2) => [{}, type2]
  });
  return new Validator(context, type);
}

// ../../node_modules/.pnpm/@earendil-works+pi-ai@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelcontextpro_284929f414f75b7f77d6867259ed136d/node_modules/@earendil-works/pi-ai/dist/utils/validation.js
var validatorCache = /* @__PURE__ */ new WeakMap();
var TYPEBOX_KIND = /* @__PURE__ */ Symbol.for("TypeBox.Kind");
function getSchemaTypes(schema) {
  if (typeof schema.type === "string") {
    return [schema.type];
  }
  if (Array.isArray(schema.type)) {
    return schema.type.filter((type) => typeof type === "string");
  }
  return [];
}
function matchesJsonType(value, type) {
  switch (type) {
    case "number":
      return typeof value === "number";
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "boolean":
      return typeof value === "boolean";
    case "string":
      return typeof value === "string";
    case "null":
      return value === null;
    case "array":
      return Array.isArray(value);
    case "object":
      return typeof value === "object" && value !== null && !Array.isArray(value);
    default:
      return false;
  }
}
function getSubSchemaValidator(schema) {
  try {
    return getValidator(schema);
  } catch {
    return void 0;
  }
}
function coercePrimitiveByType(value, type) {
  switch (type) {
    case "number": {
      if (value === null) {
        return 0;
      }
      if (typeof value === "string" && value.trim() !== "") {
        const parsed = Number(value);
        if (Number.isFinite(parsed)) {
          return parsed;
        }
      }
      if (typeof value === "boolean") {
        return value ? 1 : 0;
      }
      return value;
    }
    case "integer": {
      if (value === null) {
        return 0;
      }
      if (typeof value === "string" && value.trim() !== "") {
        const parsed = Number(value);
        if (Number.isInteger(parsed)) {
          return parsed;
        }
      }
      if (typeof value === "boolean") {
        return value ? 1 : 0;
      }
      return value;
    }
    case "boolean": {
      if (value === null) {
        return false;
      }
      if (typeof value === "string") {
        if (value === "true") {
          return true;
        }
        if (value === "false") {
          return false;
        }
      }
      if (typeof value === "number") {
        if (value === 1) {
          return true;
        }
        if (value === 0) {
          return false;
        }
      }
      return value;
    }
    case "string": {
      if (value === null) {
        return "";
      }
      if (typeof value === "number" || typeof value === "boolean") {
        return String(value);
      }
      return value;
    }
    case "null": {
      if (value === "" || value === 0 || value === false) {
        return null;
      }
      return value;
    }
    default:
      return value;
  }
}
function applySchemaObjectCoercion(value, schema) {
  const properties = schema.properties;
  const definedKeys = new Set(properties ? Object.keys(properties) : []);
  if (properties) {
    for (const [key, propertySchema] of Object.entries(properties)) {
      if (!(key in value)) {
        continue;
      }
      value[key] = coerceWithJsonSchema(value[key], propertySchema);
    }
  }
  if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
    for (const [key, propertyValue] of Object.entries(value)) {
      if (definedKeys.has(key)) {
        continue;
      }
      value[key] = coerceWithJsonSchema(propertyValue, schema.additionalProperties);
    }
  }
}
function applySchemaArrayCoercion(value, schema) {
  if (Array.isArray(schema.items)) {
    for (let index3 = 0; index3 < value.length; index3++) {
      const itemSchema = schema.items[index3];
      if (!itemSchema) {
        continue;
      }
      value[index3] = coerceWithJsonSchema(value[index3], itemSchema);
    }
    return;
  }
  if (schema.items && typeof schema.items === "object") {
    for (let index3 = 0; index3 < value.length; index3++) {
      value[index3] = coerceWithJsonSchema(value[index3], schema.items);
    }
  }
}
function coerceWithUnionSchema(value, schemas) {
  for (const schema of schemas) {
    const validator = getSubSchemaValidator(schema);
    if (validator?.Check(value)) {
      return value;
    }
  }
  for (const schema of schemas) {
    const candidate = structuredClone(value);
    const coerced = coerceWithJsonSchema(candidate, schema);
    const validator = getSubSchemaValidator(schema);
    if (validator?.Check(coerced)) {
      return coerced;
    }
  }
  return value;
}
function coerceWithJsonSchema(value, schema) {
  let nextValue = value;
  if (Array.isArray(schema.allOf)) {
    for (const nested of schema.allOf) {
      nextValue = coerceWithJsonSchema(nextValue, nested);
    }
  }
  if (Array.isArray(schema.anyOf)) {
    nextValue = coerceWithUnionSchema(nextValue, schema.anyOf);
  }
  if (Array.isArray(schema.oneOf)) {
    nextValue = coerceWithUnionSchema(nextValue, schema.oneOf);
  }
  const schemaTypes = getSchemaTypes(schema);
  const matchesUnionMember = schemaTypes.length > 1 && schemaTypes.some((schemaType) => matchesJsonType(nextValue, schemaType));
  if (schemaTypes.length > 0 && !matchesUnionMember) {
    for (const schemaType of schemaTypes) {
      const candidate = coercePrimitiveByType(nextValue, schemaType);
      if (candidate !== nextValue) {
        nextValue = candidate;
        break;
      }
    }
  }
  if (schemaTypes.includes("object") && typeof nextValue === "object" && nextValue !== null && !Array.isArray(nextValue)) {
    applySchemaObjectCoercion(nextValue, schema);
  }
  if (schemaTypes.includes("array") && Array.isArray(nextValue)) {
    applySchemaArrayCoercion(nextValue, schema);
  }
  return nextValue;
}
function normalizeOptionalNulls(value, schema) {
  if (Array.isArray(value)) {
    if (Array.isArray(schema.items)) {
      for (let index3 = 0; index3 < value.length; index3++) {
        const itemSchema = schema.items[index3];
        if (itemSchema)
          normalizeOptionalNulls(value[index3], itemSchema);
      }
    } else if (schema.items) {
      for (const item of value)
        normalizeOptionalNulls(item, schema.items);
    }
    return;
  }
  if (typeof value !== "object" || value === null || !schema.properties)
    return;
  const object = value;
  const required = new Set(schema.required ?? []);
  for (const [key, propertySchema] of Object.entries(schema.properties)) {
    if (!(key in object))
      continue;
    if (object[key] === null && !required.has(key) && typeof propertySchema.$ref !== "string" && getSubSchemaValidator(propertySchema)?.Check(null) === false) {
      delete object[key];
    } else {
      normalizeOptionalNulls(object[key], propertySchema);
    }
  }
}
function getValidator(schema) {
  const key = schema;
  const cached = validatorCache.get(key);
  if (cached) {
    return cached;
  }
  const validator = Compile(schema);
  validatorCache.set(key, validator);
  return validator;
}
function formatValidationPath(error) {
  if (error.keyword === "required") {
    const requiredProperties = error.params.requiredProperties;
    const requiredProperty = requiredProperties?.[0];
    if (requiredProperty) {
      const basePath = error.instancePath.replace(/^\//, "").replace(/\//g, ".");
      return basePath ? `${basePath}.${requiredProperty}` : requiredProperty;
    }
  }
  const path = error.instancePath.replace(/^\//, "").replace(/\//g, ".");
  return path || "root";
}
function validateToolArguments(tool, toolCall) {
  const args = structuredClone(toolCall.arguments);
  normalizeOptionalNulls(args, tool.parameters);
  value_exports.Convert(tool.parameters, args);
  const validator = getValidator(tool.parameters);
  if (!Object.getOwnPropertySymbols(tool.parameters).includes(TYPEBOX_KIND)) {
    const coerced = coerceWithJsonSchema(args, tool.parameters);
    if (coerced !== args) {
      if (typeof args === "object" && args !== null && typeof coerced === "object" && coerced !== null) {
        for (const key of Object.keys(args)) {
          delete args[key];
        }
        Object.assign(args, coerced);
      } else {
        return validator.Check(coerced) ? coerced : args;
      }
    }
  }
  if (validator.Check(args)) {
    return args;
  }
  const errors = validator.Errors(args).map((error) => `  - ${formatValidationPath(error)}: ${error.message}`).join("\n") || "Unknown validation error";
  const errorMessage = `Validation failed for tool "${toolCall.name}":
${errors}

Received arguments:
${JSON.stringify(toolCall.arguments, null, 2)}`;
  throw new Error(errorMessage);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/truncate.js
var DEFAULT_MAX_LINES = 2e3;
var DEFAULT_MAX_BYTES = 50 * 1024;
var runtimeBuffer = globalThis.Buffer;
var nonAsciiPattern = /[^\x00-\x7f]/;
function utf8ByteLength(content) {
  if (runtimeBuffer)
    return runtimeBuffer.byteLength(content, "utf8");
  const firstNonAscii = content.search(nonAsciiPattern);
  if (firstNonAscii === -1)
    return content.length;
  let bytes = firstNonAscii;
  for (let i = firstNonAscii; i < content.length; i++) {
    const code = content.charCodeAt(i);
    if (code <= 127) {
      bytes += 1;
    } else if (code <= 2047) {
      bytes += 2;
    } else if (code >= 55296 && code <= 56319 && i + 1 < content.length) {
      const next = content.charCodeAt(i + 1);
      if (next >= 56320 && next <= 57343) {
        bytes += 4;
        i++;
      } else {
        bytes += 3;
      }
    } else {
      bytes += 3;
    }
  }
  return bytes;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/output.js
var NEWLINE = 10;
var INVALID_OUTPUT = /[\x00-\x08\x0b-\x1f\ufff9-\ufffb]/g;
var encoder2 = new TextEncoder();
var decoder2 = new TextDecoder();
function sanitizeOutput(text) {
  return text.replace(INVALID_OUTPUT, "");
}
function boundOutput(text, limits) {
  const bytes = encoder2.encode(text);
  const [from, to] = limits.retain === "head" ? headRange(bytes, limits) : tailRange(bytes, limits);
  const kept = bytes.subarray(from, to);
  return {
    text: kept.length === bytes.length ? text : decoder2.decode(kept),
    bytes: kept.length,
    droppedBytes: bytes.length - kept.length,
    droppedLines: lineCount(bytes) - lineCount(kept)
  };
}
function headRange(bytes, limits) {
  if (limits.maxLines === 0 || limits.maxBytes === 0)
    return [0, 0];
  let end = bytes.length;
  let lines2 = 0;
  for (let index3 = bytes.indexOf(NEWLINE); index3 !== -1; index3 = bytes.indexOf(NEWLINE, index3 + 1)) {
    if (++lines2 === limits.maxLines) {
      end = index3 + 1;
      break;
    }
  }
  if (end > limits.maxBytes) {
    const newline = bytes.lastIndexOf(NEWLINE, limits.maxBytes - 1);
    end = newline === -1 ? characterEnd(bytes, limits.maxBytes) : newline + 1;
  }
  return [0, end];
}
function tailRange(bytes, limits) {
  if (limits.maxLines === 0 || limits.maxBytes === 0)
    return [bytes.length, bytes.length];
  const last = bytes[bytes.length - 1] === NEWLINE ? bytes.length - 2 : bytes.length - 1;
  let start = 0;
  let lines2 = 1;
  for (let index3 = last < 0 ? -1 : bytes.lastIndexOf(NEWLINE, last); index3 !== -1; ) {
    if (lines2 === limits.maxLines) {
      start = index3 + 1;
      break;
    }
    lines2++;
    index3 = index3 === 0 ? -1 : bytes.lastIndexOf(NEWLINE, index3 - 1);
  }
  if (bytes.length - start > limits.maxBytes) {
    const from = bytes.length - limits.maxBytes;
    const newline = bytes.indexOf(NEWLINE, from - 1);
    start = newline !== -1 && newline + 1 < bytes.length ? newline + 1 : characterStart(bytes, from);
  }
  return [start, bytes.length];
}
function characterEnd(bytes, index3) {
  let end = index3;
  while (end > 0 && ((bytes[end] ?? 0) & 192) === 128)
    end--;
  return end;
}
function characterStart(bytes, index3) {
  let start = index3;
  while (start < bytes.length && ((bytes[start] ?? 0) & 192) === 128)
    start++;
  return start;
}
function lineCount(bytes) {
  if (bytes.length === 0)
    return 0;
  let newlines = 0;
  for (let index3 = bytes.indexOf(NEWLINE); index3 !== -1; index3 = bytes.indexOf(NEWLINE, index3 + 1))
    newlines++;
  return newlines + (bytes[bytes.length - 1] === NEWLINE ? 0 : 1);
}
var OutputBuffer = class {
  #limits;
  #decoder = new TextDecoder();
  /** Stored chunks: for head the start of the stream, for tail a suffix that still contains the next window. */
  #chunks = [];
  #storedBytes = 0;
  #storedNewlines = 0;
  #full = false;
  #totalBytes = 0;
  #totalNewlines = 0;
  #endsWithNewline = true;
  constructor(limits) {
    this.#limits = limits;
  }
  /** Bytes currently held; bounded by the limits plus one chunk. */
  get storedBytes() {
    return this.#storedBytes;
  }
  /** Accept a chunk; returns whether anything was accepted. */
  push(chunk) {
    const text = typeof chunk === "string" ? this.#decoder.decode() + chunk : this.#decoder.decode(chunk, { stream: true });
    return this.#accept(text);
  }
  /** Flush an incomplete trailing character as a replacement character; call when the stream ends. */
  end() {
    this.#accept(this.#decoder.decode());
  }
  #accept(text) {
    if (text.length === 0)
      return false;
    const bytes = utf8ByteLength(text);
    const newlines = countNewlines(text);
    this.#totalBytes += bytes;
    this.#totalNewlines += newlines;
    this.#endsWithNewline = text.endsWith("\n");
    if (this.#full)
      return true;
    this.#chunks.push({ text, bytes, newlines });
    this.#storedBytes += bytes;
    this.#storedNewlines += newlines;
    if (this.#limits.retain === "head") {
      this.#full = this.#storedBytes > this.#limits.maxBytes || this.#storedNewlines >= this.#limits.maxLines;
      return true;
    }
    while (this.#chunks.length > 1) {
      const first = this.#chunks[0];
      const bytesAfter = this.#storedBytes - first.bytes;
      const newlinesAfter = this.#storedNewlines - first.newlines;
      if (bytesAfter <= this.#limits.maxBytes + 1 && newlinesAfter <= this.#limits.maxLines + 1)
        break;
      this.#chunks.shift();
      this.#storedBytes = bytesAfter;
      this.#storedNewlines = newlinesAfter;
    }
    return true;
  }
  /** Retained, sanitized output and what the limits dropped from the whole stream. */
  snapshot() {
    const stored = this.#chunks.length === 1 ? this.#chunks[0].text : this.#chunks.map((chunk) => chunk.text).join("");
    const kept = boundOutput(stored, this.#limits);
    const storedLines = lines(this.#storedNewlines, stored === "" || stored.endsWith("\n"));
    const keptLines = storedLines - kept.droppedLines;
    if (this.#limits.retain === "tail" || this.#chunks.length > 1) {
      const text = this.#limits.retain === "tail" ? kept.text : stored;
      const bytes = this.#limits.retain === "tail" ? kept.bytes : this.#storedBytes;
      this.#chunks = text === "" ? [] : [{ text, bytes, newlines: countNewlines(text) }];
      this.#storedBytes = bytes;
      this.#storedNewlines = this.#chunks[0]?.newlines ?? 0;
    }
    return {
      text: sanitizeOutput(kept.text),
      droppedBytes: this.#totalBytes - kept.bytes,
      droppedLines: lines(this.#totalNewlines, this.#endsWithNewline) - keptLines
    };
  }
};
function lines(newlines, terminated) {
  return newlines + (terminated ? 0 : 1);
}
function countNewlines(text) {
  let count = 0;
  for (let index3 = text.indexOf("\n"); index3 !== -1; index3 = text.indexOf("\n", index3 + 1))
    count++;
  return count;
}
var MIN_PROGRESS_INTERVAL_MS = 100;
var PROGRESS_BYTES_PER_SECOND = 100 * 1024;
var Progress = class {
  #write;
  #onError;
  #waiters = [];
  #timer;
  #inFlight;
  #nextAt = 0;
  #dirty = false;
  #stopped = false;
  constructor(write, onError) {
    this.#write = write;
    this.#onError = onError;
  }
  /** Schedule a commit. */
  mark() {
    this.#dirty = true;
    this.#schedule();
  }
  /** Schedule a commit; the promise settles with the commit that includes this change. */
  markAndWait() {
    const waiter = Promise.withResolvers();
    this.#waiters.push(waiter);
    this.mark();
    return waiter.promise;
  }
  /** Stop committing and wait for the commit in flight; returns the waiters the final commit must settle. */
  async stop() {
    this.#stopped = true;
    clearTimeout(this.#timer);
    this.#timer = void 0;
    await this.#inFlight;
    return this.#waiters.splice(0);
  }
  #schedule() {
    if (this.#stopped || this.#timer !== void 0 || this.#inFlight !== void 0)
      return;
    const wait = this.#nextAt - Date.now();
    if (wait <= 0)
      this.#flush();
    else
      this.#timer = setTimeout(() => {
        this.#timer = void 0;
        this.#flush();
      }, wait);
  }
  #flush() {
    if (this.#stopped || !this.#dirty)
      return;
    this.#dirty = false;
    const waiters = this.#waiters.splice(0);
    const started = Date.now();
    this.#inFlight = this.#write().then((bytes) => {
      this.#nextAt = started + Math.max(MIN_PROGRESS_INTERVAL_MS, bytes * 1e3 / PROGRESS_BYTES_PER_SECOND);
      for (const waiter of waiters)
        waiter.resolve();
    }, (error) => {
      this.#nextAt = started + MIN_PROGRESS_INTERVAL_MS;
      for (const waiter of waiters)
        waiter.reject(error);
      this.#onError(error);
    }).finally(() => {
      this.#inFlight = void 0;
      if (this.#dirty)
        this.#schedule();
    });
  }
};

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/usage.js
var UsageDoc = defineDoc({
  kind: "pi.usage",
  version: 1,
  scope: "conversation",
  history: "latest",
  fork: "initial",
  initial: () => ({ models: {}, tools: {} }),
  checkpointWhen: () => true
});
async function recordUsage(tx, conversationId, bucket, key, usage) {
  const totals = (await tx.doc(UsageDoc, conversationId))[bucket];
  const total = Object.hasOwn(totals, key) ? totals[key] : void 0;
  if (total === void 0)
    totals[key] = copyJson(usage, { omitUndefinedProperties: true });
  else
    addUsage(total, usage);
}
function addUsage(total, usage) {
  total.input += usage.input;
  total.output += usage.output;
  total.cacheRead += usage.cacheRead;
  total.cacheWrite += usage.cacheWrite;
  total.totalTokens += usage.totalTokens;
  if (usage.cacheWrite1h !== void 0)
    total.cacheWrite1h = (total.cacheWrite1h ?? 0) + usage.cacheWrite1h;
  if (usage.reasoning !== void 0)
    total.reasoning = (total.reasoning ?? 0) + usage.reasoning;
  total.cost.input += usage.cost.input;
  total.cost.output += usage.cost.output;
  total.cost.cacheRead += usage.cost.cacheRead;
  total.cost.cacheWrite += usage.cost.cacheWrite;
  total.cost.total += usage.cost.total;
}
function addUsageState(sum, state2) {
  for (const bucket of ["models", "tools"]) {
    for (const [key, usage] of Object.entries(state2[bucket])) {
      const total = Object.hasOwn(sum[bucket], key) ? sum[bucket][key] : void 0;
      if (total !== void 0)
        addUsage(total, usage);
      else
        Object.defineProperty(sum[bucket], key, {
          value: structuredClone(usage),
          enumerable: true,
          writable: true
        });
    }
  }
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/tool.js
var ToolTask = defineTask({
  name: "pi.tool",
  version: 1,
  initial: () => ({ phase: "call" }),
  phases: {
    call: async (task, runtime, context) => {
      const call = await readCall(runtime, task.input, context);
      const tool = (await runtime.agent(context)).tools.find((each) => each.name === call.name);
      if (tool === void 0) {
        const error = harnessError("tool_unavailable", `Tool ${call.name} is not available`);
        return settle(runtime, call, COMPLETED, () => error, context);
      }
      const prepared = prepare(tool, call.arguments);
      const checked = "error" in prepared ? prepared : validate(tool, call, prepared.args);
      if ("error" in checked)
        return settle(runtime, call, COMPLETED, () => invalid(checked.error), context);
      let args = checked.args;
      let block;
      await runtime.hooks.each("beforeTool", async (hook2) => {
        if (block !== void 0)
          return;
        try {
          const decision = await hook2({ ...call, arguments: args }, runtime, context);
          if (decision?.block !== void 0)
            block = decision.block;
          else if (decision?.arguments !== void 0)
            args = decision.arguments;
        } catch (error) {
          if (runtime.signal.aborted)
            throw error;
          block = errorText(error);
        }
      });
      if (block !== void 0) {
        const blocked = harnessError("blocked", `Tool call blocked: ${block}`);
        return settle(runtime, call, COMPLETED, () => blocked, context);
      }
      const validated = validate(tool, call, args);
      if ("error" in validated)
        return settle(runtime, call, COMPLETED, () => invalid(validated.error), context);
      const final = validated.args;
      await runtime.commit(async (tx) => {
        const slot = toolSlot(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
        if (slot !== void 0)
          slot.status = "running";
        const intent = { phase: "execute", arguments: final, replay: tool.replay ?? "unsafe" };
        return { status: "running", checkpoint: intent };
      }, context);
      await run(runtime, call, tool, final, context);
    },
    /** Recovery after intent: rerun only when the stored and the current policy both say `safe`. */
    execute: async (task, runtime, context) => {
      const { arguments: args, replay } = task.state.checkpoint;
      const call = await readCall(runtime, task.input, context);
      const tool = (await runtime.agent(context)).tools.find((each) => each.name === call.name);
      if (replay === "safe" && tool?.replay === "safe") {
        await runtime.commit(async (tx) => {
          const slot = toolSlot(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
          if (slot !== void 0)
            clearProgress(slot);
          return void 0;
        }, context);
        return run(runtime, call, tool, args, context);
      }
      const message = `Tool ${call.name} was interrupted and may have partially run`;
      const ending = { status: "failed", message };
      await settle(runtime, call, ending, (slot) => fromSlot(slot, "interrupted", message), context);
    }
  },
  abort: async (task, runtime, context) => {
    const call = await readCall(runtime, task.input, context);
    const message = `Tool ${call.name} was aborted`;
    await settle(runtime, call, { status: "aborted" }, (slot) => fromSlot(slot, "aborted", message), context);
  }
});
async function readCall(runtime, input, context) {
  const entry = await runtime.entry(AssistantEntry, input.assistant, context);
  const message = entry?.model?.[0];
  const call = message?.role === "assistant" ? message.content.find((content) => content.type === "toolCall" && content.id === input.callId) : void 0;
  if (call === void 0)
    throw new Error(`Entry ${input.assistant} has no tool call ${input.callId}`);
  return call;
}
function prepare(tool, args) {
  if (tool.prepareArguments === void 0)
    return { args };
  try {
    return { args: tool.prepareArguments(args) };
  } catch (error) {
    return { error: errorText(error) };
  }
}
function validate(tool, call, args) {
  try {
    return { args: validateToolArguments(tool, { ...call, arguments: args }) };
  } catch (error) {
    return { error: errorText(error) };
  }
}
function invalid(message) {
  return harnessError("invalid_arguments", message);
}
async function run(runtime, call, tool, args, context) {
  const limits = {
    maxBytes: tool.outputLimits?.maxBytes ?? DEFAULT_MAX_BYTES,
    maxLines: tool.outputLimits?.maxLines ?? DEFAULT_MAX_LINES,
    retain: tool.outputLimits?.retain ?? "head"
  };
  const reported = { output: new OutputBuffer(limits), limits, diagnostics: [], details: void 0 };
  const progress = publishProgress(runtime, reported, context);
  let ended = false;
  const assertLive = () => {
    if (ended)
      throw new Error(`Tool call ${call.id} has settled`);
  };
  const api = {
    taskId: runtime.taskId,
    conversationId: runtime.conversationId,
    callId: call.id,
    registry: runtime.registry,
    agent: runtime.agent,
    output: (chunk) => {
      assertLive();
      if (reported.output.push(chunk))
        progress.mark();
    },
    diagnostic: (diagnostic) => {
      assertLive();
      reported.diagnostics.push(copyJson(diagnostic, { omitUndefinedProperties: true }));
      progress.mark();
    },
    details: async (value, detailsContext) => {
      assertLive();
      detailsContext.abortSignal?.throwIfAborted();
      reported.details = copyJson(value, { omitUndefinedProperties: true });
      const committed = progress.markAndWait();
      committed.catch(() => {
      });
      return awaitWithContext(committed, detailsContext);
    },
    commit: async (change, commitContext) => {
      let result2;
      await runtime.commit(async (tx) => {
        result2 = await change(tx);
        return void 0;
      }, commitContext);
      return result2;
    },
    memo: runtime.memo,
    createTask: async (task, input, options, taskContext) => {
      let id;
      await runtime.commit(async (tx) => {
        id = await tx.createTask(task, input, options);
        return void 0;
      }, taskContext);
      return id;
    },
    getTask: runtime.getTask,
    waitForTask: runtime.waitForTask,
    conversation: runtime.conversation,
    snapshot: runtime.snapshot,
    snapshotAsOf: runtime.snapshotAsOf,
    watchDoc: runtime.watchDoc
  };
  let result;
  let ending = COMPLETED;
  try {
    const env = await runtime.env(context);
    result = await tool.execute(args, { ...api, env }, context);
  } catch (error) {
    if (runtime.signal.aborted) {
      ended = true;
      for (const waiter of await progress.stop())
        waiter.reject(error);
      throw error;
    }
    result = { isError: true, diagnostics: [toolDiagnostic("tool_error", errorText(error))] };
    ending = { status: "failed", message: `Tool ${call.name} threw` };
  }
  ended = true;
  reported.output.end();
  const pending = await progress.stop();
  try {
    const settled = await finalResult(runtime, call, result, reported, context);
    await settle(runtime, call, ending, () => settled, context);
  } catch (error) {
    for (const waiter of pending)
      waiter.reject(error);
    throw error;
  }
  for (const waiter of pending)
    waiter.resolve();
}
function publishProgress(runtime, reported, context) {
  let written = { text: "", details: void 0, diagnostics: 0 };
  return new Progress(async () => {
    const snapshot = reported.output.snapshot();
    const current = { text: snapshot.text, details: reported.details, diagnostics: reported.diagnostics.length };
    const added = reported.diagnostics.slice(written.diagnostics, current.diagnostics);
    const detailsChanged = current.details !== written.details;
    let bytes = 0;
    if (snapshot.text !== written.text) {
      const shared = snapshot.text.startsWith(written.text) ? written.text.length : overlap(written.text, snapshot.text, 65536);
      bytes += utf8ByteLength(snapshot.text.slice(shared));
    }
    if (detailsChanged)
      bytes += utf8ByteLength(JSON.stringify(current.details ?? null));
    if (added.length > 0)
      bytes += utf8ByteLength(JSON.stringify(added));
    await runtime.commit(async (tx) => {
      const slot = toolSlot(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
      if (slot === void 0)
        return void 0;
      if ((slot.output ?? "") !== snapshot.text)
        slot.output = snapshot.text;
      if (snapshot.droppedBytes > 0)
        slot.droppedBytes = snapshot.droppedBytes;
      if (snapshot.droppedLines > 0)
        slot.droppedLines = snapshot.droppedLines;
      if (detailsChanged && current.details !== void 0) {
        assignJson(slot, "details", current.details);
      }
      if (added.length > 0) {
        if (slot.diagnostics === void 0)
          slot.diagnostics = [];
        for (const diagnostic of added)
          slot.diagnostics.push(diagnostic);
      }
      return void 0;
    }, context);
    written = current;
    return bytes;
  }, (error) => {
    if (!runtime.signal.aborted)
      runtime.report(error);
  });
}
async function finalResult(runtime, call, result, reported, context) {
  const harness = [];
  const retained = result.content === void 0 ? reported.output.snapshot() : void 0;
  const content = retained === void 0 ? result.content : retained.text === "" ? [] : [{ type: "text", text: retained.text }];
  let final = {
    ...result,
    content,
    details: result.details === void 0 ? reported.details : result.details,
    diagnostics: [...reported.diagnostics, ...result.diagnostics ?? []]
  };
  await runtime.hooks.each("afterTool", async (hook2) => {
    final = await hook2(call, final, runtime, context) ?? final;
  });
  if (retained !== void 0 && retained.droppedBytes > 0 && final.content === content) {
    harness.push(truncated(retained, reported.limits.retain));
  }
  const bounded = boundContent(final.content ?? [], reported.limits);
  if (bounded.droppedBytes > 0)
    harness.push(truncated(bounded, reported.limits.retain));
  return { ...final, content: bounded.content, diagnostics: [...final.diagnostics ?? [], ...harness] };
}
async function settle(runtime, call, ending, build, context) {
  await runtime.commit(async (tx) => {
    const slot = toolSlot(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
    const result = build(slot);
    const entry = await appendToolResult(tx, runtime.conversationId, call, result, runtime.now());
    if (slot !== void 0)
      finishSlot(slot, entry.id);
    const entryId = entry.id;
    if (ending.status === "aborted")
      return { status: "terminal", outcome: { status: "aborted", result: { entryId } } };
    if (ending.status === "failed") {
      const error = { message: ending.message };
      return { status: "terminal", outcome: { status: "failed", error, result: { entryId } } };
    }
    const control = result.control === void 0 ? {} : { control: copyJson(result.control, { omitUndefinedProperties: true }) };
    return { status: "terminal", outcome: { status: "completed", result: { entryId, ...control } } };
  }, context);
}
var COMPLETED = { status: "completed" };
function fromSlot(slot, code, message) {
  const diagnostics = [...slot?.diagnostics ?? []];
  const droppedBytes = slot?.droppedBytes ?? 0;
  if (droppedBytes > 0)
    diagnostics.push(truncated({ droppedBytes, droppedLines: slot?.droppedLines ?? 0 }));
  diagnostics.push(toolDiagnostic(code, message));
  return {
    content: slot?.output === void 0 || slot.output === "" ? [] : [{ type: "text", text: slot.output }],
    isError: true,
    ...slot?.details === void 0 ? {} : { details: slot.details },
    diagnostics
  };
}
function harnessError(code, message) {
  return { content: [], isError: true, diagnostics: [toolDiagnostic(code, message)] };
}
function toolDiagnostic(code, message) {
  return { severity: "error", code, message };
}
function truncated(dropped, retain) {
  const kept = retain === void 0 ? "" : ` to its ${retain === "head" ? "beginning" : "end"}`;
  return {
    severity: "warn",
    code: "truncated",
    message: `Output truncated${kept}: ${dropped.droppedLines} lines, ${dropped.droppedBytes} bytes dropped`
  };
}
async function appendToolResult(tx, conversationId, call, result, timestamp) {
  const diagnostics = [...result.diagnostics ?? []];
  const content = [...result.content ?? []];
  if (diagnostics.length > 0)
    content.push({ type: "text", text: renderDiagnostics(diagnostics) });
  const message = {
    role: "toolResult",
    toolCallId: call.id,
    toolName: call.name,
    content,
    ...result.details === void 0 ? {} : { details: result.details },
    ...result.usage === void 0 ? {} : { usage: result.usage },
    isError: result.isError ?? false,
    timestamp
  };
  if (result.usage !== void 0)
    await recordUsage(tx, conversationId, "tools", call.name, result.usage);
  return tx.appendEntry(ToolResultEntry, conversationId, { model: [message], data: { diagnostics } });
}
function renderDiagnostics(diagnostics) {
  return `<harness>
${diagnostics.map((diagnostic) => `[${diagnostic.severity}] ${diagnostic.message}`).join("\n")}
</harness>`;
}
function boundContent(content, limits) {
  const texts = content.filter((item) => item.type === "text");
  const bounded = boundOutput(texts.map((item) => item.text).join(""), limits);
  if (bounded.droppedBytes === 0)
    return { content, droppedBytes: 0, droppedLines: 0 };
  const keep = limits.retain === "head" ? texts[0] : texts.at(-1);
  const result = [];
  for (const item of content) {
    if (item.type !== "text")
      result.push(item);
    else if (item === keep)
      result.push({ ...item, text: bounded.text });
  }
  return { content: result, droppedBytes: bounded.droppedBytes, droppedLines: bounded.droppedLines };
}
function errorText(error) {
  return error instanceof Error ? error.message : String(error);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/generation.js
var PARTIAL_THROTTLE_MS = 100;
var DEFAULT_POLL_AFTER_MS = 5e3;
var GenerationTask = defineTask({
  name: "pi.generation",
  version: 1,
  initial: () => ({ phase: "prepare", attempt: 1 }),
  phases: {
    /**
     * Render the system prompt and tool loadout and append the positional `pi.system` entries they need, then move to
     * `request`. The agent and settings resolved here are fixed for this request. Only the Harness writes to a busy
     * conversation, so the transcript read here is still the tail at the commit.
     */
    prepare: async (task, runtime, context) => {
      const { conversationId } = runtime;
      const agent = await runtime.agent(context);
      const settings = runtime.settings;
      const { model, thinkingLevel } = agent;
      const resolved = model === void 0 ? void 0 : runtime.models.getModel(model.provider, model.modelId);
      if (model === void 0 || resolved === void 0)
        return failNoModel(runtime, model, context);
      const { attempt, compacted, overflow } = task.state.checkpoint;
      if (compacted !== void 0 && overflow !== void 0) {
        const [outcome] = await runtime.outcomes([compacted], context);
        if (outcome?.status !== "completed" || outcome.result.entryId === void 0) {
          return failModelError(runtime, overflow, context);
        }
      }
      const view = await runtime.context(conversationId, context);
      const shown = replaySections(view.messages);
      const report = (error) => runtime.report(error);
      let env;
      try {
        env = await runtime.env(context);
      } catch (error) {
        if (context.abortSignal?.aborted)
          throw error;
        report(error);
      }
      const input = { conversationId, agent, env, shown: Object.fromEntries(shown), read: runtime };
      const desired = await renderSections(agent.sections, input, shown, report, context);
      const entries = planSystemEntries(view, desired, agent.tools, runtime.now());
      const threshold = compacted === void 0 ? thresholdCompaction(view, entries, resolved.contextWindow, settings.compaction) : void 0;
      if (threshold === "blocking") {
        await runtime.commit(async (tx) => {
          const child = await createCompaction(tx, conversationId, { reason: "threshold" }, runtime.taskId);
          const checkpoint = { phase: "prepare", attempt, compacted: child };
          return { status: "waiting", checkpoint, on: [child], policy: "allSettled" };
        }, context);
        return;
      }
      await runtime.commit(async (tx) => {
        let cutoff = (await tx.scanEntries({ conversationId }, 1)).items[0]?.id;
        for (const entry of entries)
          cutoff = (await tx.appendEntry(SystemEntry, conversationId, entry)).id;
        if (cutoff === void 0)
          throw new Error(`Conversation ${conversationId} has no entries to send`);
        if (threshold === "background" && (await tx.doc(LiveDoc, conversationId)).compactions === void 0) {
          await createCompaction(tx, conversationId, { reason: "threshold" });
        }
        const request = {
          attempt,
          ...compacted === void 0 ? {} : { compacted },
          model,
          thinkingLevel,
          streamOptions: settings.stream,
          cutoff
        };
        return { status: "running", checkpoint: { phase: "request", ...request } };
      }, context);
    },
    request: async (task, runtime, context) => {
      const { attempt, compacted, model: ref, thinkingLevel, streamOptions, cutoff } = task.state.checkpoint;
      const conversationId = runtime.conversationId;
      await runtime.commit(async (tx) => {
        const live = await tx.doc(LiveDoc, conversationId);
        await convertPartial(tx, live, conversationId);
        live.generation = { attempt };
        return void 0;
      }, context);
      const model = runtime.models.getModel(ref.provider, ref.modelId);
      if (model === void 0)
        return failNoModel(runtime, ref, context);
      const view = await runtime.context(conversationId, context, cutoff);
      let messages = view.messages;
      await runtime.hooks.each("beforeRequest", async (hook2) => {
        const replaced = await hook2({ messages }, runtime, context);
        if (replaced !== void 0)
          messages = replaced.messages;
      });
      const options = {
        ...streamOptions,
        signal: runtime.signal,
        ...thinkingLevel === "off" ? {} : { reasoning: thinkingLevel }
      };
      const message = await streamResponse(runtime, model, messages, options, attempt, context);
      const request = { attempt, compacted, model: ref, cutoff, messages: view.messages };
      await classify(runtime, request, message, context);
    },
    retry: async (task, runtime, context) => {
      const { attempt, compacted, until } = task.state.checkpoint;
      await runtime.sleep(until, context);
      await runtime.commit(async (tx) => {
        (await tx.doc(LiveDoc, runtime.conversationId)).generation = { attempt: attempt + 1 };
        const checkpoint = {
          phase: "prepare",
          attempt: attempt + 1,
          ...compacted === void 0 ? {} : { compacted }
        };
        return { status: "running", checkpoint };
      }, context);
    },
    poll: async (task, runtime, context) => {
      const { attempt, compacted, model: ref, cutoff, handle, pollAt } = task.state.checkpoint;
      const model = runtime.models.getModel(ref.provider, ref.modelId);
      if (model === void 0)
        return failNoModel(runtime, ref, context);
      await runtime.sleep(pollAt, context);
      const message = await runtime.models.fetchDeferred(model, handle, { signal: runtime.signal });
      const request = { attempt, compacted, model: ref, cutoff, pollAt };
      await classify(runtime, request, message, context);
    },
    tools: async (task, runtime, context) => {
      const { assistant, tools, pending } = task.state.checkpoint;
      const [next, ...rest] = pending;
      if (next === void 0)
        return finishToolRound(runtime, assistant, tools, context);
      await runtime.commit(async (tx) => {
        const live = await tx.doc(LiveDoc, runtime.conversationId);
        const taskId = await createToolTask(tx, runtime, assistant, next);
        const slot = live.tools?.find((slot2) => slot2.callId === next && slot2.taskId === void 0);
        if (slot !== void 0)
          slot.taskId = taskId;
        const checkpoint = {
          phase: "tools",
          assistant,
          tools: [...tools, taskId],
          pending: rest
        };
        return { status: "waiting", checkpoint, on: [taskId], policy: "allSettled" };
      }, context);
    }
  },
  abort: async (task, runtime, context) => {
    const checkpoint = task.state.checkpoint;
    if (checkpoint.phase === "poll") {
      const model = runtime.models.getModel(checkpoint.model.provider, checkpoint.model.modelId);
      if (model !== void 0) {
        try {
          await runtime.models.cancelDeferred(model, checkpoint.handle, { signal: runtime.signal });
        } catch (error) {
          runtime.report(error);
        }
      }
    }
    const conversationId = runtime.conversationId;
    const unstarted = checkpoint.phase === "tools" ? await readCalls(runtime, checkpoint.assistant, checkpoint.pending, context) : [];
    await runtime.commit(async (tx) => {
      const live = await tx.doc(LiveDoc, conversationId);
      await convertPartial(tx, live, conversationId);
      for (const call of unstarted) {
        const result = harnessError("aborted", `Tool ${call.name} was aborted`);
        await appendToolResult(tx, conversationId, call, result, runtime.now());
      }
      endRun(tx, live, runtime.taskId, { status: "unanswered", reason: "aborted" });
      return { status: "terminal", outcome: { status: "aborted" } };
    }, context);
  }
});
async function readCalls(runtime, assistant, callIds, context) {
  const message = (await runtime.entry(AssistantEntry, assistant, context))?.model?.[0];
  const calls = message?.role === "assistant" ? message.content.filter((content) => content.type === "toolCall") : [];
  return callIds.flatMap((id) => calls.filter((call) => call.id === id).slice(0, 1));
}
function createToolTask(tx, runtime, assistant, callId) {
  return tx.createTask(ToolTask, { assistant, callId }, { ownership: { kind: "task", taskId: runtime.taskId } });
}
function thresholdCompaction(view, planned, contextWindow, policy) {
  if (!policy.enabled || contextWindow <= 0)
    return void 0;
  const tokens = estimateContext(view, planned.flatMap((entry) => entry.model ?? []));
  const blocking = contextWindow - policy.reserveTokens;
  const background = blocking - policy.backgroundTokens;
  const over = tokens > blocking ? "blocking" : policy.backgroundTokens > 0 && tokens > background ? "background" : void 0;
  if (over === void 0 || selectCut(view, policy.keepRecentTokens) === void 0)
    return void 0;
  return over;
}
async function failModelError(runtime, text, context) {
  await runtime.commit(async (tx) => {
    const live = await tx.doc(LiveDoc, runtime.conversationId);
    endRun(tx, live, runtime.taskId, { status: "unanswered", reason: "model_error", detail: text });
    return {
      status: "terminal",
      outcome: { status: "failed", error: { message: text, detail: { reason: "model_error" } } }
    };
  }, context);
}
async function failNoModel(runtime, ref, context) {
  const message = ref === void 0 ? "No model is configured" : `Model ${ref.provider}/${ref.modelId} is not available`;
  await runtime.commit(async (tx) => {
    const live = await tx.doc(LiveDoc, runtime.conversationId);
    endRun(tx, live, runtime.taskId, { status: "unanswered", reason: "no_model" });
    return { status: "terminal", outcome: { status: "failed", error: { message, detail: { reason: "no_model" } } } };
  }, context);
}
async function convertPartial(tx, live, conversationId) {
  const partial = live.generation?.message;
  if (partial === void 0)
    return;
  const message = copyJson(partial);
  await appendAssistant(tx, conversationId, { ...message, stopReason: "aborted" });
}
async function streamResponse(runtime, model, messages, options, attempt, context) {
  let pending;
  let timer;
  let inFlight;
  let stopped = false;
  const flush = () => {
    timer = void 0;
    const partial = pending;
    pending = void 0;
    if (partial === void 0 || stopped)
      return;
    inFlight = (async () => {
      const message = copyJson(partial, { omitUndefinedProperties: true });
      await runtime.commit(async (tx) => {
        const live = await tx.doc(LiveDoc, runtime.conversationId);
        live.generation ??= { attempt };
        assignJson(live.generation, "message", message);
        return void 0;
      }, context);
    })().catch((error) => {
      if (!runtime.signal.aborted)
        runtime.report(error);
    }).finally(() => {
      inFlight = void 0;
      if (pending !== void 0 && !stopped)
        timer = setTimeout(flush, PARTIAL_THROTTLE_MS);
    });
  };
  try {
    const events = runtime.models.streamSimple(model, { messages: [...messages] }, options);
    for await (const event of events) {
      if (event.type === "done" || event.type === "error" || event.partial.content.length === 0)
        continue;
      pending = event.partial;
      if (timer === void 0 && inFlight === void 0)
        timer = setTimeout(flush, PARTIAL_THROTTLE_MS);
    }
    return await events.result();
  } finally {
    stopped = true;
    clearTimeout(timer);
    await inFlight;
  }
}
async function classify(runtime, request, message, context) {
  runtime.signal.throwIfAborted();
  const conversationId = runtime.conversationId;
  const { attempt, compacted, model: ref, cutoff } = request;
  if (message.stopReason === "deferred" && message.deferred !== void 0) {
    const handle = message.deferred;
    const pollAt = Math.max(runtime.now() + (handle.pollAfterMs ?? DEFAULT_POLL_AFTER_MS), request.pollAt === void 0 ? Number.NEGATIVE_INFINITY : request.pollAt + 1);
    await runtime.commit(async (tx) => {
      (await tx.doc(LiveDoc, conversationId)).generation = { attempt, deferred: { pollAt } };
      const checkpoint = {
        phase: "poll",
        attempt,
        ...compacted === void 0 ? {} : { compacted },
        model: ref,
        cutoff,
        handle,
        pollAt
      };
      return { status: "running", checkpoint };
    }, context);
    return;
  }
  await runtime.hooks.each("afterResponse", (hook2) => hook2(message, runtime, context));
  const calls = message.content.filter((content) => content.type === "toolCall");
  if (message.stopReason === "toolUse" && calls.length > 0) {
    return startToolRound(runtime, request, message, calls, context);
  }
  if (message.stopReason === "stop" || message.stopReason === "length" || message.stopReason === "toolUse") {
    return answer(runtime, message, context);
  }
  const settings = runtime.settings;
  const overflow = message.stopReason === "error" && isContextOverflow(message);
  if (overflow && compacted === void 0 && settings.compaction.enabled) {
    const policy2 = settings.compaction;
    const view = await runtime.context(conversationId, context, cutoff);
    if (selectCut(view, policy2.keepRecentTokens) !== void 0) {
      const text = message.errorMessage ?? "Context overflow";
      await runtime.commit(async (tx) => {
        const live = await tx.doc(LiveDoc, conversationId);
        await appendAssistant(tx, conversationId, message);
        delete live.generation;
        const child = await createCompaction(tx, conversationId, { reason: "overflow" }, runtime.taskId);
        const checkpoint = { phase: "prepare", attempt, compacted: child, overflow: text };
        return { status: "waiting", checkpoint, on: [child], policy: "allSettled" };
      }, context);
      return;
    }
  }
  const policy = settings.retry;
  const retry = message.stopReason === "error" && !overflow && isRetryableAssistantError(message) && policy.enabled && attempt <= policy.maxRetries;
  const until = retry ? runtime.now() + retryDelayMs(policy, attempt) : 0;
  await runtime.commit(async (tx) => {
    const live = await tx.doc(LiveDoc, conversationId);
    await appendAssistant(tx, conversationId, message);
    if (retry) {
      live.generation = { attempt, retry: { at: until, error: message.errorMessage ?? "" } };
      const checkpoint = {
        phase: "retry",
        attempt,
        ...compacted === void 0 ? {} : { compacted },
        until
      };
      return { status: "running", checkpoint };
    }
    const text = message.errorMessage ?? `Model response ended with stop reason ${message.stopReason}`;
    endRun(tx, live, runtime.taskId, { status: "unanswered", reason: "model_error", detail: text });
    return {
      status: "terminal",
      outcome: { status: "failed", error: { message: text, detail: { reason: "model_error" } } }
    };
  }, context);
}
async function answer(runtime, message, context) {
  let continuation;
  await runtime.hooks.each("onYield", async (hook2) => {
    if (continuation !== void 0)
      return;
    continuation = (await hook2(message, runtime, context))?.continue;
  });
  const conversationId = runtime.conversationId;
  await runtime.commit(async (tx) => {
    const boundary = await prepareBoundary(tx, conversationId, runtime.settings);
    const live = await tx.doc(LiveDoc, conversationId);
    const entry = await appendAssistant(tx, conversationId, message);
    const result = { status: "terminal", outcome: { status: "completed", result: { entryId: entry.id } } };
    const { users, reset } = await applyBoundary(tx, boundary, "final", runtime.now());
    if (continuation !== void 0 && users.length === 0 && !reset) {
      const user = { role: "user", content: continuation, timestamp: runtime.now() };
      await tx.appendEntry(UserEntry, conversationId, { model: [user] });
      handOver(live, runtime.taskId, await createGeneration(tx, conversationId));
      delete live.generation;
      return result;
    }
    endRun(tx, live, runtime.taskId, { status: "done", answer: entry.id });
    if (users.length > 0)
      await startRun(tx, conversationId, live, users);
    return result;
  }, context);
}
async function startToolRound(runtime, request, message, calls, context) {
  const conversationId = runtime.conversationId;
  const messages = request.messages ?? (await runtime.context(conversationId, context, request.cutoff)).messages;
  const offered = new Set(getCurrentTools(messages).map((tool) => tool.name));
  const tools = (await runtime.agent(context)).tools;
  const sequential = runtime.settings.toolExecution === "sequential" || calls.some((call) => offered.has(call.name) && tools.find((tool) => tool.name === call.name)?.executionMode === "sequential");
  await runtime.commit(async (tx) => {
    const live = await tx.doc(LiveDoc, conversationId);
    const entry = await appendAssistant(tx, conversationId, message);
    const slots = [];
    const tools2 = [];
    const pending = [];
    for (const call of calls) {
      if (!offered.has(call.name)) {
        const unavailable = harnessError("tool_unavailable", `Tool ${call.name} is not available`);
        const result = await appendToolResult(tx, conversationId, call, unavailable, runtime.now());
        slots.push({ callId: call.id, name: call.name, status: "done", entry: result.id });
        continue;
      }
      if (sequential && tools2.length > 0) {
        pending.push(call.id);
        slots.push({ callId: call.id, name: call.name, status: "pending" });
        continue;
      }
      const taskId = await createToolTask(tx, runtime, entry.id, call.id);
      tools2.push(taskId);
      slots.push({ callId: call.id, name: call.name, taskId, status: "pending" });
    }
    delete live.generation;
    live.tools = slots;
    const checkpoint = { phase: "tools", assistant: entry.id, tools: tools2, pending };
    return { status: "waiting", checkpoint, on: tools2, policy: "allSettled" };
  }, context);
}
async function finishToolRound(runtime, assistant, tools, context) {
  const conversationId = runtime.conversationId;
  const controls = /* @__PURE__ */ new Map();
  const outcomes = await runtime.outcomes(tools, context);
  tools.forEach((id, index3) => {
    const outcome = outcomes[index3];
    controls.set(id, outcome.status === "completed" ? outcome.result.control : void 0);
  });
  const slots = (await runtime.snapshot(LiveDoc, conversationId, context))?.tools ?? [];
  const results = slots.flatMap((slot) => slot.entry === void 0 ? [] : [slot.entry]);
  await runtime.hooks.each("afterTools", (hook2) => hook2(assistant, results, runtime, context));
  const terminate = slots.length > 0 && slots.every((slot) => slot.taskId !== void 0 && controls.get(slot.taskId)?.terminate === true);
  const added = [...controls.values()].flatMap((control) => control?.addTools ?? []);
  const handoff = [...controls.values()].findLast((control) => control?.handoff !== void 0)?.handoff;
  await runtime.commit(async (tx) => {
    const boundary = await prepareBoundary(tx, conversationId, runtime.settings);
    if (added.length > 0)
      await addTools(tx, conversationId, added);
    const live = await tx.doc(LiveDoc, conversationId);
    const now = runtime.now();
    if (terminate || handoff !== void 0) {
      if (handoff !== void 0) {
        const message = { role: "user", content: handoff, timestamp: now };
        const entry = await tx.appendEntry(ResetEntry, conversationId, { head: "self", model: [message] });
        boundary.head = entry.id;
      }
      const { users } = await applyBoundary(tx, boundary, "final", now);
      endRun(tx, live, runtime.taskId, { status: "done", answer: assistant });
      if (users.length > 0)
        await startRun(tx, conversationId, live, users);
    } else {
      const { users, reset } = await applyBoundary(tx, boundary, "postTools", now);
      if (reset) {
        endRun(tx, live, runtime.taskId, { status: "unanswered", reason: "reset" });
        if (users.length > 0)
          await startRun(tx, conversationId, live, users);
      } else {
        delete live.tools;
        if (live.run?.taskId === runtime.taskId)
          live.run.inputs.push(...users);
        handOver(live, runtime.taskId, await createGeneration(tx, conversationId));
      }
    }
    return { status: "terminal", outcome: { status: "completed", result: { entryId: assistant } } };
  }, context);
}
async function appendAssistant(tx, conversationId, message) {
  await recordUsage(tx, conversationId, "models", `${message.provider}/${message.model}`, message.usage);
  return tx.appendEntry(AssistantEntry, conversationId, { model: [message] });
}
async function startRun(tx, conversationId, live, inputs) {
  live.run = { taskId: await createGeneration(tx, conversationId), inputs };
}
function createGeneration(tx, conversationId) {
  return tx.createTask(GenerationTask, {}, { ownership: { kind: "conversation" }, conversationId });
}
function handOver(live, from, to) {
  if (live.run?.taskId === from)
    live.run.taskId = to;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/live.js
var LiveDoc = defineDoc({
  kind: "pi.live",
  version: 1,
  scope: "conversation",
  history: "latest",
  fork: "initial",
  initial: () => ({}),
  // REMINDER: a complete base whenever nothing runs (spec §8.2): no generation and no running tool slot. That holds
  // while idle, in the commit handing a generation over to its tool round, and between tools, so the delta chain
  // spans at most one generation or the overlapping execution of one round's tools. A slot holds output only while
  // running, so every base is small. Do not add a delta-count bound; the tool output benchmark checks this rule.
  checkpointWhen: (value) => value.generation === void 0 && !(value.tools ?? []).some((slot) => slot.status === "running")
});
var RUN_TASK_KINDS = /* @__PURE__ */ new Set(["pi.generation"]);
var TOOL_TASK_KIND = "pi.tool";
var COMPACTION_TASK_KIND = "pi.compaction";
function endRun(tx, live, taskId, settlement) {
  if (live.run?.taskId === taskId) {
    for (const id of live.run.inputs)
      tx.settleSubmission(id, settlement);
    delete live.run;
  }
  delete live.generation;
  delete live.tools;
}
function addCompactionStatus(live, status) {
  live.compactions ??= [];
  live.compactions.push(status);
}
function compactionStatus(live, taskId) {
  return live.compactions?.find((status) => status.taskId === taskId);
}
function removeCompactionStatus(live, taskId) {
  const statuses = live.compactions;
  if (statuses === void 0)
    return;
  const index3 = statuses.findIndex((status) => status.taskId === taskId);
  if (index3 >= 0)
    statuses.splice(index3, 1);
  if (statuses.length === 0)
    delete live.compactions;
}
function toolSlot(live, taskId) {
  return live.tools?.find((slot) => slot.taskId === taskId);
}
function finishSlot(slot, entry) {
  slot.status = "done";
  if (entry !== void 0)
    slot.entry = entry;
  clearProgress(slot);
}
function clearProgress(slot) {
  delete slot.output;
  delete slot.droppedBytes;
  delete slot.droppedLines;
  delete slot.details;
  delete slot.diagnostics;
}
async function settleSchedulerOutcome(tx, record, outcome) {
  if (record.kind === TOOL_TASK_KIND) {
    const slot = toolSlot(await tx.doc(LiveDoc, record.conversationId), record.id);
    if (slot !== void 0)
      finishSlot(slot, void 0);
    return;
  }
  if (record.kind === COMPACTION_TASK_KIND) {
    removeCompactionStatus(await tx.doc(LiveDoc, record.conversationId), record.id);
    return;
  }
  if (!RUN_TASK_KINDS.has(record.kind))
    return;
  const live = await tx.doc(LiveDoc, record.conversationId);
  if (live.run?.taskId !== record.id)
    return;
  await convertPartial(tx, live, record.conversationId);
  endRun(tx, live, record.id, outcome.status === "faulted" ? { status: "unanswered", reason: "faulted", detail: outcome.error.message } : { status: "unanswered", reason: outcome.reason });
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/util.js
var Waiters = class {
  #sets = /* @__PURE__ */ new Map();
  add(key, context) {
    const signal = context.abortSignal;
    if (signal?.aborted)
      return Promise.reject(signal.reason);
    const waiter = Promise.withResolvers();
    const set = this.#sets.get(key) ?? /* @__PURE__ */ new Set();
    this.#sets.set(key, set.add(waiter));
    if (signal !== void 0) {
      const onAbort = () => {
        set.delete(waiter);
        if (set.size === 0 && this.#sets.get(key) === set)
          this.#sets.delete(key);
        waiter.reject(signal.reason);
      };
      signal.addEventListener("abort", onAbort, { once: true });
      const detach = () => signal.removeEventListener("abort", onAbort);
      waiter.promise.then(detach, detach);
    }
    return waiter.promise;
  }
  keys() {
    return [...this.#sets.keys()];
  }
  resolve(key, value) {
    const set = this.#sets.get(key);
    this.#sets.delete(key);
    for (const waiter of set ?? [])
      waiter.resolve(value);
  }
  rejectAll(error) {
    const sets = [...this.#sets.values()];
    this.#sets.clear();
    for (const set of sets)
      for (const waiter of set)
        waiter.reject(error);
  }
};
async function scanAll(scan) {
  const items = [];
  let cursor;
  do {
    const page2 = await scan(cursor);
    items.push(...page2.items);
    cursor = page2.next;
  } while (cursor !== void 0);
  return items;
}
function closedError() {
  return new Error("Harness is closed");
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/submissions.js
var Submissions = class {
  #session;
  #storage;
  #now;
  /** Read at each admission, on the Session line. */
  #queueModes;
  /** Enable task scheduling; submitting or waiting asks for progress. */
  #resume;
  #waiters = new Waiters();
  #closed = false;
  constructor(session, storage, now, queueModes, resume) {
    this.#session = session;
    this.#storage = storage;
    this.#now = now;
    this.#queueModes = queueModes;
    this.#resume = resume;
    session.subscribeCommits((publication) => this.#observe(publication));
    session.subscribeClose(() => {
      this.#closed = true;
      this.#waiters.rejectAll(closedError());
    });
  }
  /** Admit a submission in one commit; see `admitSubmission()`. */
  async submit(conversationId, draft, context) {
    this.#resume();
    const id = await this.#session.commitWith((tx) => admitSubmission(tx, conversationId, draft, this.#now(), this.#queueModes()), context);
    return new SubmissionHandle(id, this);
  }
  /** Handle for an existing submission, or `undefined`. */
  async get(id, context) {
    const record = await this.#session.readOnLine(() => this.#storage.submission(id, context));
    return record === void 0 ? void 0 : new SubmissionHandle(record.id, this);
  }
  async status(id, context) {
    const record = await this.#session.readOnLine(() => this.#storage.submission(id, context));
    if (record === void 0)
      throw new Error(`Submission ${id} does not exist`);
    return record;
  }
  async wait(id, context) {
    this.#resume();
    const found = await this.#session.readOnLine(async () => {
      const record = await this.#storage.submission(id, context);
      if (record === void 0)
        throw new Error(`Submission ${id} does not exist`);
      if (isSettled(record))
        return { promise: Promise.resolve(record) };
      if (this.#closed)
        throw closedError();
      return { promise: this.#waiters.add(id, context) };
    });
    return found.promise;
  }
  /** Withdraw a queued submission and remove its inbox item; placed inputs and settled submissions are reported. */
  abort(id, context, conversationId) {
    return this.#session.commitWith(async (tx) => {
      const record = await tx.submission(id);
      if (record === void 0 || conversationId !== void 0 && record.conversationId !== conversationId) {
        return "not_found";
      }
      if (record.status === "queued") {
        tx.settleSubmission(id, { status: "unanswered", reason: "aborted" });
        await removeInboxItem(tx, record.conversationId, id);
        return "aborted";
      }
      return record.status === "placed" ? "already_placed" : "settled";
    }, context);
  }
  #observe(publication) {
    for (const change of publication.changes) {
      if (change.type !== "submission" || !isSettled(change.value))
        continue;
      this.#waiters.resolve(change.value.id, change.value);
    }
  }
};
var SubmissionHandle = class {
  id;
  #submissions;
  constructor(id, submissions) {
    this.id = id;
    this.#submissions = submissions;
  }
  status(context) {
    return this.#submissions.status(this.id, context);
  }
  wait(context) {
    return this.#submissions.wait(this.id, context);
  }
  async abort(context) {
    const result = await this.#submissions.abort(this.id, context);
    if (result === "not_found")
      throw new Error(`Submission ${this.id} does not exist`);
    return result;
  }
};
function isSettled(record) {
  return record.status === "done" || record.status === "unanswered";
}
async function admitSubmission(tx, conversationId, draft, now, queueModes) {
  if (draft.requestId !== void 0) {
    const existing = await tx.submissionByRequest(conversationId, draft.requestId);
    if (existing !== void 0) {
      if (existing.type !== draft.type) {
        throw new Error(`Request ${draft.requestId} already identifies a submission of type ${existing.type}`);
      }
      return existing.id;
    }
  }
  const live = await tx.doc(LiveDoc, conversationId);
  const busy = live.run !== void 0;
  if (busy && draft.type === "input" && draft.whenBusy === "reject")
    throw new ConversationBusy(conversationId);
  const requestId = draft.requestId === void 0 ? {} : { requestId: draft.requestId };
  const boundary = busy ? void 0 : await prepareBoundary(tx, conversationId, queueModes);
  if (boundary === void 0 || boundary.inbox.items.length > 0) {
    const { id: id2 } = await tx.createSubmission({
      conversationId,
      ...requestId,
      type: draft.type,
      status: "queued"
    });
    const value = copyJson(draft.type === "write" ? draft.entry : draft.content, {
      omitUndefinedProperties: true
    });
    const items = (boundary?.inbox ?? await tx.doc(InboxDoc, conversationId)).items;
    if (draft.type === "write")
      items.push({ id: id2, mode: "write", entry: value });
    else {
      const mode = draft.whenBusy === "steer" ? "steer" : "followUp";
      items.push({ id: id2, mode, content: value });
    }
    if (boundary === void 0)
      return id2;
    const { users } = await applyBoundary(tx, boundary, "final", now);
    if (users.length > 0)
      await startRun(tx, conversationId, live, users);
    return id2;
  }
  if (draft.type === "write") {
    if (isStale(boundary, draft.entry)) {
      const stale = { status: "unanswered", reason: "stale" };
      return (await tx.createSubmission({ conversationId, ...requestId, type: "write", ...stale })).id;
    }
    const entry2 = await tx.appendEntry(conversationId, draft.entry);
    const write = { conversationId, ...requestId, type: "write", status: "done", entry: entry2.id };
    return (await tx.createSubmission(write)).id;
  }
  const message = { role: "user", content: draft.content, timestamp: now };
  const entry = await tx.appendEntry(UserEntry, conversationId, { model: [message] });
  const input = { conversationId, ...requestId, type: "input", status: "placed", entry: entry.id };
  const { id } = await tx.createSubmission(input);
  await startRun(tx, conversationId, live, [id]);
  return id;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/compaction.js
var TOOL_RESULT_MAX_CHARS = 2e3;
var SUMMARY_PREFIX = "The conversation history before this point was compacted into the following summary:\n\n<summary>\n";
var SUMMARY_SUFFIX = "\n</summary>";
var SUMMARIZATION_SYSTEM_PROMPT = `You are a context summarization assistant. Your task is to read a conversation between a user and an AI assistant, then produce a structured summary following the exact format specified.

Do NOT continue the conversation. Do NOT respond to any questions in the conversation. ONLY output the structured summary.`;
var SUMMARIZATION_PROMPT = `The messages above are a conversation to summarize. Create a structured context checkpoint summary that another LLM will use to continue the work. If the conversation starts with an earlier summary, preserve its information and fold the newer messages into it.

Use this EXACT format:

## Goal
[What is the user trying to accomplish? Can be multiple items if the session covers different tasks.]

## Constraints & Preferences
- [Any constraints, preferences, or requirements mentioned by user]
- [Or "(none)" if none were mentioned]

## Progress
### Done
- [x] [Completed tasks/changes]

### In Progress
- [ ] [Current work]

### Blocked
- [Issues preventing progress, if any]

## Key Decisions
- **[Decision]**: [Brief rationale]

## Next Steps
1. [Ordered list of what should happen next]

## Critical Context
- [Any data, examples, or references needed to continue]
- [Or "(none)" if not applicable]

Keep each section concise. Preserve exact file paths, function names, and error messages.`;
var CompactionTask = defineTask({
  name: "pi.compaction",
  version: 1,
  initial: () => ({ phase: "select" }),
  phases: {
    select: async (task, runtime, context) => {
      const { conversationId } = runtime;
      const agent = await runtime.agent(context);
      const settings = runtime.settings;
      const ref = agent.model;
      const model = ref === void 0 ? void 0 : runtime.models.getModel(ref.provider, ref.modelId);
      if (ref === void 0 || model === void 0)
        return failNoModel2(runtime, ref, context);
      const policy = settings.compaction;
      const view = await runtime.context(conversationId, context);
      const cut = selectCut(view, policy.keepRecentTokens);
      if (cut === void 0)
        return complete(runtime, context);
      const firstKept = view.entries[cut].id;
      const { reason, instructions } = task.input;
      const compaction = {
        reason,
        entries: view.entries.slice(0, cut),
        messages: summarizedMessages(view, cut),
        firstKept,
        ...instructions === void 0 ? {} : { instructions }
      };
      let decision;
      await runtime.hooks.each("beforeCompact", async (hook2) => {
        if (decision === void 0)
          decision = await hook2(compaction, runtime, context);
      });
      if (decision !== void 0 && "decline" in decision)
        return complete(runtime, context);
      if (decision !== void 0)
        return place(runtime, firstKept, decision.summary, context);
      const request = {
        attempt: 1,
        model: ref,
        thinkingLevel: agent.thinkingLevel,
        streamOptions: settings.stream,
        maxTokens: Math.min(Math.floor(0.8 * policy.reserveTokens), model.maxTokens > 0 ? model.maxTokens : Number.POSITIVE_INFINITY),
        tail: view.entries.reduce((tail, entry) => entry.id > tail ? entry.id : tail, firstKept),
        firstKept
      };
      await runtime.commit(() => ({ status: "running", checkpoint: { phase: "summarize", ...request } }), context);
    },
    summarize: async (task, runtime, context) => {
      const { phase: _, ...request } = task.state.checkpoint;
      const { model: ref, thinkingLevel, streamOptions, maxTokens, tail, firstKept, attempt } = request;
      const model = runtime.models.getModel(ref.provider, ref.modelId);
      if (model === void 0)
        return failNoModel2(runtime, ref, context);
      const view = await runtime.context(runtime.conversationId, context, tail);
      const cut = view.entries.findIndex((entry) => entry.id === firstKept);
      const now = runtime.now();
      const messages = [
        { role: "system", content: SUMMARIZATION_SYSTEM_PROMPT, timestamp: now },
        {
          role: "user",
          content: [{ type: "text", text: summaryPrompt(summarizedMessages(view, cut), task.input.instructions) }],
          timestamp: now
        }
      ];
      const { deferred: _deferred, ...forwarded } = streamOptions;
      const options = {
        ...forwarded,
        cacheRetention: "none",
        maxTokens,
        signal: runtime.signal,
        ...thinkingLevel === "off" ? {} : { reasoning: thinkingLevel }
      };
      const message = await runtime.models.completeSimple(model, { messages }, options);
      runtime.signal.throwIfAborted();
      const summary = summaryText(message);
      const policy = runtime.settings.retry;
      const retry = message.stopReason === "error" && isRetryableAssistantError(message) && policy.enabled && attempt <= policy.maxRetries;
      const until = retry ? runtime.now() + retryDelayMs(policy, attempt) : 0;
      await runtime.commit(async (tx, current) => {
        await recordUsage(tx, runtime.conversationId, "models", `${message.provider}/${message.model}`, message.usage);
        const live = await tx.doc(LiveDoc, runtime.conversationId);
        if (summary !== void 0)
          return placeSummary(tx, runtime, current, live, firstKept, summary);
        if (retry) {
          const status = compactionStatus(live, runtime.taskId);
          if (status !== void 0)
            status.retry = { at: until, error: message.errorMessage ?? "" };
          return { status: "running", checkpoint: { phase: "retry", ...request, until } };
        }
        removeCompactionStatus(live, runtime.taskId);
        const text = summaryFailure(message);
        return {
          status: "terminal",
          outcome: { status: "failed", error: { message: text, detail: { reason: "model_error" } } }
        };
      }, context);
    },
    retry: async (task, runtime, context) => {
      const { phase: _, until, ...request } = task.state.checkpoint;
      await runtime.sleep(until, context);
      const attempt = request.attempt + 1;
      await runtime.commit(async (tx) => {
        const status = compactionStatus(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
        if (status !== void 0) {
          status.attempt = attempt;
          delete status.retry;
        }
        return { status: "running", checkpoint: { phase: "summarize", ...request, attempt } };
      }, context);
    }
  },
  abort: async (_task, runtime, context) => {
    await runtime.commit(async (tx) => {
      removeCompactionStatus(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
      return { status: "terminal", outcome: { status: "aborted" } };
    }, context);
  }
});
async function createCompaction(tx, conversationId, input, owner) {
  const ownership = owner === void 0 ? { kind: "conversation" } : { kind: "task", taskId: owner };
  const background = owner === void 0 && input.reason !== "manual";
  const taskId = await tx.createTask(CompactionTask, input, { ownership, conversationId, background });
  const status = { taskId, reason: input.reason, blocking: owner !== void 0, attempt: 1 };
  addCompactionStatus(await tx.doc(LiveDoc, conversationId), status);
  return taskId;
}
function selectCut(view, keepRecentTokens) {
  const { contributions } = view;
  const start = view.head === void 0 ? 0 : 1;
  const candidates = [];
  for (let index3 = start; index3 < contributions.length; index3++) {
    if (isCandidate(contributions, index3))
      candidates.push(index3);
  }
  let kept = 0;
  let cut;
  for (let index3 = contributions.length - 1; index3 >= start; index3--) {
    for (const message of contributions[index3])
      kept += estimateMessageTokens(message);
    if (kept < keepRecentTokens)
      continue;
    cut = candidates.find((candidate) => candidate >= index3) ?? candidates.at(-1);
    break;
  }
  if (cut === void 0)
    return void 0;
  for (let index3 = start; index3 < cut; index3++)
    if (contributions[index3].length > 0)
      return cut;
  return void 0;
}
function isCandidate(contributions, index3) {
  const first = contributions[index3][0];
  if (first?.role === "assistant")
    return true;
  if (first?.role !== "user")
    return false;
  let calls = /* @__PURE__ */ new Set();
  for (let before = index3 - 1; before >= 0; before--) {
    const assistant = contributions[before].findLast((message) => message.role === "assistant");
    if (assistant === void 0)
      continue;
    calls = new Set(assistant.content.flatMap((content) => content.type === "toolCall" ? [content.id] : []));
    break;
  }
  if (calls.size === 0)
    return true;
  for (let after = index3; after < contributions.length; after++) {
    for (const [position, message] of contributions[after].entries()) {
      if (message.role === "assistant" && (after > index3 || position > 0))
        return true;
      if (message.role === "toolResult" && calls.has(message.toolCallId))
        return false;
    }
  }
  return true;
}
function summarizedMessages(view, cut) {
  return orderToolResults(view.contributions.slice(0, cut).flat());
}
function estimateContext(view, extra) {
  let measured;
  const after = view.head?.id ?? Number.NEGATIVE_INFINITY;
  for (let index3 = view.entries.length - 1; index3 >= 0 && measured === void 0; index3--) {
    if (view.entries[index3].id <= after)
      continue;
    measured = view.contributions[index3].findLast((message) => message.role === "assistant" && calculateContextTokens(message.usage) > 0);
  }
  const from = measured === void 0 ? 0 : view.messages.lastIndexOf(measured) + 1;
  let tokens = measured === void 0 ? 0 : calculateContextTokens(measured.usage);
  for (const message of view.messages.slice(from))
    tokens += estimateMessageTokens(message);
  for (const message of extra)
    tokens += estimateMessageTokens(message);
  return tokens;
}
function summaryText(message) {
  if (message.stopReason !== "stop" || message.content.some((content) => content.type === "toolCall"))
    return void 0;
  const text = message.content.flatMap((content) => content.type === "text" ? [content.text] : []).join("\n").trim();
  return text.length === 0 ? void 0 : text;
}
function summaryFailure(message) {
  if (message.stopReason === "error" || message.stopReason === "aborted") {
    return `Summarization failed: ${message.errorMessage ?? message.stopReason}`;
  }
  if (message.stopReason === "length")
    return "Summarization hit the token limit; the summary is incomplete";
  if (message.content.some((content) => content.type === "toolCall"))
    return "Summarization attempted to call a tool";
  return "Summarization produced no text";
}
function summaryPrompt(messages, instructions) {
  const focus = instructions === void 0 ? "" : `

Additional focus: ${instructions}`;
  return `<conversation>
${serializeConversation(messages)}
</conversation>

${SUMMARIZATION_PROMPT}${focus}`;
}
function serializeConversation(messages) {
  const parts2 = [];
  for (const message of messages) {
    if (message.role === "user") {
      const text = contentText(message.content);
      if (text.length > 0)
        parts2.push(`[User]: ${text}`);
    } else if (message.role === "assistant") {
      const thinking = message.content.flatMap((content) => content.type === "thinking" ? [content.thinking] : []);
      const text = message.content.flatMap((content) => content.type === "text" ? [content.text] : []);
      const calls = message.content.flatMap((content) => content.type === "toolCall" ? [
        `${content.name}(${Object.entries(content.arguments).map(([key, value]) => `${key}=${JSON.stringify(value)}`).join(", ")})`
      ] : []);
      if (thinking.length > 0)
        parts2.push(`[Assistant thinking]: ${thinking.join("\n")}`);
      if (text.length > 0)
        parts2.push(`[Assistant]: ${text.join("\n")}`);
      if (calls.length > 0)
        parts2.push(`[Assistant tool calls]: ${calls.join("; ")}`);
    } else if (message.role === "toolResult") {
      const text = contentText(message.content);
      if (text.length > 0)
        parts2.push(`[Tool result]: ${truncate(text, TOOL_RESULT_MAX_CHARS)}`);
    }
  }
  return parts2.join("\n\n");
}
function contentText(content) {
  if (typeof content === "string")
    return content;
  return content.flatMap((block) => block.type === "text" && block.text !== void 0 ? [block.text] : []).join("\n");
}
function truncate(text, maxChars) {
  if (text.length <= maxChars)
    return text;
  return `${text.slice(0, maxChars)}

[... ${text.length - maxChars} more characters truncated]`;
}
async function place(runtime, firstKept, summary, context) {
  await runtime.commit(async (tx, current) => placeSummary(tx, runtime, current, await tx.doc(LiveDoc, runtime.conversationId), firstKept, summary), context);
}
async function placeSummary(tx, runtime, current, live, firstKept, summary) {
  removeCompactionStatus(live, runtime.taskId);
  const text = `${SUMMARY_PREFIX}${summary}${SUMMARY_SUFFIX}`;
  const entry = {
    kind: CompactionEntry.kind,
    head: firstKept,
    model: [{ role: "user", content: [{ type: "text", text }], timestamp: runtime.now() }],
    data: { reason: current.input.reason }
  };
  const result = current.owner === void 0 ? {
    submissionId: await admitSubmission(tx, runtime.conversationId, { type: "write", requestId: `compaction:${runtime.taskId}`, entry }, runtime.now(), runtime.settings)
  } : { entryId: (await tx.appendEntry(runtime.conversationId, entry)).id };
  return { status: "terminal", outcome: { status: "completed", result } };
}
async function complete(runtime, context) {
  await runtime.commit(async (tx) => {
    removeCompactionStatus(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
    return { status: "terminal", outcome: { status: "completed", result: {} } };
  }, context);
}
async function failNoModel2(runtime, ref, context) {
  const message = ref === void 0 ? "No model is configured" : `Model ${ref.provider}/${ref.modelId} is not available`;
  await runtime.commit(async (tx) => {
    removeCompactionStatus(await tx.doc(LiveDoc, runtime.conversationId), runtime.taskId);
    return { status: "terminal", outcome: { status: "failed", error: { message, detail: { reason: "no_model" } } } };
  }, context);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/define.js
function defineExtension(extension) {
  return extension;
}
function defineTool(tool) {
  return tool;
}
function section(key, render, options) {
  return options?.tag === void 0 ? { key, render } : { key, render, tag: options.tag };
}
function hook(task, handlers) {
  return { task: task.definition.name, handlers };
}
function wrapTool(tool, wrapper) {
  return { tool: tool.name, wrap: wrapper };
}
function wrapSection(key, wrapper) {
  return { section: key, wrap: wrapper };
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/session/observation.js
var MAX_PENDING_WATCH_FRAMES = 100;
var RETIREMENT_OPERATIONS = [["r", null]];
var CommittedStateSource = class {
  #attachments = /* @__PURE__ */ new Set();
  #release;
  /** Released on disposal. */
  #value;
  #cursor = 0;
  #retired = false;
  #closed = false;
  constructor(value, release) {
    this.#value = value;
    this.#release = release;
  }
  attach() {
    if (this.#closed)
      throw new Error("State source is closed");
    const attachment = new SessionSourceAttachment({ value: this.#value, cursor: this.#cursor }, () => {
      this.#attachments.delete(attachment);
      if (this.#attachments.size === 0)
        this.#finishDisposal();
    });
    this.#attachments.add(attachment);
    return attachment;
  }
  advance(value, ops, context) {
    if (this.#closed || this.#retired)
      return;
    this.#value = value;
    this.#cursor += 1;
    if (value === null)
      this.#retired = true;
    const frame = {
      cursor: this.#cursor,
      value,
      ops,
      context
    };
    for (const attachment of [...this.#attachments])
      attachment.publish(frame);
  }
  closeSession() {
    if (this.#closed)
      return;
    for (const attachment of [...this.#attachments])
      attachment.dispose();
    this.#finishDisposal();
  }
  #finishDisposal() {
    if (this.#closed)
      return;
    this.#closed = true;
    this.#value = void 0;
    const release = this.#release;
    this.#release = void 0;
    release?.();
  }
};
var SessionSourceAttachment = class {
  snapshot;
  #release;
  #frames = [];
  #listener;
  #activated = false;
  #disposed = false;
  #scheduled = false;
  #delivering = false;
  constructor(snapshot, release) {
    this.snapshot = snapshot;
    this.#release = release;
  }
  activate(listener) {
    if (this.#activated)
      throw new Error("State attachment is already active");
    if (this.#disposed)
      throw new Error("State attachment is disposed");
    this.#activated = true;
    this.#listener = listener;
    this.#drain();
  }
  publish(frame) {
    if (this.#disposed)
      return;
    this.#frames.push(frame);
    if (!this.#activated || this.#delivering || this.#scheduled)
      return;
    this.#scheduled = true;
    queueMicrotask(() => {
      this.#scheduled = false;
      if (this.#disposed)
        return;
      try {
        this.#drain();
      } catch {
        this.dispose();
      }
    });
  }
  dispose() {
    if (this.#disposed)
      return;
    this.#disposed = true;
    this.#frames.length = 0;
    this.#listener = void 0;
    const release = this.#release;
    this.#release = void 0;
    release?.();
  }
  #drain() {
    const listener = this.#listener;
    if (listener === void 0 || this.#delivering || this.#disposed)
      return;
    this.#delivering = true;
    try {
      while (!this.#disposed) {
        const frame = this.#frames.shift();
        if (frame === void 0)
          break;
        listener(frame);
      }
    } finally {
      this.#delivering = false;
    }
  }
};
var CommittedWatch = class {
  #detach;
  #replace;
  #closedPromise;
  #pending = [];
  #resolveClosed;
  #value;
  #listener;
  #started = false;
  #scheduled = false;
  #running = false;
  #detached = false;
  #retired = false;
  #end;
  #resolved = false;
  #cancellationSignal;
  #cancellationListener;
  /** `replace` gives the value an overflow delivers; by default the newest value. */
  constructor(value, detach, replace) {
    this.#value = value;
    this.#detach = detach;
    this.#replace = replace;
    this.#closedPromise = new Promise((resolve) => {
      this.#resolveClosed = resolve;
    });
  }
  get value() {
    return this.#value;
  }
  get closed() {
    return this.#closedPromise;
  }
  start(listener) {
    if (this.#started)
      throw new Error("Watch is already started");
    if (this.#end !== void 0)
      throw new Error("Watch is stopped");
    this.#started = true;
    this.#listener = listener;
    if (this.#pending.length > 0)
      this.#schedule();
  }
  stop() {
    this.#terminate({ reason: "stopped" });
    return this.#closedPromise;
  }
  observeCancellation(signal) {
    if (this.#cancellationSignal !== void 0)
      throw new Error("Watch cancellation is already installed");
    if (this.#end !== void 0)
      return;
    this.#cancellationSignal = signal;
    this.#cancellationListener = () => this.cancel();
    signal.addEventListener("abort", this.#cancellationListener, { once: true });
    if (signal.aborted)
      this.cancel();
  }
  cancel() {
    this.#terminate({ reason: "cancelled" });
  }
  closeSession() {
    this.#terminate({ reason: "session_closed" });
  }
  advance(value, ops, context) {
    if (this.#end !== void 0 || this.#retired)
      return;
    if (value === null)
      this.#retired = true;
    if (this.#pending.length >= MAX_PENDING_WATCH_FRAMES) {
      this.#pending.length = 0;
      const replacement = this.#replace?.() ?? value;
      this.#pending.push({ value: replacement, ops: [["r", replacement]], context });
    } else {
      this.#pending.push({ value, ops, context });
    }
    if (this.#started)
      this.#schedule();
  }
  #schedule() {
    if (this.#scheduled || this.#running || this.#end !== void 0)
      return;
    this.#scheduled = true;
    queueMicrotask(() => {
      this.#scheduled = false;
      void this.#drain();
    });
  }
  async #drain() {
    if (this.#running || this.#end !== void 0 || !this.#started) {
      this.#finishIfReady();
      return;
    }
    this.#running = true;
    try {
      while (this.#end === void 0) {
        const frame = this.#pending.shift();
        if (frame === void 0)
          break;
        this.#value = frame.value;
        const deliveryContext = withoutAbortSignal(frame.context);
        try {
          await this.#listener(frame.value, frame.ops, deliveryContext);
        } catch (error) {
          if (this.#end === void 0) {
            this.#terminate({ reason: "listener_error", error: toError2(error) });
          }
          break;
        }
        if (frame.value === null) {
          this.#terminate({ reason: "retired" });
          break;
        }
      }
    } finally {
      this.#running = false;
      if (this.#end === void 0 && this.#pending.length > 0)
        this.#schedule();
      this.#finishIfReady();
    }
  }
  #terminate(end) {
    if (this.#end !== void 0)
      return;
    this.#end = end;
    this.#detachNow();
    this.#pending.length = 0;
    this.#finishIfReady();
  }
  #detachNow() {
    if (this.#detached)
      return;
    this.#detached = true;
    this.#detach();
  }
  #finishIfReady() {
    if (this.#resolved || this.#end === void 0)
      return;
    this.#resolved = true;
    if (this.#cancellationSignal !== void 0 && this.#cancellationListener !== void 0) {
      this.#cancellationSignal.removeEventListener("abort", this.#cancellationListener);
    }
    this.#resolveClosed(this.#end);
  }
};
function toError2(error) {
  return error instanceof Error ? error : new Error(String(error));
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/view.js
var MOUNTED = [AgentDoc, LiveDoc, InboxDoc, UsageDoc];
var MOUNTED_KINDS = new Set(MOUNTED.map((token) => token.definition.kind));
var VIEWS = /* @__PURE__ */ new WeakMap();
function conversationViews(harness) {
  const views = VIEWS.get(harness);
  if (views === void 0)
    throw new Error("Not a Harness");
  return views;
}
var ConversationViews = class {
  #session;
  #storage;
  #mounts = /* @__PURE__ */ new Map();
  #closed = false;
  constructor(session, storage) {
    this.#session = session;
    this.#storage = storage;
    VIEWS.set(session, this);
    session.subscribeCommits((publication, context) => {
      for (const [id, mount] of this.#mounts)
        advance(id, mount, publication, context);
    });
    session.subscribeClose(() => {
      this.#closed = true;
      for (const mount of this.#mounts.values())
        for (const observer of [...mount.observers])
          observer.closeSession();
      this.#mounts.clear();
    });
  }
  /** A disposable read-only Chord state of the view. */
  async state(id, context) {
    const { observer, detach } = await this.attach(id, (value, release) => new CommittedStateSource(value, release), context);
    try {
      return replicatedState(observer);
    } catch (error) {
      detach();
      throw error;
    }
  }
  /** A serialized exact-frame watch of the view; cancelling `context` stops it. */
  async watch(id, context) {
    const { observer } = await this.attach(id, (value, release) => new CommittedWatch(value, release), context);
    const signal = context.abortSignal;
    if (signal?.aborted) {
      observer.cancel();
      throw signal.reason;
    }
    if (signal !== void 0)
      observer.observeCancellation(signal);
    return observer;
  }
  /**
   * Register an observer created from the current revision, atomically on the Session line: it sees every later
   * publication and nothing earlier. `create` may read committed Storage, still on the line. `release` drops it, and
   * the mount with its last observer.
   */
  attach(id, create, context) {
    return this.#session.readOnLine(async () => {
      const mount = this.#mounts.get(id) ?? await this.#build(id, context);
      const detach = () => {
        mount.observers.delete(observer);
        if (mount.observers.size === 0 && this.#mounts.get(id) === mount)
          this.#mounts.delete(id);
      };
      const observer = await create(mount.value, detach, this.#storage);
      if (this.#closed)
        throw closedError();
      context.abortSignal?.throwIfAborted();
      this.#mounts.set(id, mount);
      mount.observers.add(observer);
      return { observer, detach };
    });
  }
  async #build(id, context) {
    const conversation = await this.#storage.conversation(id, context);
    if (conversation === void 0)
      throw new Error(`Conversation ${id} does not exist`);
    const bounds = await captureContextBounds(this.#storage, id, context);
    const entries = await activeEntries(this.#storage, id, bounds, context);
    const docs = {};
    const incarnations = /* @__PURE__ */ new Map();
    for (const token of MOUNTED) {
      const loaded = await this.#session.conversationDocumentOnLine(token, id, context);
      if (loaded === void 0)
        continue;
      docs[token.definition.kind] = loaded.value;
      incarnations.set(token.definition.kind, { id: loaded.record.id, version: loaded.version });
    }
    return { value: { conversation, entries, docs }, docs: incarnations, observers: /* @__PURE__ */ new Set() };
  }
};
function advance(id, mount, publication, context) {
  const docOps = [];
  const entryOps = [];
  let entries = mount.value.entries;
  for (const change of publication.changes) {
    if (change.type === "entry" && change.value.conversationId === id) {
      const entry = change.value;
      const value = entry;
      if (entry.head === void 0) {
        entryOps.push(["p", ["entries"], entries.length, 0, [value]]);
        entries = [...entries, entry];
        continue;
      }
      const target = entry.head;
      let kept = entries.findIndex((candidate) => candidate.head === void 0 && candidate.id >= target);
      if (kept < 0)
        kept = entries.length;
      entryOps.push(["p", ["entries"], 0, kept, [value]]);
      entries = [entry, ...entries.slice(kept)];
      continue;
    }
    if (change.type !== "document" || change.conversationId !== id)
      continue;
    const kind = change.record.kind;
    if (!MOUNTED_KINDS.has(kind) || change.record.key !== void 0)
      continue;
    const path = ["docs", kind];
    const mounted = mount.docs.get(kind);
    if (change.value === null) {
      if (mounted?.id !== change.record.id)
        continue;
      mount.docs.delete(kind);
      docOps.push(["d", path]);
    } else if (mounted?.id === change.record.id && mounted.version === change.version) {
      for (const op of change.ops)
        docOps.push(prefixed(op, path));
    } else {
      mount.docs.set(kind, { id: change.record.id, version: change.version });
      docOps.push(["s", path, change.value]);
    }
  }
  const before = mount.value;
  const ops = [...docOps, ...entryOps];
  const frameContext = withoutAbortSignal(context);
  if (ops.length > 0) {
    const value = docOps.length === 0 ? mount.value : applyImmutable(mount.value, docOps);
    mount.value = entries === value.entries ? value : { ...value, entries };
    for (const observer of [...mount.observers])
      observer.advance?.(mount.value, ops, frameContext);
  }
  for (const observer of [...mount.observers]) {
    observer.publication?.(before, mount.value, ops, publication, frameContext);
  }
}
function prefixed(op, prefix) {
  const at = (path) => [...prefix, ...path];
  switch (op[0]) {
    case "r":
      return ["s", prefix, op[1]];
    case "p":
      return ["p", at(op[1]), op[2], op[3], op[4]];
    case "m":
      return ["m", at(op[1]), op[2]];
    case "s":
      return ["s", at(op[1]), op[2]];
    case "d":
      return ["d", at(op[1])];
    case "a":
      return ["a", at(op[1]), op[2]];
    case "t":
      return ["t", at(op[1]), op[2]];
  }
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/events.js
function parts(view) {
  return {
    live: view.docs["pi.live"] ?? {},
    inbox: view.docs["pi.inbox"],
    agent: view.docs["pi.agent"],
    usage: view.docs["pi.usage"]
  };
}
function snapshotOf(view) {
  const { live, inbox, agent, usage } = parts(view);
  return {
    type: "snapshot",
    entries: view.entries,
    ...live.run === void 0 ? {} : { run: { inputs: live.run.inputs } },
    ...live.generation === void 0 ? {} : { generation: live.generation },
    tools: live.tools ?? [],
    compactions: live.compactions ?? [],
    inbox: queued(inbox),
    agent: agent ?? AgentDoc.definition.initial(),
    usage: usage ?? UsageDoc.definition.initial()
  };
}
function queued(inbox) {
  return (inbox?.items ?? []).map((item) => ({ id: item.id, mode: item.mode }));
}
async function watchEvents(harness, conversationId, context) {
  let watch;
  let snapshot;
  await conversationViews(harness).attach(conversationId, async (initial, release, storage) => {
    const query = { conversationId, kind: "pi.generation", status: "completing" };
    const completing = await scanAll((cursor) => storage.scanTasks(query, 100, cursor, context));
    const held = new Set(completing.map((record) => record.id));
    let current = initial;
    snapshot = snapshotOf(initial);
    watch = new CommittedWatch([], release, () => [snapshotOf(current)]);
    return {
      publication: (before, after, ops, publication, commitContext) => {
        current = after;
        const events = translate(conversationId, before, after, ops, publication, held);
        if (events.length > 0)
          watch.advance(events, [], commitContext);
      },
      closeSession: () => watch.closeSession()
    };
  }, context);
  const signal = context.abortSignal;
  if (signal?.aborted) {
    watch.cancel();
    throw signal.reason;
  }
  if (signal !== void 0)
    watch.observeCancellation(signal);
  return {
    snapshot,
    start: (listener) => watch.start((events, _ops, deliveryContext) => listener(events, deliveryContext)),
    stop: () => watch.stop(),
    closed: watch.closed
  };
}
function resultOf(entries, callId) {
  return entries.find((entry) => {
    const message = entry.model?.[0];
    return message?.role === "toolResult" && message.toolCallId === callId;
  });
}
function translate(conversationId, before, after, viewOps, publication, held) {
  const entries = [];
  const tasks = /* @__PURE__ */ new Map();
  const submissions = [];
  for (const change of publication.changes) {
    if (change.type === "entry" && change.value.conversationId === conversationId)
      entries.push(change.value);
    if (change.type === "task" && change.value.conversationId === conversationId)
      tasks.set(change.value.id, change.value);
    if (change.type === "submission" && change.value.conversationId === conversationId) {
      submissions.push(change.value);
    }
  }
  if (viewOps.length === 0 && entries.length === 0 && tasks.size === 0 && submissions.length === 0)
    return [];
  submissions.sort((a, b) => a.id - b.id);
  const was = parts(before);
  const now = parts(after);
  const events = [];
  const slotsBefore = new Map((was.live.tools ?? []).map((slot) => [slot.callId, slot]));
  const slots = now.live.tools ?? [];
  for (const slot of slots) {
    if (slot.status !== "running" || slotsBefore.get(slot.callId)?.status === "running")
      continue;
    const checkpoint = slot.taskId === void 0 ? void 0 : tasks.get(slot.taskId)?.state.checkpoint;
    const args = checkpoint?.arguments ?? {};
    events.push({ type: "tool_execution_start", toolCallId: slot.callId, toolName: slot.name, args });
  }
  const partialBefore = was.live.generation?.message;
  const partial = now.live.generation?.message;
  if (partial !== void 0 && partialBefore === void 0)
    events.push({ type: "message_start", message: partial });
  else if (partial !== void 0 && partial !== partialBefore) {
    events.push({ type: "message_update", usage: partial.usage, changes: messageChanges(viewOps, partial) });
  }
  for (const [index3, slot] of slots.entries()) {
    const previous = slotsBefore.get(slot.callId);
    if (slot.status !== "running" || previous?.status !== "running")
      continue;
    const update = toolUpdate(viewOps, index3, slot, previous);
    if (update === void 0)
      continue;
    events.push({ type: "tool_execution_update", toolCallId: slot.callId, toolName: slot.name, ...update });
  }
  const generation = now.live.generation;
  const generationBefore = was.live.generation;
  if (generation?.retry !== void 0 && generationBefore?.retry === void 0) {
    const { at, error } = generation.retry;
    events.push({ type: "auto_retry_start", attempt: generation.attempt, at, errorMessage: error });
  }
  if (generationBefore?.retry !== void 0 && generation?.retry === void 0) {
    events.push({ type: "auto_retry_end", attempt: generationBefore.attempt });
  }
  if (generation?.deferred !== void 0 && generation.deferred.pollAt !== generationBefore?.deferred?.pollAt) {
    events.push({ type: "deferred_poll", pollAt: generation.deferred.pollAt });
  }
  const toolEnds = [];
  const endTool = (callId, name, entryId) => {
    const entry = entries.find((candidate) => candidate.id === entryId);
    toolEnds.push({
      type: "tool_execution_end",
      toolCallId: callId,
      toolName: name,
      ...entry === void 0 ? {} : { entry }
    });
  };
  for (const previous of slotsBefore.values()) {
    if (previous.status === "done")
      continue;
    const slot = slots.find((candidate) => candidate.callId === previous.callId);
    if (slot?.status === "done")
      endTool(previous.callId, previous.name, slot.entry);
    else if (slot === void 0)
      endTool(previous.callId, previous.name, resultOf(entries, previous.callId)?.id);
  }
  for (const slot of slots) {
    if (slot.status === "done" && !slotsBefore.has(slot.callId))
      endTool(slot.callId, slot.name, slot.entry);
  }
  let assistantAppended = false;
  for (const entry of entries) {
    events.push(...toolEnds.filter((end) => end.entry === entry));
    const message = entry.model?.[0];
    if (message === void 0) {
      events.push({ type: "entry_appended", entry });
      continue;
    }
    const streamed = message.role === "assistant" && partialBefore !== void 0 && !assistantAppended;
    if (message.role === "assistant")
      assistantAppended = true;
    if (!streamed)
      events.push({ type: "message_start", message });
    events.push({ type: "message_end", entry });
  }
  events.push(...toolEnds.filter((end) => end.entry === void 0));
  const compactionsBefore = was.live.compactions ?? [];
  const compactions = now.live.compactions ?? [];
  for (const { taskId, reason } of compactionsBefore) {
    if (!compactions.some((status) => status.taskId === taskId)) {
      events.push({ type: "compaction_end", taskId, reason });
    }
  }
  let turnEnded = false;
  for (const task of tasks.values()) {
    const status = task.state.status;
    if (task.kind === "pi.generation" && status === "completing" && !held.has(task.id)) {
      held.add(task.id);
      turnEnded = true;
    }
    if (status !== "terminal")
      continue;
    if (task.kind === "pi.generation" && !held.delete(task.id))
      turnEnded = true;
    const outcome = task.state.outcome;
    if (outcome.status === "faulted" || outcome.status === "orphaned") {
      const message = outcome.status === "faulted" ? outcome.error.message : outcome.reason;
      events.push({ type: "task_failed", taskId: task.id, kind: task.kind, message });
    }
  }
  if (turnEnded)
    events.push({ type: "turn_end" });
  const run2 = now.live.run;
  const runBefore = was.live.run;
  const runChanged = run2?.inputs[0] !== runBefore?.inputs[0];
  if (runBefore !== void 0 && runChanged)
    events.push({ type: "run_end", inputs: runBefore.inputs });
  for (const record of submissions)
    events.push({ type: "submission", record });
  if (now.inbox !== was.inbox)
    events.push({ type: "inbox_update", items: queued(now.inbox) });
  if (now.agent !== was.agent) {
    events.push({ type: "agent_changed", agent: now.agent ?? AgentDoc.definition.initial() });
  }
  if (now.usage !== was.usage)
    events.push({ type: "usage_changed", usage: now.usage ?? UsageDoc.definition.initial() });
  for (const { taskId, reason, blocking } of compactions) {
    if (!compactionsBefore.some((status) => status.taskId === taskId)) {
      events.push({ type: "compaction_start", taskId, reason, blocking });
    }
  }
  if (run2 !== void 0 && runChanged)
    events.push({ type: "run_start", inputs: run2.inputs });
  if (run2 !== void 0 && run2.taskId !== runBefore?.taskId && tasks.get(run2.taskId)?.kind === "pi.generation") {
    events.push({ type: "turn_start" });
  }
  return events;
}
var PARTIAL_PATH = ["docs", "pi.live", "generation", "message"];
function messageChanges(viewOps, message) {
  const changes = [];
  const whole = /* @__PURE__ */ new Set();
  for (const op of viewOps) {
    const path = op[1];
    if (!startsWith(path, PARTIAL_PATH)) {
      if (startsWith(PARTIAL_PATH, path))
        return [{ type: "message", message }];
      continue;
    }
    const rest = path.slice(PARTIAL_PATH.length);
    if (rest[0] === "usage")
      continue;
    if (rest[0] !== "content")
      return [{ type: "message", message }];
    if (rest.length === 1) {
      if (op[0] !== "p" || op[3] !== 0)
        return [{ type: "message", message }];
      for (const [offset, block] of op[4].entries()) {
        const type = block.type === "text" ? "text_start" : block.type === "thinking" ? "thinking_start" : "toolcall_start";
        changes.push({ type, contentIndex: op[2] + offset, block });
      }
      continue;
    }
    const contentIndex = rest[1];
    const field = rest[2];
    if (whole.has(contentIndex))
      continue;
    if (op[0] === "a" && rest.length === 3 && (field === "text" || field === "thinking")) {
      changes.push({ type: field === "text" ? "text_delta" : "thinking_delta", contentIndex, delta: op[2] });
    } else if (op[0] === "a" && field === "arguments") {
      changes.push({ type: "toolcall_delta", contentIndex, path: rest.slice(3), delta: op[2] });
    } else {
      whole.add(contentIndex);
      changes.push({ type: "block", contentIndex, block: message.content[contentIndex] });
    }
  }
  return changes;
}
function toolUpdate(viewOps, index3, slot, previous) {
  const outputPath = ["docs", "pi.live", "tools", index3, "output"];
  let trimStart = 0;
  let append = "";
  let set = false;
  for (const op of viewOps) {
    if (!startsWith(op[1], outputPath))
      continue;
    if (op[0] === "t")
      trimStart += op[2];
    else if (op[0] === "a")
      append += op[2];
    else
      set = true;
  }
  let output;
  if (set || slot.output !== previous.output && trimStart === 0 && append === "")
    output = { set: slot.output ?? "" };
  else if (trimStart > 0 || append !== "") {
    output = { ...trimStart > 0 ? { trimStart } : {}, ...append === "" ? {} : { append } };
  }
  const update = {
    ...output === void 0 ? {} : { output },
    ...slot.details === previous.details ? {} : { details: slot.details ?? null },
    ...slot.diagnostics === previous.diagnostics ? {} : { diagnostics: slot.diagnostics ?? [] }
  };
  return Object.keys(update).length === 0 ? void 0 : update;
}
function startsWith(path, prefix) {
  return prefix.length <= path.length && prefix.every((segment, index3) => path[index3] === segment);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/types.js
var ROOT_CONVERSATION_ID = 1;

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/session/forks.js
var SCAN_PAGE_SIZE2 = 256;
async function prepareForkDocumentCopies(storage, parentConversationId, at, childConversationId, context) {
  const entry = await storage.entry(parentConversationId, at, context);
  if (entry === void 0)
    throw new Error(`Entry ${at} is not visible from conversation ${parentConversationId}`);
  const copies = [];
  const copiedAddresses = /* @__PURE__ */ new Set();
  await collectCopies(storage, { kind: "conversation", conversationId: entry.entry.conversationId }, entry.commitSeq, "asOf", childConversationId, copies, copiedAddresses, context);
  await collectCopies(storage, { kind: "conversation", conversationId: parentConversationId }, "current", "current", childConversationId, copies, copiedAddresses, context);
  return copies;
}
async function collectCopies(storage, scope, at, policy, childConversationId, copies, copiedAddresses, context) {
  let cursor;
  do {
    const page2 = await storage.scanDocuments({ scope, at }, SCAN_PAGE_SIZE2, cursor, context);
    for (const source of page2.items) {
      if (source.scope.kind !== "conversation" || source.fork !== policy)
        continue;
      const id = await storage.mintId();
      const identity = {
        id,
        kind: source.kind,
        ...source.key === void 0 ? {} : { key: source.key },
        scope: { kind: "conversation", conversationId: childConversationId }
      };
      const record = source.history === "latest" ? { ...identity, history: "latest", fork: source.fork } : { ...identity, history: "rewindable", fork: source.fork };
      const copyAddress = addressId(record);
      if (copiedAddresses.has(copyAddress)) {
        const member = record.key === void 0 ? record.kind : `${record.kind}/${record.key}`;
        throw new Error(`Fork selects multiple source documents for ${member}`);
      }
      copiedAddresses.add(copyAddress);
      copies.push({ record, source: { id: source.id, at } });
    }
    cursor = page2.next;
  } while (cursor !== void 0);
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/session/transaction.js
function applySubmissionChange(current, change) {
  if (current.status === "done" || current.status === "unanswered")
    return current;
  if (change.status === "placed") {
    if (current.status !== "queued")
      throw new Error(`Submission ${current.id} is not queued`);
    const status = current.type === "input" ? "placed" : "done";
    return { ...current, status, entry: change.entry };
  }
  if (change.status === "done" && current.status !== "placed") {
    throw new Error(`Submission ${current.id} is not a placed input`);
  }
  return { ...current, ...change };
}
var INTERNAL_SCAN_PAGE_SIZE = 256;
var EMPTY_OPERATIONS = [];
var TABLE_JSON_COPY_OPTIONS = { omitUndefinedProperties: true };
var Transaction = class {
  #host;
  #context;
  #scope;
  #pendingOperations = /* @__PURE__ */ new Set();
  #sealed = false;
  #hasTableWrite = false;
  /** Atomic batch; conversation and entry writes stage eagerly, while task and document writes assemble later. */
  #writes = [];
  #createdConversationIds = /* @__PURE__ */ new Set();
  #forkSourceConversationIds = /* @__PURE__ */ new Set();
  #forkSourceDocumentIds = /* @__PURE__ */ new Set();
  /** One entry per task touched by a public read, candidate write, or document-owner lookup. */
  #tasksById = /* @__PURE__ */ new Map();
  /** Submissions created by this transaction, by ID. */
  #submissions = /* @__PURE__ */ new Map();
  /** Submission settlements and placements in staging order; resolved against the latest candidate record during assembly. */
  #submissionChanges = [];
  /** Write and publication plans of every staged incarnation, built during assembly. */
  #plans = [];
  /** Every document acquisition or retirement marker in staging order. */
  #documents = [];
  /** Latest transaction-local incarnation or retirement marker at each logical address. */
  #latestDocumentByAddress = /* @__PURE__ */ new Map();
  constructor(host, context, scope = {}) {
    this.#host = host;
    this.#context = context;
    this.#scope = scope;
  }
  // ─── Table reads ────────────────────────────────────────────────────────
  conversation(id) {
    return this.#read("conversation", () => this.#host.storage.conversation(id, this.#context));
  }
  entry(first, second) {
    const kind = typeof first === "number" ? void 0 : first.kind;
    const id = typeof first === "number" ? first : second;
    return this.#read("entry", async () => {
      const entry = (await this.#host.storage.entry(id, this.#context))?.entry;
      return kind === void 0 || entry?.kind === kind ? entry : void 0;
    });
  }
  task(id) {
    return this.#read("task", () => this.#committedTask(id));
  }
  scanConversations(query, limit, cursor) {
    return this.#read("scanConversations", () => this.#host.storage.scanConversations(query, limit, cursor, this.#context));
  }
  scanEntries(query, limit, cursor) {
    return this.#read("scanEntries", () => this.#host.storage.scanEntries(query, limit, cursor, this.#context));
  }
  latestHeadMarker(conversationId) {
    return this.#read("latestHeadMarker", () => this.#host.storage.findLatestHeadMarker(conversationId, void 0, this.#context));
  }
  scanTasks(query, limit, cursor) {
    return this.#read("scanTasks", () => this.#host.storage.scanTasks(query, limit, cursor, this.#context));
  }
  /** Internal: committed submission record. */
  submission(id) {
    return this.#read("submission", () => this.#host.storage.submission(id, this.#context));
  }
  /** Committed submission with a conversation-scoped request ID. */
  submissionByRequest(conversationId, requestId) {
    return this.#read("submissionByRequest", () => this.#host.storage.submissionByRequest(conversationId, requestId, this.#context));
  }
  // ─── Table writes ───────────────────────────────────────────────────────
  createConversation(options) {
    return this.#write(() => this.#stageConversation(void 0, options.ownership));
  }
  /** Internal final-form bootstrap path for the reserved root identity. */
  createRootConversation() {
    return this.#write(() => this.#stageConversation(void 0, { kind: "ownerless" }, ROOT_CONVERSATION_ID));
  }
  forkConversation(parentConversationId, at, options) {
    return this.#write(() => this.#stageConversation({ conversationId: parentConversationId, at }, options.ownership));
  }
  async #stageConversation(parent, ownership, reservedId) {
    const ownerTaskId = ownership.kind === "task" ? ownership.taskId : void 0;
    const id = reservedId ?? await this.#host.storage.mintId();
    this.#assertOpen();
    let owner;
    if (ownerTaskId !== void 0) {
      const task = await this.#currentTask(ownerTaskId);
      this.#assertOpen();
      if (task === void 0)
        throw new Error(`Conversation owner task ${ownerTaskId} does not exist`);
      owner = { conversationId: task.conversationId, taskId: ownerTaskId };
    }
    const record = {
      id,
      ...parent === void 0 ? {} : { parent },
      ...owner === void 0 ? {} : { owner }
    };
    const copies = parent === void 0 ? [] : await prepareForkDocumentCopies(this.#host.storage, parent.conversationId, parent.at, id, this.#context);
    this.#assertOpen();
    for (const copy of copies) {
      this.#forkSourceDocumentIds.add(copy.source.id);
      const entry = {
        addressId: addressId(copy.record),
        address: copy.record,
        target: { kind: "fork-copy", ...copy },
        retireOnCommit: false
      };
      this.#documents.push(entry);
      this.#latestDocumentByAddress.set(entry.addressId, entry);
    }
    if (parent !== void 0)
      this.#forkSourceConversationIds.add(parent.conversationId);
    this.#createdConversationIds.add(id);
    this.#writes.push({ type: "conversation", value: record });
    await this.#host.conversationCreated(this, record);
    this.#assertOpen();
    return record;
  }
  appendEntry(first, second, third) {
    if (typeof first === "number")
      return this.#appendEntry(first, second);
    return this.#appendEntry(second, { ...third, kind: first.kind });
  }
  #appendEntry(conversationId, value) {
    return this.#write(async () => {
      await this.#requireConversation(conversationId);
      this.#assertOpen();
      const id = await this.#host.storage.mintId();
      this.#assertOpen();
      const { head, ...rest } = value;
      const record = copyJson({
        ...rest,
        id,
        conversationId,
        head: head === "self" ? id : head,
        byTaskId: this.#scope.taskId
      }, TABLE_JSON_COPY_OPTIONS);
      this.#writes.push({ type: "entry", value: record });
      return record;
    });
  }
  createTask(task, input, options) {
    return this.#write(async () => {
      const ownership = options.ownership;
      let owner;
      if (ownership.kind === "task") {
        owner = await this.#currentTask(ownership.taskId);
        this.#assertOpen();
        if (owner === void 0)
          throw new Error(`Task owner ${ownership.taskId} does not exist`);
        if (options.background === true)
          throw new TypeError("A child task cannot be background");
        if (options.conversationId !== void 0 && options.conversationId !== owner.conversationId) {
          throw new Error(`A child task lives in its owner's conversation ${owner.conversationId}`);
        }
      }
      const conversationId = owner?.conversationId ?? options.conversationId ?? this.#scope.conversationId;
      if (conversationId === void 0)
        throw new TypeError("Tx.createTask() requires options.conversationId");
      await this.#requireConversation(conversationId);
      this.#assertOpen();
      const definition = task.definition;
      const checkpoint = definition.initial(input);
      const id = await this.#host.storage.mintId();
      this.#assertOpen();
      const record = copyJson({
        id,
        conversationId,
        kind: definition.name,
        version: definition.version,
        input,
        ...owner === void 0 ? {} : { owner: owner.id },
        background: options.background ?? false,
        abortRequested: false,
        state: { status: "pending", checkpoint }
      }, TABLE_JSON_COPY_OPTIONS);
      this.#tasksById.set(id, { write: { kind: "create", record } });
      return id;
    });
  }
  /** Create a raw submission record with a fresh ID; no admission rules apply. */
  createSubmission(create) {
    return this.#write(async () => {
      await this.#requireConversation(create.conversationId);
      this.#assertOpen();
      const id = await this.#host.storage.mintId();
      this.#assertOpen();
      const record = copyJson({ ...create, id }, TABLE_JSON_COPY_OPTIONS);
      this.#submissions.set(id, record);
      return record;
    });
  }
  /**
   * Settle a submission. Resolved during assembly against the transaction's latest candidate record, falling back to
   * committed state, so it is not a caller table read and works after the first table write.
   */
  settleSubmission(id, settlement) {
    this.#assertOpen();
    this.#hasTableWrite = true;
    this.#submissionChanges.push({ id, change: copyJson(settlement) });
  }
  /** Place a queued submission at `entry`; resolved during assembly like `settleSubmission()`. */
  placeSubmission(id, entry) {
    this.#assertOpen();
    this.#hasTableWrite = true;
    this.#submissionChanges.push({ id, change: { status: "placed", entry } });
  }
  /** Internal: replace one task record completely. Tasks change their own state through their runtime. */
  setTask(value) {
    this.#assertOpen();
    this.#hasTableWrite = true;
    const task = this.#taskEntry(value.id);
    const candidate = task.write?.record;
    if (candidate?.state.status === "terminal") {
      throw new Error(`Task ${value.id} already has a terminal candidate`);
    }
    if (candidate !== void 0 && candidate.conversationId !== value.conversationId) {
      throw new Error(`Task ${value.id} cannot change conversations`);
    }
    task.write = {
      kind: task.write?.kind === "create" ? "create" : "replace",
      record: copyJson(value, TABLE_JSON_COPY_OPTIONS)
    };
  }
  /** Internal: candidate records of the tasks this transaction created or replaced so far. */
  stagedTasks() {
    const records = [];
    for (const task of this.#tasksById.values())
      if (task.write !== void 0)
        records.push(task.write.record);
    return records;
  }
  /** Internal: conversations this transaction created or forked so far. */
  stagedConversations() {
    const records = [];
    for (const write of this.#writes)
      if (write.type === "conversation")
        records.push(write.value);
    return records;
  }
  doc(token, ...args) {
    try {
      this.#assertOpen();
      const definition = token.definition;
      const resolved = resolveAddress(definition, args);
      this.#assertTaskDocumentsOpen(resolved);
      const latest = this.#latestDocumentByAddress.get(resolved.id);
      if (latest !== void 0 && !latest.retireOnCommit) {
        if (latest.draftPromise !== void 0)
          return latest.draftPromise;
        if (latest.target?.kind === "fork-copy") {
          latest.draftPromise = this.#track(this.#acquireForkCopy(latest, definition, latest.target));
          return latest.draftPromise;
        }
      }
      const seed = definition.family === true ? copyJson(args[resolved.nextArgument]) : void 0;
      const docEntry = {
        addressId: resolved.id,
        address: resolved.address,
        definition,
        retireOnCommit: false
      };
      this.#documents.push(docEntry);
      this.#latestDocumentByAddress.set(docEntry.addressId, docEntry);
      docEntry.draftPromise = this.#track(this.#acquire(docEntry, seed, latest?.retireOnCommit === true));
      return docEntry.draftPromise;
    } catch (error) {
      return Promise.reject(error);
    }
  }
  retireDoc(token, ...args) {
    try {
      this.#assertOpen();
      const definition = token.definition;
      const resolved = resolveAddress(definition, args);
      const latest = this.#latestDocumentByAddress.get(resolved.id);
      if (latest?.retireOnCommit)
        return Promise.resolve();
      if (latest?.target?.kind === "fork-copy") {
        checkRecordScope(definition, latest.target.record);
        latest.retireOnCommit = true;
        return Promise.resolve();
      }
      if (latest?.draftPromise !== void 0) {
        latest.retireOnCommit = true;
        return this.#track(latest.draftPromise.then(() => void 0));
      }
      const entry = {
        addressId: resolved.id,
        address: resolved.address,
        definition,
        retireOnCommit: true
      };
      this.#documents.push(entry);
      this.#latestDocumentByAddress.set(entry.addressId, entry);
      return this.#track(this.#findRetirement(entry));
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #acquire(entry, seed, skipLoad) {
    const definition = entry.definition;
    const loaded = skipLoad ? void 0 : await this.#host.load(definition, entry.addressId, entry.address, this.#context);
    this.#assertOpen();
    if (loaded !== void 0) {
      checkRecordScope(definition, loaded.record);
      checkRecordVersion(definition, loaded.record, loaded.storedVersion);
      entry.target = { kind: "loaded", document: loaded };
      entry.change = loaded.tracker.beginChange();
      return entry.change.state;
    }
    const scope = entry.address.scope;
    if (scope.kind === "conversation")
      await this.#requireConversation(scope.conversationId);
    if (scope.kind === "task") {
      const task = await this.#currentTask(scope.taskId);
      if (task === void 0)
        throw new Error(`Task ${scope.taskId} does not exist`);
      if (task.state.status === "terminal")
        throw new Error(`Task ${scope.taskId} is terminal`);
    }
    this.#assertOpen();
    const value = copyJson(definition.family === true ? definition.initial(seed) : definition.initial());
    const id = await this.#host.storage.mintId();
    this.#assertOpen();
    const tracker = track(value);
    entry.target = {
      kind: "created",
      record: documentCreate(definition, entry.address, id),
      version: definition.version,
      tracker
    };
    entry.change = tracker.beginChange();
    return entry.change.state;
  }
  async #acquireForkCopy(entry, definition, target) {
    const stored = await this.#host.storage.document(target.source.id, target.source.at, this.#context);
    this.#assertOpen();
    if (stored === void 0) {
      throw new Error(`Fork source document ${target.source.id} cannot be read`);
    }
    if (stored.record.scope.kind !== "conversation" || stored.record.kind !== target.record.kind || stored.record.key !== target.record.key || stored.record.history !== target.record.history || stored.record.fork !== target.record.fork) {
      throw new Error(`Fork source document ${target.source.id} does not match the copied record`);
    }
    const value = materializeDocumentValue(definition, target.record, stored.version, stored.value);
    const tracker = track(value);
    entry.definition = definition;
    entry.target = { kind: "created", record: target.record, version: definition.version, tracker };
    entry.change = tracker.beginChange();
    return entry.change.state;
  }
  async #findRetirement(entry) {
    const record = this.#host.cached(entry.addressId)?.record ?? await this.#host.storage.findDocument(entry.address, "current", this.#context);
    this.#assertOpen();
    if (record === void 0)
      return;
    checkRecordScope(entry.definition, record);
    entry.target = { kind: "retire-only", record };
  }
  // ─── Settlement ─────────────────────────────────────────────────────────
  /** Seal after callback failure: abort every change and observe every pending operation. */
  async settleFailure() {
    this.#sealed = true;
    this.#abortChanges();
    await Promise.allSettled(this.#pendingOperations);
  }
  /**
   * Seal after callback success, prepare every open change, and assemble the atomic batch.
   * Any failure aborts every change before Storage admission.
   */
  async settleSuccess() {
    this.#sealed = true;
    if (this.#pendingOperations.size > 0) {
      this.#abortChanges();
      await Promise.allSettled(this.#pendingOperations);
      throw new Error("Session commit callback settled before its pending Tx operations");
    }
    try {
      for (const document of this.#documents) {
        if (document.change !== void 0)
          document.prepared = document.change.prepare();
      }
      return await this.#assemble();
    } catch (error) {
      this.#abortChanges();
      throw error;
    }
  }
  /** Abort every prepared change after Storage failure or when no write is required. */
  discard() {
    this.#abortChanges();
  }
  /** Adopt every prepared change by pointer swap after Storage success and describe the publication. */
  adopt(seq) {
    const publications = [];
    for (const plan of this.#plans) {
      const committed = "createdAt" in plan.record;
      let record = committed ? plan.record : { ...plan.record, createdAt: seq };
      if (plan.retire)
        record = { ...record, retiredAt: seq };
      const change = plan.change;
      if (change !== void 0) {
        const { tracker, prepared, loaded, version } = change;
        if (loaded === void 0 ? !plan.retire : prepared.ops.length > 0)
          tracker.adopt(prepared);
        else
          prepared.abort();
        if (loaded !== void 0) {
          if (loaded.storedVersion < version)
            loaded.storedVersion = version;
          if (plan.content?.type === "document.change") {
            if (plan.content.content.kind === "base")
              loaded.deltasSinceBase = 0;
            else
              loaded.deltasSinceBase++;
          }
        } else if (!plan.retire) {
          this.#host.install({
            addressId: plan.addressId,
            record,
            storedVersion: version,
            valueVersion: version,
            deltasSinceBase: 0,
            tracker
          });
        }
      }
      const conversationId = plan.conversationId;
      if (plan.retire) {
        if (committed)
          this.#host.evict(plan.addressId, record.id);
        const retired = { version: void 0, value: null, ops: EMPTY_OPERATIONS };
        publications.push({ type: "document", record, conversationId, ...retired });
      } else if (plan.content?.type === "document.copy") {
        publications.push({
          type: "document.copy",
          record,
          conversationId,
          source: plan.content.source
        });
      } else if (change !== void 0 && publishes(plan)) {
        const ops = change.loaded === void 0 ? EMPTY_OPERATIONS : change.prepared.ops;
        publications.push({
          type: "document",
          record,
          conversationId,
          version: change.version,
          value: change.prepared.value,
          ops
        });
      }
    }
    return publications;
  }
  async #assemble() {
    const storage = this.#host.storage;
    const plans = this.#plans;
    for (const document of this.#documents) {
      const plan = planDocument(document);
      if (plan !== void 0)
        plans.push(plan);
    }
    this.#rejectForkSourceWrites(plans);
    await this.#validateOwners();
    for (const [id, task] of this.#tasksById) {
      if (task.write?.kind !== "replace")
        continue;
      const committed = await this.#committedTask(id);
      if (committed === void 0)
        throw new Error(`Task ${id} does not exist`);
      if (committed.state.status === "terminal")
        throw new Error(`Task ${id} is already terminal`);
      if (committed.conversationId !== task.write.record.conversationId) {
        throw new Error(`Task ${id} cannot change conversations`);
      }
    }
    const terminalTaskIds = /* @__PURE__ */ new Set();
    for (const task of this.#tasksById.values()) {
      if (task.write?.record.state.status === "terminal")
        terminalTaskIds.add(task.write.record.id);
    }
    if (terminalTaskIds.size > 0) {
      const retiring = /* @__PURE__ */ new Set();
      for (const plan of plans) {
        const scope = plan.record.scope;
        if (scope.kind !== "task" || !terminalTaskIds.has(scope.taskId))
          continue;
        plan.retire = true;
        retiring.add(plan.record.id);
      }
      for (const taskId of terminalTaskIds) {
        if (this.#tasksById.get(taskId)?.write?.kind === "create")
          continue;
        let cursor;
        do {
          const page2 = await storage.scanDocuments({ scope: { kind: "task", taskId }, at: "current" }, INTERNAL_SCAN_PAGE_SIZE, cursor, this.#context);
          for (const record of page2.items) {
            if (retiring.has(record.id))
              continue;
            plans.push({ addressId: addressId(record), record, retire: true });
            retiring.add(record.id);
          }
          cursor = page2.next;
        } while (cursor !== void 0);
      }
    }
    for (const plan of plans) {
      if (!publishes(plan))
        continue;
      const scope = plan.record.scope;
      if (scope.kind === "conversation")
        plan.conversationId = scope.conversationId;
      if (scope.kind !== "task")
        continue;
      const task = this.#taskEntry(scope.taskId);
      if (task.publicationConversationId === void 0) {
        const current = await this.#currentTask(scope.taskId);
        if (current !== void 0)
          task.publicationConversationId = current.conversationId;
      }
      plan.conversationId = task.publicationConversationId;
    }
    for (const { id, change } of this.#submissionChanges) {
      const current = this.#submissions.get(id) ?? await storage.submission(id, this.#context);
      if (current === void 0)
        throw new Error(`Submission ${id} does not exist`);
      const next = applySubmissionChange(current, change);
      if (next !== current)
        this.#submissions.set(id, next);
    }
    const writes = this.#writes;
    for (const value of this.#submissions.values())
      writes.push({ type: "submission", value });
    for (const task of this.#tasksById.values()) {
      if (task.write !== void 0)
        writes.push({ type: "task", value: task.write.record });
    }
    for (const plan of plans) {
      const change = plan.change;
      if (plan.content?.type === "document.change" && plan.content.content.kind === "delta" && change?.loaded) {
        const { prepared, version } = change;
        const info = { deltasSinceBase: change.loaded.deltasSinceBase };
        if (change.definition?.checkpointWhen?.(prepared.value, prepared.ops, info)) {
          plan.content = { ...plan.content, content: { version, kind: "base", value: prepared.value } };
        }
      }
      if (plan.content !== void 0)
        writes.push(plan.content);
      if (plan.retire)
        writes.push({ type: "document.retire", id: plan.record.id });
    }
    return writes;
  }
  // ─── Helpers ────────────────────────────────────────────────────────────
  /**
   * New owned work needs a live owner, judged on the owner's final candidate: not `completing`, terminal, or
   * abort-marked. A task therefore cannot create owned work in the commit that finishes it (spec §5.5).
   */
  async #validateOwners() {
    const owners = [];
    for (const write of this.#writes) {
      if (write.type !== "conversation" || write.value.owner === void 0)
        continue;
      owners.push({ what: "Conversation owner task", taskId: write.value.owner.taskId });
    }
    for (const task of this.#tasksById.values()) {
      const record = task.write?.kind === "create" ? task.write.record : void 0;
      if (record?.owner !== void 0)
        owners.push({ what: "Task owner", taskId: record.owner });
    }
    for (const { what, taskId } of owners) {
      const task = await this.#currentTask(taskId);
      if (task === void 0)
        throw new Error(`${what} ${taskId} does not exist`);
      if (task.state.status === "terminal" || task.state.status === "completing") {
        throw new Error(`${what} ${taskId} is ${task.state.status}`);
      }
      if (task.abortRequested)
        throw new Error(`${what} ${taskId} is abort-marked`);
    }
  }
  #rejectForkSourceWrites(plans) {
    for (const plan of plans) {
      if (plan.content === void 0 && !plan.retire)
        continue;
      const record = plan.record;
      if (this.#forkSourceDocumentIds.has(record.id)) {
        throw new Error(`Cannot change fork source document ${record.id} in the fork transaction`);
      }
      const scope = plan.record.scope;
      if (scope.kind === "conversation" && this.#forkSourceConversationIds.has(scope.conversationId) && record.scope.kind === "conversation" && record.fork === "current") {
        throw new Error(`Cannot fork conversation ${scope.conversationId} while changing its current-policy documents`);
      }
    }
  }
  #abortChanges() {
    for (const document of this.#documents)
      document.change?.abort();
  }
  #assertOpen() {
    if (this.#sealed)
      throw new Error("Transaction has settled");
  }
  #assertTaskDocumentsOpen(resolved) {
    const scope = resolved.address.scope;
    if (scope.kind === "task" && this.#tasksById.get(scope.taskId)?.write?.record.state.status === "terminal") {
      throw new Error(`Task ${scope.taskId} is terminal`);
    }
  }
  /** Register an operation so callback settlement can reject and drain it. */
  #track(operation) {
    this.#pendingOperations.add(operation);
    const settle2 = () => {
      this.#pendingOperations.delete(operation);
    };
    operation.then(settle2, settle2);
    return operation;
  }
  #read(method, read) {
    try {
      this.#assertOpen();
      if (this.#hasTableWrite)
        throw new ReadAfterWrite(method);
      return this.#track(read());
    } catch (error) {
      return Promise.reject(error);
    }
  }
  #write(write) {
    try {
      this.#assertOpen();
      this.#hasTableWrite = true;
      return this.#track(write());
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #requireConversation(id) {
    if (this.#createdConversationIds.has(id))
      return;
    if (await this.#host.storage.conversation(id, this.#context) === void 0) {
      throw new Error(`Conversation ${id} does not exist`);
    }
  }
  #taskEntry(id) {
    let task = this.#tasksById.get(id);
    if (task === void 0) {
      task = {};
      this.#tasksById.set(id, task);
    }
    return task;
  }
  /** Latest candidate task record, falling back to committed state; not a caller table read. */
  async #currentTask(id) {
    return this.#tasksById.get(id)?.write?.record ?? await this.#committedTask(id);
  }
  #committedTask(id) {
    const task = this.#taskEntry(id);
    task.committedRead ??= this.#host.storage.task(id, this.#context);
    return task.committedRead;
  }
};
function planDocument(document) {
  const target = document.target;
  if (target === void 0)
    return void 0;
  const plan = { addressId: document.addressId, retire: document.retireOnCommit };
  switch (target.kind) {
    case "created": {
      const prepared = document.prepared;
      const { record, version, tracker } = target;
      const content = { version, kind: "base", value: prepared.value };
      return {
        ...plan,
        record,
        content: { type: "document.create", record, content },
        change: { tracker, prepared, version }
      };
    }
    case "fork-copy":
      return {
        ...plan,
        record: target.record,
        content: { type: "document.copy", record: target.record, source: target.source }
      };
    case "retire-only":
      return { ...plan, record: target.record };
    case "loaded": {
      const loaded = target.document;
      const definition = document.definition;
      const prepared = document.prepared;
      const version = definition.version;
      const id = loaded.record.id;
      const content = loaded.storedVersion < version ? { type: "document.change", id, content: { version, kind: "base", value: prepared.value } } : prepared.ops.length > 0 ? { type: "document.change", id, content: { version, kind: "delta", ops: prepared.ops } } : void 0;
      const change = {
        tracker: loaded.tracker,
        prepared,
        version,
        loaded,
        definition
      };
      return { ...plan, record: loaded.record, change, ...content === void 0 ? {} : { content } };
    }
  }
}
function publishes(plan) {
  return plan.retire || plan.change?.loaded === void 0 || plan.content !== void 0;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/session/session.js
function createSession(storage) {
  return new SessionImpl(storage);
}
var SessionImpl = class {
  #storage;
  #documents = /* @__PURE__ */ new Map();
  #commitListeners = /* @__PURE__ */ new Set();
  #closeListeners = /* @__PURE__ */ new Set();
  #host;
  #tail = Promise.resolve();
  #closing;
  #poison;
  constructor(storage) {
    this.#storage = storage;
    this.#host = {
      storage,
      cached: (id) => this.#documents.get(id),
      load: (definition, addressId2, address, context) => this.#loadDocument(definition, addressId2, address, context),
      install: (document) => {
        this.#documents.set(document.addressId, document);
      },
      evict: (id, recordId) => {
        if (this.#documents.get(id)?.record.id === recordId)
          this.#documents.delete(id);
      },
      conversationCreated: (tx, record) => this.conversationCreated(tx, record)
    };
  }
  commit(change, context) {
    return this.commitWith(change, context);
  }
  /**
   * Internal commit exposing the concrete transaction and its internal operations, such as the reserved-ID root
   * bootstrap and task replacement. `scope` sets the default `tx.createTask()` conversation and the task attributed to
   * appended entries.
   */
  commitWith(change, context, scope) {
    try {
      this.#assertUsable();
    } catch (error) {
      return Promise.reject(error);
    }
    return this.#enqueue(() => this.#runCommit(change, context, scope));
  }
  /** Internal: run a read-only job on the mutation line so multi-read derivations observe one committed state. */
  readOnLine(job) {
    try {
      this.#assertUsable();
    } catch (error) {
      return Promise.reject(error);
    }
    return this.#enqueue(async () => {
      this.#assertHealthy();
      return job();
    });
  }
  /**
   * Internal: a conversation document's current incarnation and value, for a job already running on the line (see
   * `readOnLine()`). Absent documents are `undefined`.
   */
  async conversationDocumentOnLine(token, conversationId, context) {
    const definition = token.definition;
    const resolved = resolveAddress(definition, [conversationId, context]);
    const loaded = await this.#loadDocument(definition, resolved.id, resolved.address, context);
    if (loaded === void 0)
      return void 0;
    checkRecordScope(definition, loaded.record);
    checkRecordVersion(definition, loaded.record, loaded.storedVersion);
    return { record: loaded.record, version: loaded.valueVersion, value: loaded.tracker.value };
  }
  async snapshot(token, ...args) {
    this.#assertUsable();
    const definition = token.definition;
    const resolved = resolveAddress(definition, args);
    const context = args[resolved.nextArgument];
    const cached = this.#documents.get(resolved.id);
    const loaded = cached?.valueVersion === definition.version ? cached : await this.#enqueue(async () => {
      this.#assertHealthy();
      return this.#loadDocument(definition, resolved.id, resolved.address, context);
    });
    if (loaded === void 0)
      return void 0;
    checkRecordScope(definition, loaded.record);
    checkRecordVersion(definition, loaded.record, loaded.storedVersion);
    return loaded.tracker.value;
  }
  documentState(token, ...args) {
    try {
      this.#assertUsable();
      const definition = token.definition;
      const resolved = resolveAddress(definition, args);
      const context = args[resolved.nextArgument];
      return this.#enqueue(async () => {
        this.#assertHealthy();
        const loaded = await this.#loadDocument(definition, resolved.id, resolved.address, context);
        if (loaded === void 0)
          return void 0;
        const { observer: source, detach } = this.#attachDocument(definition, loaded, (value, release) => new CommittedStateSource(value, release));
        try {
          return replicatedState(source);
        } catch (error) {
          detach();
          throw error;
        }
      });
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async watchDoc(token, ...args) {
    this.#assertUsable();
    const definition = token.definition;
    const resolved = resolveAddress(definition, args);
    const context = args[resolved.nextArgument];
    const signal = context.abortSignal;
    let cancelled = signal?.aborted ?? false;
    const markCancelled = () => {
      cancelled = true;
    };
    signal?.addEventListener("abort", markCancelled, { once: true });
    try {
      const watch = await this.#enqueue(async () => {
        this.#assertHealthy();
        if (cancelled)
          throw cancellationError(signal);
        const loaded = await this.#loadDocument(definition, resolved.id, resolved.address, context);
        if (cancelled)
          throw cancellationError(signal);
        if (loaded === void 0)
          return void 0;
        return this.#attachDocument(definition, loaded, (value, release) => new CommittedWatch(value, release)).observer;
      });
      if (watch === void 0)
        return void 0;
      if (cancelled) {
        watch.cancel();
        throw cancellationError(signal);
      }
      if (signal !== void 0)
        watch.observeCancellation(signal);
      return watch;
    } finally {
      signal?.removeEventListener("abort", markCancelled);
    }
  }
  async snapshotAsOf(token, ...args) {
    this.#assertUsable();
    const definition = token.definition;
    const resolved = resolveAddress(definition, args);
    if (resolved.address.scope.kind !== "conversation") {
      throw new TypeError("Session.snapshotAsOf() requires a conversation document");
    }
    const conversationId = resolved.address.scope.conversationId;
    const atValue = args[resolved.nextArgument];
    if (typeof atValue !== "number" || !Number.isSafeInteger(atValue)) {
      throw new TypeError("Session.snapshotAsOf() requires an entry ID");
    }
    const at = idFromNumber(atValue);
    const context = args[resolved.nextArgument + 1];
    return this.#enqueue(async () => {
      this.#assertHealthy();
      const storedEntry = await this.#storage.entry(conversationId, at, context);
      if (storedEntry === void 0) {
        throw new Error(`Entry ${at} is not visible from conversation ${conversationId}`);
      }
      const address = {
        ...resolved.address,
        scope: { kind: "conversation", conversationId: storedEntry.entry.conversationId }
      };
      const record = await this.#storage.findDocument(address, storedEntry.commitSeq, context);
      if (record === void 0)
        return void 0;
      const stored = await this.#storage.document(record.id, storedEntry.commitSeq, context);
      if (stored === void 0) {
        throw new Error(`Historical document ${record.id} (${record.kind}) cannot be read`);
      }
      return materializeDocument(definition, stored);
    });
  }
  close(context) {
    if (this.#closing === void 0) {
      const cleanup = withoutAbortSignal(context);
      this.#closing = Promise.resolve().then(() => this.beforeClose()).then(() => this.#enqueue(async () => {
        this.#commitListeners.clear();
        this.#documents.clear();
        await this.#storage.close(cleanup);
      }));
      const listeners = [...this.#closeListeners];
      this.#closeListeners.clear();
      for (const listener of listeners)
        listener();
    }
    return awaitWithContext(this.#closing, context);
  }
  /**
   * Runs inside every transaction that creates or forks a conversation, after the conversation record is staged. A
   * plain Session stages nothing; a Harness stages its built-in documents.
   */
  conversationCreated(_tx, _record) {
    return Promise.resolve();
  }
  /** Runs after close seals admission and before the line closes Storage; must not reject. */
  beforeClose() {
    return Promise.resolve();
  }
  /** Register a synchronous post-adoption listener. It must not throw, block, or call Session operations. */
  subscribeCommits(listener) {
    this.#assertUsable();
    this.#commitListeners.add(listener);
    return () => this.#commitListeners.delete(listener);
  }
  /** Register a listener called synchronously when close begins. It must not throw, block, or call Session operations. */
  subscribeClose(listener) {
    this.#assertUsable();
    this.#closeListeners.add(listener);
    return () => this.#closeListeners.delete(listener);
  }
  /** Drop every loaded tracker on the mutation line; later access cold-loads from Storage. */
  unloadDocuments() {
    return this.#enqueue(async () => {
      this.#documents.clear();
    });
  }
  async #runCommit(change, context, scope) {
    this.#assertHealthy();
    context.abortSignal?.throwIfAborted();
    const tx = new Transaction(this.#host, context, scope);
    let result;
    try {
      result = await change(tx);
    } catch (error) {
      await tx.settleFailure();
      throw error;
    }
    const writes = await tx.settleSuccess();
    if (writes.length === 0) {
      tx.discard();
      return result;
    }
    let seq;
    try {
      seq = await this.#storage.commit(writes, withoutAbortSignal(context));
    } catch (error) {
      tx.discard();
      if (!(error instanceof StorageRejected))
        this.#poison = { error };
      throw error;
    }
    let documents;
    try {
      documents = tx.adopt(seq);
    } catch (error) {
      this.#poison = { error };
      throw error;
    }
    this.#publish(seq, writes, documents, context);
    return result;
  }
  #publish(seq, writes, documents, context) {
    if (this.#commitListeners.size === 0)
      return;
    const changes = [];
    for (const write of writes) {
      switch (write.type) {
        case "conversation":
        case "entry":
        case "task":
        case "submission":
          changes.push(write);
      }
    }
    for (const document of documents)
      changes.push(document);
    const publication = { seq, changes };
    for (const listener of [...this.#commitListeners])
      listener(publication, context);
  }
  /**
   * Attach an observer to one committed incarnation: check the definition, then forward this incarnation's committed
   * changes and close. `detach` removes both subscriptions.
   */
  #attachDocument(definition, loaded, create) {
    checkRecordScope(definition, loaded.record);
    checkRecordVersion(definition, loaded.record, loaded.storedVersion);
    let unsubscribeCommit = () => {
    };
    let unsubscribeClose = () => {
    };
    const detach = () => {
      unsubscribeCommit();
      unsubscribeClose();
    };
    const observer = create(loaded.tracker.value, detach);
    const observed = { version: loaded.valueVersion };
    unsubscribeCommit = this.subscribeCommits((publication, context) => {
      for (const change of publication.changes) {
        if (change.type !== "document" || change.record.id !== loaded.record.id)
          continue;
        const frameContext = observer instanceof CommittedStateSource ? withoutAbortSignal(context) : context;
        const ops = observedOperations(observed, change);
        if (ops.length === 0)
          continue;
        observer.advance(change.value, ops, frameContext);
      }
    });
    unsubscribeClose = this.subscribeClose(() => observer.closeSession());
    return { observer, detach };
  }
  async #loadDocument(definition, addressId2, address, context) {
    const cached = this.#documents.get(addressId2);
    if (cached?.valueVersion === definition.version)
      return cached;
    if (cached !== void 0)
      this.#documents.delete(addressId2);
    const record = await this.#storage.findDocument(address, "current", context);
    if (record === void 0)
      return void 0;
    const stored = await this.#storage.document(record.id, "current", context);
    if (stored === void 0)
      throw new Error(`Current document ${record.id} (${record.kind}) cannot be read`);
    const value = materializeDocument(definition, stored);
    const loaded = {
      addressId: addressId2,
      record: stored.record,
      storedVersion: stored.version,
      valueVersion: definition.version,
      deltasSinceBase: stored.deltasSinceBase,
      tracker: track(value)
    };
    this.#documents.set(addressId2, loaded);
    return loaded;
  }
  #enqueue(job) {
    const run2 = this.#tail.then(job);
    this.#tail = run2.then(() => void 0, () => void 0);
    return run2;
  }
  #assertUsable() {
    if (this.#closing !== void 0)
      throw new Error("Session is closed");
    this.#assertHealthy();
  }
  #assertHealthy() {
    if (this.#poison !== void 0) {
      throw new Error("Session is poisoned by a failed commit after storage admission; reopen it", {
        cause: this.#poison.error
      });
    }
  }
};
function observedOperations(observed, change) {
  if (change.value === null)
    return RETIREMENT_OPERATIONS;
  if (change.version === observed.version)
    return change.ops;
  observed.version = change.version;
  return [["r", change.value]];
}
function cancellationError(signal) {
  return signal.reason instanceof Error ? signal.reason : new DOMException("The operation was aborted", "AbortError");
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/registry.js
var SECTION_KEY = /^[a-z][a-z0-9_-]*$/;
var BUILTIN_TASKS = [GenerationTask, ToolTask, CompactionTask];
var RegistryState = class {
  #extensions;
  #byName;
  #tasks;
  constructor(extensions) {
    this.#extensions = extensions;
    this.#byName = new Map(extensions.map((extension) => [extension.name, extension]));
    const tasks = /* @__PURE__ */ new Map();
    for (const task of BUILTIN_TASKS)
      tasks.set(task.definition.name, task);
    for (const extension of extensions) {
      for (const task of extension.tasks ?? []) {
        const name = task.definition.name;
        if (tasks.has(name))
          throw new Error(`Task ${name} of extension ${extension.name} is already installed`);
        tasks.set(name, task);
      }
    }
    this.#tasks = tasks;
  }
  installed() {
    return this.#extensions;
  }
  extension(name) {
    return this.#byName.get(name);
  }
  tools() {
    return this.#extensions.flatMap((extension) => (extension.tools ?? []).map((tool) => ({ extension, tool })));
  }
  sections() {
    return this.#extensions.flatMap((extension) => (extension.sections ?? []).map((section2) => ({ extension, section: section2 })));
  }
  tasks() {
    return [...this.#tasks.values()];
  }
  task(name) {
    return this.#tasks.get(name);
  }
};
var RegistryImpl = class {
  #current = new RegistryState([]);
  #listeners = /* @__PURE__ */ new Set();
  snapshot() {
    return this.#current;
  }
  subscribe(listener) {
    this.#listeners.add(listener);
    return () => this.#listeners.delete(listener);
  }
  install(extension) {
    validateExtension(extension);
    const current = this.#current.installed();
    const index3 = current.findIndex((installed) => installed.name === extension.name);
    const next = index3 < 0 ? [...current, extension] : current.map((installed, at) => at === index3 ? extension : installed);
    this.#publish(next);
  }
  uninstall(extension) {
    const current = this.#current.installed();
    if (!current.some((installed) => installed.name === extension.name))
      return;
    this.#publish(current.filter((installed) => installed.name !== extension.name));
  }
  /** Build and validate the next state, which throws on a task name collision, then publish it synchronously. */
  #publish(extensions) {
    this.#current = new RegistryState(extensions);
    for (const listener of [...this.#listeners])
      listener();
  }
};
function validateExtension(extension) {
  const tools = /* @__PURE__ */ new Set();
  for (const tool of extension.tools ?? []) {
    if (tools.has(tool.name))
      throw new Error(`Extension ${extension.name} has two tools named ${tool.name}`);
    tools.add(tool.name);
  }
  const sections = /* @__PURE__ */ new Set();
  for (const { key } of extension.sections ?? []) {
    if (!SECTION_KEY.test(key))
      throw new TypeError(`Section key ${JSON.stringify(key)} must match ${SECTION_KEY}`);
    if (key === INSTRUCTIONS_KEY)
      throw new Error(`Section key ${key} is reserved for the agent's instructions`);
    if (sections.has(key))
      throw new Error(`Extension ${extension.name} has two sections with key ${key}`);
    sections.add(key);
  }
}
function createRegistry() {
  return new RegistryImpl();
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/scheduler.js
var SCAN_PAGE_SIZE3 = 256;
var MAX_TIMER_DELAY = 2147483647;
var LIVE_STATUSES = ["pending", "running", "waiting", "completing"];
var TaskScheduler = class {
  #session;
  #storage;
  #registry;
  #models;
  #agent;
  #settings;
  #env;
  #now;
  #report;
  #settleOutcome;
  #withdrawInputs;
  #conversation;
  #context;
  #live = /* @__PURE__ */ new Map();
  #invocations = /* @__PURE__ */ new Map();
  #taskWaiters = new Waiters();
  /** Idle waiters by conversation; `undefined` waits for the whole Harness. */
  #idleWaiters = new Waiters();
  /** Definition whose migration failed per task; retried only once the registry resolves another definition. */
  #failedMigrations = /* @__PURE__ */ new Map();
  /** Owner task of each loaded conversation, `null` when ownerless. */
  #edges = /* @__PURE__ */ new Map();
  /** Tasks that own a loaded conversation; their nodes stay in `#settled` once terminal. */
  #conversationOwners = /* @__PURE__ */ new Set();
  /** Ownership fields of terminal tasks that walks pass through. */
  #settled = /* @__PURE__ */ new Map();
  /**
   * `failFast` waiters the next reconcile checks for a failed task in `on`: at open, when they start waiting, and when
   * one of their tasks fails.
   */
  #failFastChecks = /* @__PURE__ */ new Set();
  #reconcileScheduled = false;
  #cascadePending = false;
  #unsubscribeRegistry = () => {
  };
  #enabled = false;
  #closing = false;
  #dirty = false;
  #draining = false;
  constructor(options) {
    this.#session = options.session;
    this.#storage = options.storage;
    this.#registry = options.registry;
    this.#models = options.models;
    this.#agent = options.agent;
    this.#settings = options.settings;
    this.#env = options.env;
    this.#now = options.now;
    this.#report = options.report;
    this.#settleOutcome = options.settleOutcome;
    this.#withdrawInputs = options.withdrawInputs;
    this.#conversation = options.conversation;
    this.#context = options.context;
  }
  /** Load live tasks and change surviving `running` tasks back to `pending`. Dispatches nothing. */
  async open(context) {
    this.#session.subscribeCommits((publication) => this.#observe(publication));
    this.#session.subscribeClose(() => this.#seal());
    this.#unsubscribeRegistry = this.#registry.subscribe(() => this.#kick());
    await this.#session.commitWith(async (tx) => {
      const scans = [];
      for (const status of LIVE_STATUSES) {
        scans.push(await scanAll((cursor) => tx.scanTasks({ status }, SCAN_PAGE_SIZE3, cursor)));
      }
      for (const records of scans) {
        for (const record of records) {
          this.#live.set(record.id, record);
          if (record.state.status === "running") {
            tx.setTask(withState(record, { status: "pending", checkpoint: record.state.checkpoint }));
          }
          if (record.state.status === "waiting" && record.state.policy === "failFast") {
            this.#failFastChecks.add(record.id);
          }
        }
      }
    }, context);
    this.#cascadePending = true;
    this.#scheduleReconcile();
  }
  /** Enable scheduling. Idempotent; the kick does nothing once closing. */
  resume() {
    this.#enabled = true;
    this.#kick();
  }
  /** Wait for every invocation signalled by `#seal()`. Writes nothing. */
  async join() {
    await Promise.allSettled([...this.#invocations.values()].map((invocation) => invocation.done));
  }
  /**
   * Commit the abort mark, or settle a task that no registered definition can take as `orphaned` when nothing it owns
   * is live, then join the run invocation seen on the line; the commit listener signalled it. The abort invocation
   * starts once the task's ordinary owned work is gone. A `completing` task is only marked.
   */
  async abort(id, context) {
    const marked = await this.#session.commitWith(async (tx) => {
      const current = await tx.task(id);
      if (current === void 0)
        throw new Error(`Task ${id} does not exist`);
      if (current.state.status === "terminal")
        return { result: "terminal" };
      const invocation = this.#invocations.get(id);
      if (invocation === void 0 && current.state.status !== "completing") {
        await this.#loadScopes(false);
        if (!this.#ownedLive().has(id)) {
          const resolution = this.#resolve(current, this.#registry.snapshot());
          if (resolution.kind === "blocked") {
            await this.#terminate(tx, current, { status: "orphaned", reason: resolution.reason });
            return { result: "marked" };
          }
        }
      }
      if (!current.abortRequested)
        tx.setTask({ ...current, abortRequested: true });
      return { result: "marked", run: invocation?.mode === "run" ? invocation : void 0 };
    }, context);
    if (marked.run !== void 0)
      await awaitWithContext(marked.run.done, context);
    return marked.result;
  }
  async waitForTask(id, context) {
    const found = await this.#session.readOnLine(async () => {
      if (this.#closing)
        throw closedError();
      if (this.#live.has(id))
        return { promise: this.#taskWaiters.add(id, context) };
      const record = await this.#storage.task(id, context);
      if (record === void 0)
        throw new Error(`Task ${id} does not exist`);
      return { promise: Promise.resolve(record) };
    });
    return found.promise;
  }
  /**
   * Resolve when ordinary traversal from the conversation, or from every ownerless conversation, reaches no live
   * non-background task.
   */
  waitForIdle(conversationId, context) {
    if (this.#closing)
      return Promise.reject(closedError());
    if (this.#idle(conversationId))
      return Promise.resolve();
    this.#scheduleReconcile();
    return this.#idleWaiters.add(conversationId, context);
  }
  /**
   * `Conversation.abort()`: in one commit, withdraw the queued inputs and mark every live non-background task that
   * ordinary traversal from the conversation reaches; resolves once the scope is idle. With `background`, traversal
   * crosses background boundaries, and the wait also covers every task it reached.
   */
  async abortConversation(conversationId, background, context) {
    const reached = await this.#session.commitWith(async (tx) => {
      const queued2 = await this.#loadScopes(true);
      const scope = { conversation: conversationId };
      const reached2 = [];
      for (const record of this.#live.values()) {
        if (record.background && !background)
          continue;
        if (this.#inScope(parentOf(record), scope, background) !== true)
          continue;
        reached2.push(record.id);
        if (!record.abortRequested)
          tx.setTask({ ...record, abortRequested: true });
      }
      for (const id of queued2) {
        if (this.#inScope({ conversation: id }, scope, background) === true)
          await this.#withdrawInputs(tx, id);
      }
      return reached2;
    }, context);
    if (background)
      for (const id of reached)
        await this.waitForTask(id, context);
    await this.waitForIdle(conversationId, context);
  }
  // ─── Scheduling ────────────────────────────────────────────────────────
  #observe(publication) {
    const updated = [];
    const failed = [];
    let changed = false;
    for (const change of publication.changes) {
      if (change.type !== "task")
        continue;
      changed = true;
      const record = change.value;
      const previous = this.#live.get(record.id);
      if (failedOutcome(record) && (previous === void 0 || !failedOutcome(previous)))
        failed.push(record.id);
      if (record.state.status === "terminal") {
        this.#live.delete(record.id);
        this.#failedMigrations.delete(record.id);
        this.#failFastChecks.delete(record.id);
        if (this.#conversationOwners.has(record.id))
          this.#settled.set(record.id, nodeOf(record));
        this.#taskWaiters.resolve(record.id, record);
        this.#scheduleReconcile();
        continue;
      }
      if (record.abortRequested && previous?.abortRequested !== true) {
        this.#cascadePending = true;
        const invocation = this.#invocations.get(record.id);
        if (invocation?.mode === "run")
          invocation.controller.abort();
      }
      const status = record.state.status;
      if (status === "completing" && previous?.state.status !== "completing") {
        if (cancellationIntent(record))
          this.#cascadePending = true;
        this.#scheduleReconcile();
      }
      if (status === "waiting" && record.state.policy === "failFast" && previous?.state.status !== "waiting") {
        this.#failFastChecks.add(record.id);
        this.#scheduleReconcile();
      }
      this.#live.set(record.id, record);
      updated.push(record);
    }
    for (const id of failed) {
      for (const record of this.#live.values()) {
        const state2 = record.state;
        if (state2.status === "waiting" && state2.policy === "failFast" && state2.on.includes(id)) {
          this.#failFastChecks.add(record.id);
          this.#scheduleReconcile();
        }
      }
    }
    for (const change of publication.changes) {
      if (change.type === "conversation" && !this.#edges.has(change.value.id)) {
        this.#setEdge(change.value.id, change.value.owner?.taskId ?? null);
      }
    }
    for (const change of publication.changes) {
      if (change.type !== "submission" || change.value.status !== "queued" || change.value.type !== "input")
        continue;
      const up = { conversation: change.value.conversationId };
      if (!this.#chainKnown(up) || this.#belowCancelled(up))
        this.#cascadePending = true;
    }
    for (const record of updated) {
      if (!this.#chainKnown(parentOf(record)))
        this.#scheduleReconcile();
      else if (!record.background && !record.abortRequested && this.#belowCancelled(parentOf(record))) {
        this.#cascadePending = true;
      }
    }
    if (this.#cascadePending)
      this.#scheduleReconcile();
    if (!changed)
      return;
    this.#resolveIdleWaiters();
    this.#kick();
  }
  #resolveIdleWaiters() {
    for (const conversationId of this.#idleWaiters.keys()) {
      if (this.#idle(conversationId))
        this.#idleWaiters.resolve(conversationId);
    }
  }
  // ─── Ownership ───────────────────────────────────────────────────────────
  #scheduleReconcile() {
    if (this.#reconcileScheduled || this.#closing)
      return;
    this.#reconcileScheduled = true;
    queueMicrotask(() => void this.#reconcile());
  }
  /**
   * One commit that applies what committed records imply: abort marks below live owners with cancellation intent
   * (spec §5.4), `failFast` marks (spec §5.5), withdrawn queued inputs below cancelled owners, and the final terminal
   * record of every `completing` task whose ordinary owned work is gone. The durable records are the intent, so this
   * also repairs whatever a crash left unapplied. Resolves idle waiters that the loaded edges decide.
   */
  async #reconcile() {
    this.#reconcileScheduled = false;
    const cascade = this.#cascadePending;
    this.#cascadePending = false;
    const checks = [...this.#failFastChecks];
    this.#failFastChecks.clear();
    try {
      await this.#session.commitWith(async (tx) => {
        if (this.#closing)
          return;
        const queued2 = await this.#loadScopes(cascade);
        const marked = /* @__PURE__ */ new Set();
        const mark = (record) => {
          if (record.abortRequested || marked.has(record.id))
            return;
          marked.add(record.id);
          tx.setTask({ ...record, abortRequested: true });
        };
        for (const record of this.#live.values()) {
          if (!record.background && this.#belowCancelled(parentOf(record)))
            mark(record);
        }
        for (const id of checks) {
          const waiter = this.#live.get(id);
          if (waiter?.state.status !== "waiting" || !await this.#anyFailed(waiter.state.on))
            continue;
          for (const member of waiter.state.on) {
            const record = this.#live.get(member);
            if (record !== void 0 && !failedOutcome(record))
              mark(record);
          }
        }
        for (const id of queued2)
          if (this.#belowCancelled({ conversation: id }))
            await this.#withdrawInputs(tx, id);
        await this.#finalize(tx);
      }, this.#context);
    } catch (error) {
      this.#cascadePending = true;
      for (const id of checks)
        this.#failFastChecks.add(id);
      if (!this.#closing)
        this.#report(error);
    }
    this.#resolveIdleWaiters();
  }
  /** Whether any of `ids` holds or ended with an outcome other than `completed`. */
  async #anyFailed(ids) {
    for (const id of ids) {
      const record = this.#live.get(id) ?? await this.#storage.task(id, this.#context);
      if (record !== void 0 && failedOutcome(record))
        return true;
    }
    return false;
  }
  /**
   * Write the terminal record of every `completing` task without live ordinary owned work. Finalizing one can free its
   * owner, so this repeats over the commit's candidates until nothing changes. A held scheduler outcome gets its
   * Harness cleanup here.
   */
  async #finalize(tx) {
    for (; ; ) {
      const overlay = overlayOf(tx);
      const owned = this.#ownedLive(overlay);
      const done = [...this.#liveRecords(overlay)].filter((record) => record.state.status === "completing" && !owned.has(record.id));
      if (done.length === 0)
        return;
      for (const record of done) {
        const outcome = record.state.outcome;
        tx.setTask(withState(record, { status: "terminal", outcome }));
        if (outcome.status === "faulted" || outcome.status === "orphaned") {
          await this.#settleOutcome(tx, record, outcome);
        }
      }
    }
  }
  /**
   * Load the owner chains of every live task and, with `queued`, of every conversation with queued submissions, on the
   * Session line; returns the latter. Reads committed Storage directly, so it may run inside a commit callback.
   */
  async #loadScopes(queued2) {
    for (const record of [...this.#live.values()]) {
      if (!this.#chainKnown(parentOf(record)))
        await this.#loadChain(parentOf(record));
    }
    if (!queued2)
      return [];
    const submissions = await scanAll((cursor) => this.#storage.scanSubmissions({ status: "queued" }, SCAN_PAGE_SIZE3, cursor, this.#context));
    const conversations = [...new Set(submissions.map((submission) => submission.conversationId))];
    for (const id of conversations)
      await this.#loadChain({ conversation: id });
    return conversations;
  }
  /** Load the owner edges and task nodes from `start` up to its ownerless root. */
  async #loadChain(start, overlay) {
    let at = start;
    while (at !== void 0) {
      if ("task" in at) {
        let node = this.#node(at.task, overlay);
        if (node === void 0) {
          const record = await this.#storage.task(at.task, this.#context);
          if (record === void 0)
            return;
          node = nodeOf(record);
          if (record.state.status === "terminal")
            this.#settled.set(record.id, node);
        }
        at = parentOf(node);
      } else {
        let edge = this.#edge(at.conversation, overlay);
        if (edge === void 0) {
          const record = await this.#storage.conversation(at.conversation, this.#context);
          edge = record?.owner?.taskId ?? null;
          this.#setEdge(at.conversation, edge);
        }
        at = edge === null ? void 0 : { task: edge };
      }
    }
  }
  #setEdge(conversationId, owner) {
    this.#edges.set(conversationId, owner);
    if (owner !== null)
      this.#conversationOwners.add(owner);
  }
  /** Owner task of a conversation, `null` when ownerless, `undefined` while not loaded. */
  #edge(id, overlay) {
    return overlay?.edges.has(id) === true ? overlay.edges.get(id) : this.#edges.get(id);
  }
  #node(id, overlay) {
    return overlay?.tasks.get(id) ?? this.#live.get(id) ?? this.#settled.get(id);
  }
  /** Walk up from `start`: owner tasks and conversations, ending at an ownerless root or an edge not loaded yet. */
  *#above(start, overlay) {
    let at = start;
    while (at !== void 0) {
      if ("task" in at) {
        const node = this.#node(at.task, overlay);
        if (node === void 0) {
          yield { unknown: true };
          return;
        }
        yield { task: at.task, node };
        at = parentOf(node);
      } else {
        yield { conversation: at.conversation };
        const edge = this.#edge(at.conversation, overlay);
        if (edge === void 0) {
          yield { unknown: true };
          return;
        }
        at = edge === null ? void 0 : { task: edge };
      }
    }
  }
  /** Whether every owner above `start` is loaded. */
  #chainKnown(start, overlay) {
    for (const step of this.#above(start, overlay))
      if ("unknown" in step)
        return false;
    return true;
  }
  /** Live records, with the overlay's candidates replacing committed ones; terminal candidates are gone. */
  *#liveRecords(overlay) {
    for (const record of this.#live.values()) {
      const candidate = overlay?.tasks.get(record.id) ?? record;
      if (candidate.state.status !== "terminal")
        yield candidate;
    }
    if (overlay === void 0)
      return;
    for (const record of overlay.tasks.values()) {
      if (!this.#live.has(record.id) && record.state.status !== "terminal")
        yield record;
    }
  }
  /**
   * Every task with live ordinary owned work (spec §5.5), mapped to that work: each live non-background task counts for
   * every owner task above it up to and including the first background one. Owner chains must be loaded.
   */
  #ownedLive(overlay) {
    const owned = /* @__PURE__ */ new Map();
    for (const record of this.#liveRecords(overlay)) {
      if (record.background)
        continue;
      for (const step of this.#above(parentOf(record), overlay)) {
        if ("unknown" in step)
          break;
        if (!("task" in step))
          continue;
        const below = owned.get(step.task);
        if (below === void 0)
          owned.set(step.task, [record.id]);
        else
          below.push(record.id);
        if (step.node.background)
          break;
      }
    }
    return owned;
  }
  /**
   * Whether ordinary traversal from `scope` reaches `start`: walking up reaches the scope's conversation, or an
   * ownerless one for `roots`, without crossing a background owner, unless `crossBackground`. `undefined` while an
   * edge is not loaded.
   */
  #inScope(start, scope, crossBackground = false) {
    for (const step of this.#above(start)) {
      if ("unknown" in step)
        return void 0;
      if ("conversation" in step) {
        if ("conversation" in scope && step.conversation === scope.conversation)
          return true;
      } else if (step.node.background && !crossBackground) {
        return false;
      }
    }
    return "roots" in scope;
  }
  /**
   * Whether a live owner's cancellation intent reaches `start`: walking up finds an owner with intent before a
   * background owner without it. Terminal owners never cascade (spec §5.4).
   */
  #belowCancelled(start) {
    for (const step of this.#above(start)) {
      if ("unknown" in step)
        return false;
      if (!("task" in step))
        continue;
      const live = this.#live.get(step.task);
      if (live !== void 0 && cancellationIntent(live))
        return true;
      if (step.node.background)
        return false;
    }
    return false;
  }
  /** Close listener: runs synchronously once admission is sealed, before `join()`. */
  #seal() {
    this.#closing = true;
    this.#unsubscribeRegistry();
    const error = closedError();
    this.#taskWaiters.rejectAll(error);
    this.#idleWaiters.rejectAll(error);
    for (const invocation of this.#invocations.values())
      invocation.controller.abort();
  }
  #kick() {
    this.#dirty = true;
    if (this.#draining || !this.#enabled || this.#closing)
      return;
    this.#draining = true;
    queueMicrotask(() => void this.#drain());
  }
  async #drain() {
    try {
      while (this.#dirty && this.#enabled && !this.#closing) {
        this.#dirty = false;
        for (const reservation of await this.#reserve())
          this.#start(reservation);
      }
    } catch (error) {
      if (!this.#closing)
        this.#report(error);
    } finally {
      this.#draining = false;
      if (this.#dirty)
        this.#kick();
    }
  }
  /** Reserve every eligible task in one commit; orphan abort-marked tasks no definition can take. */
  async #reserve() {
    const reservations = [];
    try {
      await this.#session.commitWith(async (tx) => {
        if (!this.#enabled || this.#closing)
          return;
        await this.#loadScopes(false);
        const owned = this.#ownedLive();
        let snapshot;
        for (const record of [...this.#live.values()]) {
          if (this.#invocations.has(record.id) || this.#waitingOn(record, owned).length > 0)
            continue;
          if (record.state.status === "completing")
            continue;
          const runnable = record;
          const mode = record.abortRequested ? "abort" : "run";
          snapshot ??= this.#registry.snapshot();
          const resolution = this.#resolve(runnable, snapshot);
          if (resolution.kind === "blocked") {
            if (mode === "abort") {
              await this.#terminate(tx, record, { status: "orphaned", reason: resolution.reason });
            }
            continue;
          }
          if (resolution.record !== runnable || record.state.status !== "running") {
            tx.setTask(withState(resolution.record, {
              status: "running",
              checkpoint: resolution.record.state.checkpoint
            }));
          }
          const invocation = this.#createInvocation(record, mode);
          reservations.push({ invocation, task: resolution.task, snapshot });
        }
      }, this.#context);
    } catch (error) {
      for (const { invocation } of reservations) {
        this.#invocations.delete(invocation.taskId);
        invocation.finish();
      }
      throw error;
    }
    return reservations;
  }
  /**
   * Live tasks a task waits for before its next invocation: its live ordinary owned work when abort-marked, since
   * abort runs bottom-up, otherwise the live part of the `on` of a wait.
   */
  #waitingOn(record, owned) {
    if (record.abortRequested)
      return owned.get(record.id) ?? [];
    if (record.state.status !== "waiting")
      return [];
    return record.state.on.filter((id) => this.#live.has(id));
  }
  /** Resolve the record's definition by kind, migrating an older stored version. */
  #resolve(record, snapshot) {
    const fit = this.#fit(record, snapshot.task(record.kind));
    if ("reason" in fit)
      return { kind: "blocked", reason: fit.reason };
    if (!fit.migrates)
      return { kind: "ready", task: fit.task, record };
    const definition = erased(fit.task);
    try {
      if (definition.migrate === void 0)
        throw missingMigration(record, definition);
      const migrated = definition.migrate(record.input, record.state.checkpoint, record.version);
      const state2 = { ...record.state, checkpoint: copyJson(migrated.checkpoint) };
      const migratedRecord = { ...record, version: definition.version, input: copyJson(migrated.input), state: state2 };
      return { kind: "ready", task: fit.task, record: migratedRecord };
    } catch (error) {
      this.#failedMigrations.set(record.id, { task: fit.task, error });
      this.#report(error);
      return { kind: "blocked", reason: "migration_failed" };
    }
  }
  #fit(record, task) {
    if (task === void 0)
      return { reason: "missing_task" };
    const version = task.definition.version;
    if (version === record.version)
      return { task, migrates: false };
    if (version < record.version)
      return { reason: "task_too_old" };
    const failed = this.#failedMigrations.get(record.id);
    if (failed?.task === task)
      return { reason: "migration_failed", error: failed.error };
    return { task, migrates: true };
  }
  /**
   * Scheduling state and every live task with its derived state, read on the Session line. Runs no task code: a
   * pending migration shows as `ready` with `migrates`, and only a migration the scheduler already tried, or one that
   * cannot exist, shows as failed.
   */
  async inspect(snapshot) {
    await this.#loadScopes(false);
    const owned = this.#ownedLive();
    const tasks = [];
    for (const record of this.#live.values()) {
      tasks.push({ record, state: this.#inspectTask(record, snapshot, owned) });
    }
    const scheduling = this.#closing ? "closing" : this.#enabled ? "running" : "paused";
    return { scheduling, tasks };
  }
  #inspectTask(record, snapshot, owned) {
    if (this.#invocations.has(record.id))
      return { kind: "running" };
    if (record.state.status === "completing")
      return { kind: "completing" };
    const on = this.#waitingOn(record, owned);
    if (on.length > 0)
      return { kind: "waiting", on };
    const fit = this.#fit(record, snapshot.task(record.kind));
    if ("reason" in fit)
      return { kind: "blocked", ...fit };
    if (fit.migrates && fit.task.definition.migrate === void 0) {
      return { kind: "blocked", reason: "migration_failed", error: missingMigration(record, erased(fit.task)) };
    }
    return { kind: "ready", migrates: fit.migrates };
  }
  #createInvocation(record, mode) {
    const controller = new AbortController();
    const { promise: done, resolve: finish } = Promise.withResolvers();
    const invocation = {
      taskId: record.id,
      conversationId: record.conversationId,
      mode,
      controller,
      context: withAbortSignal(controller.signal, this.#context),
      watches: /* @__PURE__ */ new Set(),
      ended: false,
      done,
      finish: () => finish()
    };
    this.#invocations.set(record.id, invocation);
    return invocation;
  }
  #start(reservation) {
    const invocation = reservation.invocation;
    void (async () => {
      try {
        if (invocation.mode === "run")
          await this.#run(reservation);
        else
          await this.#runAbort(reservation);
      } catch (error) {
        this.#report(error);
      } finally {
        this.#end(invocation);
        invocation.finish();
        this.#kick();
      }
    })();
  }
  /** Run phase handlers, each preceded by a step that decides on the line whether the invocation continues. */
  async #run(reservation) {
    const invocation = reservation.invocation;
    const state2 = { task: reservation.task, snapshot: reservation.snapshot, reported: void 0 };
    const phase = { snapshot: () => state2.snapshot, task: () => state2.task, agent: void 0 };
    const runtime = this.#runtime(invocation, phase);
    let previous;
    for (; ; ) {
      const current = await this.#step(invocation, (tx, current2) => this.#decide(tx, current2, previous, state2));
      if (current === void 0 || this.#closing)
        return;
      const checkpoint = current.state.checkpoint;
      phase.agent = void 0;
      try {
        await erased(state2.task).phases[checkpoint.phase](current, runtime, invocation.context);
        previous = { checkpoint };
      } catch (error) {
        previous = { checkpoint, failure: { error } };
      }
    }
  }
  /**
   * Precedence rules for a run invocation, on the line. Rules 1 (terminal, `completing`, or `waiting`) and 2 (closing)
   * are applied by `#step`. Returns whether the invocation continues with the next phase.
   */
  #decide(tx, current, previous, state2) {
    if (current.abortRequested)
      return false;
    if (previous === void 0)
      return true;
    if (previous.failure !== void 0)
      return { fault: previous.failure.error };
    if (jsonEqual(current.state.checkpoint, previous.checkpoint)) {
      const message = `Task ${current.kind} phase ${previous.checkpoint.phase} returned without durable progress`;
      return { fault: new Error(message) };
    }
    state2.snapshot = this.#registry.snapshot();
    const next = state2.snapshot.task(current.kind);
    if (next !== state2.task) {
      if (next !== void 0 && canReserve(next, current)) {
        tx.setTask(withState(current, { status: "pending", checkpoint: current.state.checkpoint }));
        return false;
      }
      if (state2.reported === void 0 || state2.reported.task !== next) {
        state2.reported = { task: next };
        const cause = next === void 0 ? "missing_task" : "incompatible_task";
        this.#report(new Error(`Task ${current.id} keeps running under its old ${current.kind} definition`, { cause }));
      }
    }
    return true;
  }
  /** Run the abort handler once; rules 1, 2, and 4 apply, and returning without an outcome faults. */
  async #runAbort(reservation) {
    const invocation = reservation.invocation;
    const current = this.#live.get(invocation.taskId);
    if (current === void 0 || this.#closing)
      return;
    let failure;
    try {
      const phase = { snapshot: () => reservation.snapshot, task: () => reservation.task, agent: void 0 };
      const runtime = this.#runtime(invocation, phase);
      await erased(reservation.task).abort(current, runtime, invocation.context);
    } catch (error) {
      failure = { error };
    }
    const message = `Abort handler of task ${invocation.taskId} returned without a terminal outcome`;
    await this.#step(invocation, () => ({ fault: failure?.error ?? new Error(message) }));
  }
  /**
   * One synchronous decision on the Session line. A task that is no longer running (rule 1: terminal, `completing`, or
   * `waiting`) or a closing Harness (rule 2) ends the invocation without a write; otherwise `decide` may stage a write
   * and returns whether the invocation continues. Ending happens inside the callback, before a fault's Harness
   * cleanup. A rejected step, such as admission after close, also ends the invocation.
   */
  async #step(invocation, decide) {
    try {
      return await this.#session.commitWith(async (tx) => {
        const found = this.#live.get(invocation.taskId);
        const current = found?.state.status === "running" ? found : void 0;
        const decision = current !== void 0 && !this.#closing ? decide(tx, current) : false;
        if (decision === true)
          return current;
        this.#end(invocation);
        if (decision !== false) {
          const message = decision.fault instanceof Error ? decision.fault.message : String(decision.fault);
          await this.#terminate(tx, current, { status: "faulted", error: { message } });
        }
        return void 0;
      }, this.#context);
    } catch (error) {
      this.#end(invocation);
      if (!this.#closing)
        this.#report(error);
      return void 0;
    }
  }
  /**
   * Write an outcome the scheduler decided. While the task's ordinary owned work is live it holds as `completing` and
   * its Harness cleanup waits for the final commit (spec §5.5, rule 4); otherwise it is terminal with its cleanup.
   */
  async #terminate(tx, record, outcome) {
    await this.#loadScopes(false);
    if (this.#ownedLive(overlayOf(tx)).has(record.id)) {
      tx.setTask(withState(record, { status: "completing", outcome }));
      return;
    }
    tx.setTask(withState(record, { status: "terminal", outcome }));
    await this.#settleOutcome(tx, record, outcome);
  }
  /**
   * Replace a running task's state with what it committed. A terminal state holds as `completing` while ordinary owned
   * work is live, judged on the commit's candidates, so work the same commit creates below the task counts. A wait is
   * validated first.
   */
  async #commitState(tx, invocation, current, next) {
    if (next.status === "waiting")
      await this.#validateWait(tx, invocation, current, next.on, next.policy);
    if (next.status === "terminal") {
      const overlay = overlayOf(tx);
      await this.#loadScopes(false);
      for (const record of overlay.tasks.values())
        await this.#loadChain(parentOf(record), overlay);
      if (this.#ownedLive(overlay).has(current.id)) {
        tx.setTask(withState(current, { status: "completing", outcome: next.outcome }));
        return;
      }
    }
    tx.setTask(withState(current, next));
  }
  /**
   * A wait names existing tasks other than the waiter and its owners, which could never finish first; `failFast` only
   * tasks the waiter owns. An abort handler cannot wait.
   */
  async #validateWait(tx, invocation, current, on, policy) {
    if (invocation.mode === "abort")
      throw new Error(`Abort handler of task ${current.id} cannot wait`);
    const overlay = overlayOf(tx);
    await this.#loadChain(parentOf(current));
    const owners = /* @__PURE__ */ new Set();
    for (const step of this.#above(parentOf(current)))
      if ("task" in step)
        owners.add(step.task);
    for (const id of on) {
      if (id === current.id || owners.has(id)) {
        throw new Error(`Task ${current.id} cannot wait on itself or its owner ${id}`);
      }
      const member = overlay.tasks.get(id) ?? this.#live.get(id) ?? await this.#storage.task(id, this.#context);
      if (member === void 0)
        throw new Error(`Task ${id} does not exist`);
      if (policy === "failFast" && member.owner !== current.id) {
        throw new Error(`Task ${current.id} can wait failFast only on tasks it owns; ${id} is not one`);
      }
    }
  }
  /** End an invocation: its runtime operations reject from now on, its signal aborts, its watches stop, and its task is free. */
  #end(invocation) {
    if (invocation.ended)
      return;
    invocation.ended = true;
    if (this.#invocations.get(invocation.taskId) === invocation)
      this.#invocations.delete(invocation.taskId);
    for (const watch of invocation.watches)
      void watch.stop();
    invocation.controller.abort(endedError(invocation));
  }
  /** No live non-background task in the scope; a task whose owner edges are not loaded yet counts as inside. */
  #idle(conversationId) {
    const scope = conversationId === void 0 ? { roots: true } : { conversation: conversationId };
    for (const record of this.#live.values()) {
      if (!record.background && this.#inScope(parentOf(record), scope) !== false)
        return false;
    }
    return true;
  }
  // ─── Invocation runtime ──────────────────────────────────────────────────
  #runtime(invocation, phase) {
    const agent = () => {
      if (invocation.ended)
        return Promise.reject(endedError(invocation));
      if (phase.agent === void 0) {
        phase.agent = this.#agent(invocation.conversationId, phase.snapshot(), invocation.context);
        phase.agent.catch(() => {
        });
      }
      return phase.agent;
    };
    const hooks = {
      each: async (name, invoke) => {
        for (const handlers of agentHooks(await agent(), phase.task().definition.name)) {
          const handler = handlers[name];
          if (typeof handler !== "function")
            continue;
          try {
            await invoke(handler.bind(handlers));
          } catch (error) {
            if (invocation.controller.signal.aborted)
              throw error;
            this.#report(error);
          }
        }
      }
    };
    const settings = this.#settings;
    return {
      taskId: invocation.taskId,
      conversationId: invocation.conversationId,
      signal: invocation.controller.signal,
      models: this.#models,
      agent: (context) => invocation.ended ? Promise.reject(endedError(invocation)) : awaitWithContext(agent(), context),
      get settings() {
        return settings();
      },
      env: (context) => this.#read(invocation, () => this.#env(invocation.conversationId, context)),
      hooks,
      get registry() {
        return phase.snapshot();
      },
      commit: (change, context) => this.#gated(invocation, async (tx, current) => {
        const next = await change(tx, current);
        if (next !== void 0)
          await this.#commitState(tx, invocation, current, next);
      }, context),
      memo: ((name, ...rest) => {
        if (rest.length === 1) {
          return this.#read(invocation, async () => memoOf(this.#live.get(invocation.taskId), name));
        }
        const candidate = rest[0];
        return this.#gated(invocation, (tx, current) => {
          const winner = memoOf(current, name);
          if (winner !== void 0)
            return winner;
          tx.setTask({ ...current, memos: { ...current.memos, [name]: candidate } });
          return candidate;
        }, rest[1]);
      }),
      sleep: (until, context) => this.#sleep(invocation, until, context),
      watchDoc: ((...args) => this.#watchDoc(invocation, args)),
      snapshot: ((...args) => this.#read(invocation, () => sessionMethod(this.#session, "snapshot")(...args))),
      snapshotAsOf: ((...args) => this.#read(invocation, () => sessionMethod(this.#session, "snapshotAsOf")(...args))),
      getTask: ((id, context) => this.#read(invocation, () => this.#session.readOnLine(() => this.#storage.task(id, context)))),
      waitForTask: ((id, context) => this.#read(invocation, () => this.waitForTask(id, withAbortSignal(invocation.controller.signal, context)))),
      outcomes: ((ids, context) => this.#read(invocation, () => this.#session.readOnLine(async () => {
        const outcomes = [];
        for (const id of ids) {
          const state2 = (await this.#storage.task(id, context))?.state;
          if (state2?.status !== "terminal")
            throw new Error(`Task ${id} is not terminal`);
          outcomes.push(state2.outcome);
        }
        return outcomes;
      }))),
      conversation: (id, context) => this.#read(invocation, () => this.#conversation(id, {
        signal: invocation.controller.signal,
        check: () => {
          if (invocation.ended)
            throw endedError(invocation);
        }
      }, context)),
      entry: ((...args) => {
        const [token, id, context] = args.length === 2 ? [void 0, args[0], args[1]] : [args[0], args[1], args[2]];
        return this.#read(invocation, async () => {
          const found = await this.#session.readOnLine(() => this.#storage.entry(invocation.conversationId, id, context));
          const entry = found?.entry;
          return token === void 0 || entry?.kind === token.kind ? entry : void 0;
        });
      }),
      context: (conversationId, context, at) => this.#read(invocation, () => readContext(this.#session, this.#storage, conversationId, context, at)),
      now: () => {
        if (invocation.ended)
          throw endedError(invocation);
        return this.#now();
      },
      report: (error) => {
        if (invocation.ended)
          throw endedError(invocation);
        this.#report(error);
      }
    };
  }
  /** Run a committed-state read unless the invocation has ended. */
  async #read(invocation, read) {
    if (invocation.ended)
      throw endedError(invocation);
    return read();
  }
  /** Commit after rereading the task on the line and gating the invocation. */
  #gated(invocation, change, context) {
    if (invocation.ended)
      return Promise.reject(endedError(invocation));
    return this.#session.commitWith(async (tx) => {
      if (invocation.ended)
        throw endedError(invocation);
      if (this.#closing)
        throw closedError();
      const found = this.#live.get(invocation.taskId);
      if (found === void 0)
        throw new Error(`Task ${invocation.taskId} is terminal`);
      if (found.state.status !== "running")
        throw new Error(`Task ${invocation.taskId} is ${found.state.status}`);
      const current = found;
      if (invocation.mode === "run" && current.abortRequested) {
        throw new Error(`Task ${invocation.taskId} has a durable abort mark`);
      }
      return change(tx, current);
    }, context, { conversationId: invocation.conversationId, taskId: invocation.taskId });
  }
  /** Wait until the Harness clock reaches `until`, rechecking it after every timer. */
  async #sleep(invocation, until, context) {
    if (invocation.ended)
      throw endedError(invocation);
    const signals = [invocation.controller.signal];
    if (context.abortSignal !== void 0)
      signals.push(context.abortSignal);
    const signal = AbortSignal.any(signals);
    for (; ; ) {
      signal.throwIfAborted();
      const remaining = until - this.#now();
      if (remaining <= 0)
        return;
      await delay(Math.min(remaining, MAX_TIMER_DELAY), signal);
    }
  }
  async #watchDoc(invocation, args) {
    if (invocation.ended)
      throw endedError(invocation);
    const watch = await sessionMethod(this.#session, "watchDoc")(...args);
    if (watch === void 0)
      return void 0;
    if (invocation.ended) {
      void watch.stop();
      throw endedError(invocation);
    }
    invocation.watches.add(watch);
    void watch.closed.then(() => invocation.watches.delete(watch));
    return watch;
  }
};
function cancellationIntent(record) {
  return record.state.status !== "terminal" && (record.abortRequested || failedOutcome(record));
}
function failedOutcome(record) {
  const state2 = record.state;
  return (state2.status === "completing" || state2.status === "terminal") && state2.outcome.status !== "completed";
}
function parentOf(node) {
  return node.owner !== void 0 ? { task: node.owner } : { conversation: node.conversationId };
}
function nodeOf(record) {
  return {
    conversationId: record.conversationId,
    ...record.owner === void 0 ? {} : { owner: record.owner },
    background: record.background
  };
}
function overlayOf(tx) {
  const tasks = new Map(tx.stagedTasks().map((record) => [record.id, record]));
  const edges = new Map(tx.stagedConversations().map((record) => [record.id, record.owner?.taskId ?? null]));
  return { tasks, edges };
}
function memoOf(record, name) {
  const memos = record?.memos;
  return memos !== void 0 && Object.hasOwn(memos, name) ? memos[name] : void 0;
}
function sessionMethod(session, name) {
  return session[name].bind(session);
}
function missingMigration(record, definition) {
  return new Error(`Task ${record.kind} version ${definition.version} has no migration from ${record.version}`);
}
function erased(task) {
  return task.definition;
}
function endedError(invocation) {
  return new Error(`Task ${invocation.taskId} invocation has ended`);
}
function withState(record, state2) {
  if (state2.status !== "terminal" && state2.status !== "completing")
    return { ...record, state: state2 };
  const { memos: _memos, ...rest } = record;
  return { ...rest, state: state2 };
}
function canReserve(task, record) {
  const definition = task.definition;
  return definition.version === record.version || definition.version > record.version && definition.migrate !== void 0;
}
function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      clearTimeout(timer);
      reject(signal.reason);
    };
    const timer = setTimeout(() => {
      signal.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal.addEventListener("abort", onAbort, { once: true });
  });
}
function jsonEqual(left, right) {
  if (left === right)
    return true;
  if (typeof left !== "object" || typeof right !== "object" || left === null || right === null)
    return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length)
      return false;
    return left.every((value, index3) => jsonEqual(value, right[index3]));
  }
  const keys = Object.keys(left);
  if (keys.length !== Object.keys(right).length)
    return false;
  return keys.every((key) => Object.hasOwn(right, key) && jsonEqual(left[key], right[key]));
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/task-graph.js
var LIVE_STATUSES2 = ["pending", "running", "waiting", "completing"];
var SCAN_PAGE_SIZE4 = 256;
var TaskGraphView = class {
  #session;
  #storage;
  #mount;
  #closed = false;
  constructor(session, storage) {
    this.#session = session;
    this.#storage = storage;
    session.subscribeCommits((publication, context) => {
      if (this.#mount !== void 0)
        advance2(this.#mount, publication, context);
    });
    session.subscribeClose(() => {
      this.#closed = true;
      for (const observer of [...this.#mount?.observers ?? []])
        observer.closeSession();
      this.#mount = void 0;
    });
  }
  /** A disposable read-only Chord state of the graph. */
  async state(context) {
    const { observer, detach } = await this.#attach((value, release) => new CommittedStateSource(value, release), context);
    try {
      return replicatedState(observer);
    } catch (error) {
      detach();
      throw error;
    }
  }
  /** A serialized exact-frame watch of the graph; cancelling `context` stops it. */
  async watch(context) {
    const { observer } = await this.#attach((value, release) => new CommittedWatch(value, release), context);
    const signal = context.abortSignal;
    if (signal?.aborted) {
      observer.cancel();
      throw signal.reason;
    }
    if (signal !== void 0)
      observer.observeCancellation(signal);
    return observer;
  }
  /** Register an observer created from the current revision, atomically on the Session line. */
  #attach(create, context) {
    return this.#session.readOnLine(async () => {
      const mount = this.#mount ?? { value: await this.#build(context), observers: /* @__PURE__ */ new Set() };
      const detach = () => {
        mount.observers.delete(observer);
        if (mount.observers.size === 0 && this.#mount === mount)
          this.#mount = void 0;
      };
      const observer = create(mount.value, detach);
      if (this.#closed)
        throw closedError();
      context.abortSignal?.throwIfAborted();
      this.#mount = mount;
      mount.observers.add(observer);
      return { observer, detach };
    });
  }
  async #build(context) {
    const tasks = {};
    const records = [];
    for (const status of LIVE_STATUSES2) {
      records.push(...await scanAll((cursor) => this.#storage.scanTasks({ status }, SCAN_PAGE_SIZE4, cursor, context)));
    }
    records.sort((a, b) => a.id - b.id);
    for (const record of records) {
      const owned = await scanAll((cursor) => this.#storage.scanConversations({ ownerTaskId: record.id }, SCAN_PAGE_SIZE4, cursor, context));
      const conversations = owned.map((conversation) => conversation.id).sort((a, b) => a - b);
      tasks[String(record.id)] = nodeOf2(record, conversations);
    }
    return { tasks };
  }
};
function advance2(mount, publication, context) {
  const ops = [];
  const changed = /* @__PURE__ */ new Map();
  const node = (key) => changed.has(key) ? changed.get(key) : mount.value.tasks[key];
  for (const change of publication.changes) {
    if (change.type !== "task")
      continue;
    const record = change.value;
    const key = String(record.id);
    const previous = node(key);
    if (record.state.status === "terminal") {
      if (previous === void 0)
        continue;
      ops.push(["d", ["tasks", key]]);
      changed.set(key, void 0);
      continue;
    }
    const next = nodeOf2(record, previous?.conversations ?? []);
    if (previous !== void 0 && JSON.stringify(next) === JSON.stringify(previous))
      continue;
    ops.push(["s", ["tasks", key], next]);
    changed.set(key, next);
  }
  const created = /* @__PURE__ */ new Map();
  for (const change of publication.changes) {
    if (change.type !== "conversation" || change.value.owner === void 0)
      continue;
    const key = String(change.value.owner.taskId);
    if (node(key) !== void 0)
      created.set(key, [...created.get(key) ?? [], change.value.id]);
  }
  for (const [key, ids] of created) {
    const conversations = [...node(key).conversations, ...ids].sort((a, b) => a - b);
    ops.push(["s", ["tasks", key, "conversations"], conversations]);
  }
  if (ops.length === 0)
    return;
  mount.value = applyImmutable(mount.value, ops);
  const frameContext = withoutAbortSignal(context);
  for (const observer of [...mount.observers])
    observer.advance(mount.value, ops, frameContext);
}
function nodeOf2(record, conversations) {
  return {
    id: record.id,
    kind: record.kind,
    conversationId: record.conversationId,
    ...record.owner === void 0 ? {} : { owner: record.owner },
    background: record.background,
    abortRequested: record.abortRequested,
    state: stateOf(record),
    conversations
  };
}
function stateOf(record) {
  const state2 = record.state;
  switch (state2.status) {
    case "pending":
    case "running":
      return { status: state2.status, phase: phaseOf(state2.checkpoint) };
    case "waiting":
      return { status: "waiting", phase: phaseOf(state2.checkpoint), on: [...state2.on], policy: state2.policy };
    // Terminal records never reach here: they leave the graph.
    case "completing":
    case "terminal":
      return { status: "completing", outcome: state2.outcome.status };
  }
}
function phaseOf(checkpoint) {
  return checkpoint.phase;
}

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/harness/harness.js
var SCAN_PAGE_SIZE5 = 256;
var ConversationImpl = class {
  id;
  #host;
  constructor(id, host) {
    this.id = id;
    this.#host = host;
  }
  agent(context) {
    return this.#host.harness.resolveAgent(this.id, void 0, context);
  }
  configure(change, context) {
    return this.#host.harness.commitWith((tx) => configure(tx, this.id, change), context);
  }
  submit(submission, context) {
    return this.#host.submissions.submit(this.id, submission, context);
  }
  compact(instructions, context) {
    this.#host.tasks.resume();
    const input = { reason: "manual", ...instructions === void 0 ? {} : { instructions } };
    return this.#host.harness.commitWith((tx) => createCompaction(tx, this.id, input), context);
  }
  async reset(handoff, context) {
    const model = handoff === void 0 ? {} : { model: [{ role: "user", content: handoff, timestamp: this.#host.now() }] };
    const entry = { kind: ResetEntry.kind, head: "self", ...model };
    await this.#host.submissions.submit(this.id, { type: "write", entry }, context);
  }
  commit(change, context) {
    return this.#host.harness.commitWith(change, context, { conversationId: this.id });
  }
  context(context) {
    return readContext(this.#host.harness, this.#host.storage, this.id, context);
  }
  entries(query, limit, cursor, context) {
    const bounded = {
      conversationId: this.id,
      ...query.minEntryId === void 0 ? {} : { minEntryId: query.minEntryId },
      ...query.maxEntryId === void 0 ? {} : { maxEntryId: query.maxEntryId }
    };
    return this.#host.harness.readOnLine(() => this.#host.storage.scanEntries(bounded, limit, cursor, context));
  }
  fork(at, options, context) {
    return this.#host.create({ kind: "fork", parentId: this.id, at, ownership: options.ownership }, options, context);
  }
  abort(context, options) {
    this.#host.tasks.resume();
    return this.#host.tasks.abortConversation(this.id, options?.background === true, context);
  }
  waitForIdle(context) {
    this.#host.tasks.resume();
    return this.#host.tasks.waitForIdle(this.id, context);
  }
  viewState(context) {
    return this.#host.views.state(this.id, context);
  }
  watch(context) {
    return this.#host.views.watch(this.id, context);
  }
};
var HarnessImpl = class extends SessionImpl {
  #storage;
  #options;
  #report;
  #host;
  #tasks;
  #submissions;
  #taskGraph;
  #closed = false;
  constructor(storage, options, context) {
    super(storage);
    this.#storage = storage;
    this.#options = options;
    this.#report = options.onReport ?? (() => {
    });
    const now = options.now ?? Date.now;
    const settings = () => resolveSettings(options.settings);
    this.#tasks = new TaskScheduler({
      session: this,
      storage,
      registry: options.registry,
      models: options.models,
      agent: (id, snapshot, callContext) => this.resolveAgent(id, snapshot, callContext),
      settings,
      env: (id, callContext) => this.buildEnv(id, callContext),
      now,
      report: this.#report,
      settleOutcome: settleSchedulerOutcome,
      withdrawInputs: withdrawQueuedInputs,
      conversation: async (id, binding, callContext) => {
        const record = await this.readOnLine(() => storage.conversation(id, callContext));
        return record === void 0 ? void 0 : boundConversation(id, binding, this.#submissions, this.#tasks);
      },
      context: withoutAbortSignal(context)
    });
    this.#submissions = new Submissions(this, storage, now, settings, () => this.#tasks.resume());
    this.#taskGraph = new TaskGraphView(this, storage);
    this.#host = {
      harness: this,
      storage,
      tasks: this.#tasks,
      submissions: this.#submissions,
      views: new ConversationViews(this, storage),
      now,
      create: (target, createOptions, context2) => this.#create(target, createOptions, context2)
    };
  }
  /** Resolve a conversation's committed `pi.agent` against `snapshot`, or the current one, and the current settings. */
  async resolveAgent(id, snapshot, context) {
    const registry = snapshot ?? this.#options.registry.snapshot();
    const state2 = await this.snapshot(AgentDoc, id, context);
    return resolveAgent(state2, registry, resolveSettings(this.#options.settings), this.#report);
  }
  /** Build a conversation's environment from its current `cwd`; `undefined` without an `env` option. */
  async buildEnv(id, context) {
    const build = this.#options.env;
    if (build === void 0)
      return void 0;
    const cwd = (await this.snapshot(AgentDoc, id, context))?.cwd;
    return build({ conversationId: id, ...cwd === void 0 ? {} : { cwd }, read: this }, context);
  }
  /** Reconcile surviving `running` tasks to `pending`; part of open. */
  openTasks(context) {
    return this.#tasks.open(context);
  }
  resume() {
    this.#assertOpen();
    this.#tasks.resume();
  }
  getTask(id, context) {
    return this.readOnLine(() => this.#storage.task(id, context));
  }
  inspect(context) {
    return this.readOnLine(async () => {
      const { scheduling, tasks } = await this.#tasks.inspect(this.#options.registry.snapshot());
      const scan = (status) => scanAll((cursor) => this.#storage.scanSubmissions({ status }, SCAN_PAGE_SIZE5, cursor, context));
      const submissions = [...await scan("queued"), ...await scan("placed")].sort((a, b) => a.id - b.id);
      return { scheduling, tasks, submissions };
    });
  }
  submission(id, context) {
    return this.#submissions.get(id, context);
  }
  abortSubmission(id, context, conversationId) {
    return this.#submissions.abort(id, context, conversationId);
  }
  abortTask(id, context) {
    return this.#tasks.abort(id, context);
  }
  waitForTask(id, context) {
    this.#tasks.resume();
    return this.#tasks.waitForTask(id, context);
  }
  waitForIdle(context) {
    this.#tasks.resume();
    return this.#tasks.waitForIdle(void 0, context);
  }
  /** Sum every conversation's committed `pi.usage`. Each document is read at its own point; totals only grow. */
  async usage(context) {
    const conversations = await this.readOnLine(() => scanAll((cursor) => this.#storage.scanConversations({}, SCAN_PAGE_SIZE5, cursor, context)));
    const total = UsageDoc.definition.initial();
    for (const { id } of conversations) {
      const state2 = await this.snapshot(UsageDoc, id, context);
      if (state2 !== void 0)
        addUsageState(total, state2);
    }
    return total;
  }
  taskGraph(context) {
    return this.#taskGraph.state(context);
  }
  watchTaskGraph(context) {
    return this.#taskGraph.watch(context);
  }
  root(context, options) {
    return this.#create({ kind: "root" }, options ?? {}, context);
  }
  async conversation(id, context) {
    this.#assertOpen();
    const record = await this.readOnLine(() => this.#storage.conversation(id, context));
    return record === void 0 ? void 0 : new ConversationImpl(record.id, this.#host);
  }
  createConversation(options, context) {
    return this.#create({ kind: "independent", ownership: options.ownership }, options, context);
  }
  close(context) {
    this.#closed = true;
    return super.close(context);
  }
  /** Join task invocations after admission is sealed and before Storage closes; writes no task outcome. */
  beforeClose() {
    return this.#tasks.join();
  }
  async #create(target, options, context) {
    this.#assertOpen();
    const id = await this.commitWith(async (tx) => {
      if (target.kind === "root" && await tx.conversation(ROOT_CONVERSATION_ID) !== void 0) {
        return ROOT_CONVERSATION_ID;
      }
      const record = target.kind === "root" ? await tx.createRootConversation() : target.kind === "fork" ? await tx.forkConversation(target.parentId, target.at, { ownership: target.ownership }) : await tx.createConversation({ ownership: target.ownership });
      if (options.agent !== void 0)
        await configure(tx, record.id, options.agent);
      if (options.init !== void 0)
        await options.init(tx, record.id);
      return record.id;
    }, context);
    return new ConversationImpl(id, this.#host);
  }
  /**
   * The built-in creation hook, in every commit that creates or forks a conversation: empty `pi.live`, `pi.inbox`, and
   * `pi.usage`, the conversation's `pi.agent` (see `createAgent()`), then `HarnessOptions.conversationCreated`.
   */
  async conversationCreated(tx, record) {
    await tx.doc(LiveDoc, record.id);
    await tx.doc(InboxDoc, record.id);
    await tx.doc(UsageDoc, record.id);
    await createAgent(tx, record);
    await this.#options.conversationCreated?.(tx, record);
  }
  #assertOpen() {
    if (this.#closed)
      throw new Error("Harness is closed");
  }
};
function boundConversation(id, binding, submissions, tasks) {
  const bind = (context) => withAbortSignal(binding.signal, context);
  const bound = (operation) => {
    return async (context) => {
      binding.check();
      return operation(bind(context));
    };
  };
  return {
    id,
    submit: async (draft, context) => {
      binding.check();
      const submission = await submissions.submit(id, draft, bind(context));
      return {
        id: submission.id,
        status: bound((callContext) => submission.status(callContext)),
        wait: bound((callContext) => submission.wait(callContext)),
        abort: bound((callContext) => submission.abort(callContext))
      };
    },
    abort: async (context, options) => {
      binding.check();
      return tasks.abortConversation(id, options?.background === true, bind(context));
    },
    waitForIdle: bound((callContext) => tasks.waitForIdle(id, callContext))
  };
}
var Harness = {
  /** Open a Harness over storage. The registry may keep changing while the Harness runs. */
  async open(storage, options, context) {
    context.abortSignal?.throwIfAborted();
    const snapshot = options.registry.snapshot();
    const missing = BUILTIN_TASKS.filter((task) => snapshot.task(task.definition.name) === void 0);
    if (missing.length > 0) {
      const names3 = missing.map((task) => task.definition.name).join(", ");
      throw new Error(`Registry lacks built-in tasks ${names3}; create it with createRegistry()`);
    }
    const harness = new HarnessImpl(storage, options, context);
    try {
      await harness.openTasks(context);
    } catch (error) {
      await harness.close(withoutAbortSignal(context)).catch((closeError) => options.onReport?.(closeError));
      throw error;
    }
    return harness;
  }
};

// ../../node_modules/.pnpm/@earendil-works+pi-durable@1.0.1_@aws-sdk+credential-provider-node@3.972.84_@modelconte_867545391487edcd36123475ad2fe1d0/node_modules/@earendil-works/pi-durable/dist/storage/memory.js
function* documentDeltaBatches(id, version, revisions, start) {
  for (let index3 = start; index3 < revisions.length; index3++) {
    const revision = revisions[index3];
    if (revision.kind !== "delta" || revision.version !== version) {
      throw new Error(`Document ${id} crosses a stored version boundary without a base`);
    }
    yield revision.ops;
  }
}
var clone = (value) => {
  if (value === null || typeof value !== "object")
    return value;
  if (Array.isArray(value))
    return value.map((item) => clone(item));
  const source = value;
  const nullPrototype = Object.getPrototypeOf(value) === null;
  const result = nullPrototype ? /* @__PURE__ */ Object.create(null) : {};
  for (const key of Object.keys(source)) {
    const copied = clone(source[key]);
    if (!nullPrototype && key in result) {
      Object.defineProperty(result, key, {
        value: copied,
        writable: true,
        enumerable: true,
        configurable: true
      });
    } else {
      result[key] = copied;
    }
  }
  return result;
};
var freeze = (value) => {
  if (value === null || typeof value !== "object" || Object.isFrozen(value))
    return value;
  for (const child of Object.values(value))
    freeze(child);
  return Object.freeze(value);
};
var cursorId = (cursor) => {
  const after = cursor?.after;
  if (after === void 0)
    return void 0;
  if (typeof after !== "number" || !Number.isSafeInteger(after))
    throw new TypeError("Invalid storage cursor");
  return idFromNumber(after);
};
var lowerBound = (ids, target) => {
  let low = 0;
  let high = ids.length;
  while (low < high) {
    const middle = low + high >>> 1;
    if (ids[middle] < target)
      low = middle + 1;
    else
      high = middle;
  }
  return low;
};
var upperBound = (ids, target) => {
  let low = 0;
  let high = ids.length;
  while (low < high) {
    const middle = low + high >>> 1;
    if (ids[middle] <= target)
      low = middle + 1;
    else
      high = middle;
  }
  return low;
};
var insertSorted = (ids, id) => {
  if (ids.length === 0 || ids[ids.length - 1] < id)
    ids.push(id);
  else
    ids.splice(lowerBound(ids, id), 0, id);
};
var removeSorted = (ids, id) => {
  const index3 = lowerBound(ids, id);
  if (ids[index3] === id)
    ids.splice(index3, 1);
};
var insertMapId = (index3, key, id) => {
  let ids = index3.get(key);
  if (ids === void 0) {
    ids = [];
    index3.set(key, ids);
  }
  insertSorted(ids, id);
};
var scopeKey = (scope) => {
  switch (scope.kind) {
    case "session":
      return JSON.stringify(["session"]);
    case "conversation":
      return JSON.stringify(["conversation", scope.conversationId]);
    case "task":
      return JSON.stringify(["task", scope.taskId]);
  }
};
var addressKey = (address) => JSON.stringify([
  address.kind,
  scopeKey(address.scope),
  address.key === void 0 ? ["singleton"] : ["family", address.key]
]);
var recordAddressKey = (record) => addressKey({ kind: record.kind, scope: record.scope, key: record.key });
var isAliveAt = (record, at) => {
  if (at === "current")
    return record.retiredAt === void 0;
  return record.createdAt <= at && (record.retiredAt === void 0 || at < record.retiredAt);
};
var isCurrentOnly = (record) => record.scope.kind !== "conversation" || record.history === "latest";
var tableContaining = (state2, id) => state2.recordTypes.get(id);
var page = (values, limit) => {
  const items = values.slice(0, limit);
  if (values.length <= limit)
    return { items: clone(items) };
  return { items: clone(items), next: { after: items.at(-1).id } };
};
var MemoryStorage = class {
  state = {
    recordTypes: /* @__PURE__ */ new Map(),
    conversations: /* @__PURE__ */ new Map(),
    conversationIds: [],
    conversationIdsByOwnerConversation: /* @__PURE__ */ new Map(),
    conversationIdsByOwnerTask: /* @__PURE__ */ new Map(),
    entries: /* @__PURE__ */ new Map(),
    entryIds: /* @__PURE__ */ new Map(),
    headEntryIds: /* @__PURE__ */ new Map(),
    entryCommitSeqs: /* @__PURE__ */ new Map(),
    tasks: /* @__PURE__ */ new Map(),
    taskIds: [],
    taskIdsByStatus: { pending: [], running: [], waiting: [], completing: [], terminal: [] },
    submissions: /* @__PURE__ */ new Map(),
    submissionIds: [],
    submissionIdsByStatus: { queued: [], placed: [], done: [], unanswered: [] },
    submissionIdsByRequest: /* @__PURE__ */ new Map(),
    documents: /* @__PURE__ */ new Map(),
    documentAddresses: /* @__PURE__ */ new Map(),
    documentIdsByScope: /* @__PURE__ */ new Map()
  };
  nextId = 2;
  nextSeq = 1;
  closed = false;
  async commit(writes, _context) {
    return this.prepareCommit(writes).apply();
  }
  /** Validate and detach one commit without changing observable state. */
  prepareCommit(writes, seq = seqFromNumber(this.nextSeq)) {
    this.assertOpen();
    if (!Number.isSafeInteger(seq) || seq < this.nextSeq) {
      throw new Error(`Commit sequence ${seq} does not strictly increase`);
    }
    const detachedWrites = freeze(this.resolveDocumentCopies(writes.map((write) => clone(write))));
    this.checkGlobalIds(detachedWrites);
    const documentActions = this.prepareDocumentActions(detachedWrites);
    this.checkDocumentActions(documentActions);
    let applied = false;
    return {
      seq,
      writes: detachedWrites,
      apply: () => {
        if (!applied) {
          applied = true;
          this.applyPreparedCommit(detachedWrites, documentActions, seq);
        }
        return seq;
      }
    };
  }
  resolveDocumentCopies(writes) {
    if (!writes.some((write) => write.type === "document.copy"))
      return writes;
    const changedDocumentIds = /* @__PURE__ */ new Set();
    for (const write of writes) {
      if (write.type === "document.create" || write.type === "document.copy") {
        changedDocumentIds.add(write.record.id);
      } else if (write.type === "document.change" || write.type === "document.retire") {
        changedDocumentIds.add(write.id);
      }
    }
    return writes.map((write) => {
      if (write.type !== "document.copy")
        return write;
      try {
        if (changedDocumentIds.has(write.source.id)) {
          throw new Error(`Fork source document ${write.source.id} is changed in the copy batch`);
        }
        const stored = this.materializeDocument(write.source.id, write.source.at);
        if (stored === void 0)
          throw new Error(`Fork source document ${write.source.id} cannot be read`);
        if (stored.record.scope.kind !== "conversation" || write.record.scope.kind !== "conversation" || stored.record.kind !== write.record.kind || stored.record.key !== write.record.key || stored.record.history !== write.record.history || stored.record.fork !== write.record.fork) {
          throw new Error(`Fork source document ${write.source.id} does not match the copied record`);
        }
        return {
          type: "document.create",
          record: write.record,
          content: { kind: "base", version: stored.version, value: stored.value }
        };
      } catch (error) {
        if (error instanceof StorageRejected)
          throw error;
        throw new StorageRejected(`Document copy ${write.record.id} was rejected`, { cause: error });
      }
    });
  }
  applyPreparedCommit(prepared, documentActions, seq) {
    for (const write of prepared) {
      switch (write.type) {
        case "conversation": {
          this.state.recordTypes.set(write.value.id, "conversation");
          this.state.conversations.set(write.value.id, write.value);
          insertSorted(this.state.conversationIds, write.value.id);
          const owner = write.value.owner;
          if (owner !== void 0) {
            insertMapId(this.state.conversationIdsByOwnerConversation, owner.conversationId, write.value.id);
            insertMapId(this.state.conversationIdsByOwnerTask, owner.taskId, write.value.id);
          }
          this.nextId = Math.max(this.nextId, write.value.id + 1);
          break;
        }
        case "entry": {
          this.state.recordTypes.set(write.value.id, "entry");
          this.state.entries.set(write.value.id, write.value);
          this.state.entryCommitSeqs.set(write.value.id, seq);
          let ids = this.state.entryIds.get(write.value.conversationId);
          if (ids === void 0) {
            ids = [];
            this.state.entryIds.set(write.value.conversationId, ids);
          }
          insertSorted(ids, write.value.id);
          if (write.value.head !== void 0) {
            let headIds = this.state.headEntryIds.get(write.value.conversationId);
            if (headIds === void 0) {
              headIds = [];
              this.state.headEntryIds.set(write.value.conversationId, headIds);
            }
            insertSorted(headIds, write.value.id);
          }
          this.nextId = Math.max(this.nextId, write.value.id + 1);
          break;
        }
        case "task": {
          this.state.recordTypes.set(write.value.id, "task");
          const previous = this.state.tasks.get(write.value.id);
          if (previous === void 0) {
            insertSorted(this.state.taskIds, write.value.id);
            insertSorted(this.state.taskIdsByStatus[write.value.state.status], write.value.id);
          } else if (previous.state.status !== write.value.state.status) {
            removeSorted(this.state.taskIdsByStatus[previous.state.status], write.value.id);
            insertSorted(this.state.taskIdsByStatus[write.value.state.status], write.value.id);
          }
          this.state.tasks.set(write.value.id, write.value);
          this.nextId = Math.max(this.nextId, write.value.id + 1);
          break;
        }
        case "submission": {
          this.state.recordTypes.set(write.value.id, "submission");
          const previous = this.state.submissions.get(write.value.id);
          if (previous === void 0) {
            insertSorted(this.state.submissionIds, write.value.id);
            insertSorted(this.state.submissionIdsByStatus[write.value.status], write.value.id);
          } else if (previous.status !== write.value.status) {
            removeSorted(this.state.submissionIdsByStatus[previous.status], write.value.id);
            insertSorted(this.state.submissionIdsByStatus[write.value.status], write.value.id);
          }
          if (previous?.requestId !== void 0) {
            const previousRequests = this.state.submissionIdsByRequest.get(previous.conversationId);
            if (previousRequests?.get(previous.requestId) === write.value.id) {
              previousRequests.delete(previous.requestId);
              if (previousRequests.size === 0)
                this.state.submissionIdsByRequest.delete(previous.conversationId);
            }
          }
          this.state.submissions.set(write.value.id, write.value);
          if (write.value.requestId !== void 0) {
            let requests = this.state.submissionIdsByRequest.get(write.value.conversationId);
            if (requests === void 0) {
              requests = /* @__PURE__ */ new Map();
              this.state.submissionIdsByRequest.set(write.value.conversationId, requests);
            }
            requests.set(write.value.requestId, write.value.id);
          }
          this.nextId = Math.max(this.nextId, write.value.id + 1);
          break;
        }
        case "document.copy":
          throw new Error("Prepared document copy was not resolved");
        case "document.create":
        case "document.change":
        case "document.retire":
          break;
      }
    }
    this.applyDocumentActions(documentActions, seq);
    this.nextSeq = seq + 1;
    return seq;
  }
  async mintId() {
    this.assertOpen();
    if (!Number.isSafeInteger(this.nextId))
      throw new Error("ID space is exhausted");
    return idFromNumber(this.nextId++);
  }
  async conversation(id, _context) {
    this.assertOpen();
    const value = this.state.conversations.get(id);
    return value === void 0 ? void 0 : clone(value);
  }
  async scanConversations(query, limit, cursor, _context) {
    this.assertOpen();
    const ids = query.ownerTaskId !== void 0 ? this.state.conversationIdsByOwnerTask.get(query.ownerTaskId) ?? [] : query.ownerConversationId !== void 0 ? this.state.conversationIdsByOwnerConversation.get(query.ownerConversationId) ?? [] : this.state.conversationIds;
    const after = cursorId(cursor);
    const start = after === void 0 ? 0 : upperBound(ids, after);
    const values = [];
    for (let index3 = start; index3 < ids.length && values.length <= limit; index3++) {
      const value = this.state.conversations.get(ids[index3]);
      if (query.ownerConversationId !== void 0 && value.owner?.conversationId !== query.ownerConversationId) {
        continue;
      }
      values.push(value);
    }
    return page(values, limit);
  }
  async entry(idOrConversationId, idOrContext, context) {
    this.assertOpen();
    if (context === void 0) {
      const id2 = idFromNumber(idOrConversationId);
      const entry2 = this.state.entries.get(id2);
      if (entry2 === void 0)
        return void 0;
      return { entry: clone(entry2), commitSeq: this.state.entryCommitSeqs.get(id2) };
    }
    if (typeof idOrContext !== "number")
      throw new TypeError("Storage.entry() requires an entry ID");
    const conversationId = idFromNumber(idOrConversationId);
    const id = idFromNumber(idOrContext);
    const entry = this.visibleEntries(conversationId, id, id).next().value;
    if (entry === void 0)
      return void 0;
    return { entry: clone(entry), commitSeq: this.state.entryCommitSeqs.get(id) };
  }
  async findLatestHeadMarker(conversationId, atOrBeforeEntryId, _context) {
    this.assertOpen();
    if (!this.state.conversations.has(conversationId)) {
      throw new Error(`Unknown conversation: ${conversationId}`);
    }
    let currentId = conversationId;
    let upperEntryId = atOrBeforeEntryId ?? Number.POSITIVE_INFINITY;
    while (true) {
      const ids = this.state.headEntryIds.get(currentId) ?? [];
      const index3 = upperBound(ids, upperEntryId) - 1;
      if (index3 >= 0) {
        const entry = this.state.entries.get(ids[index3]);
        return clone({ ...entry, head: entry.head });
      }
      const conversation = this.state.conversations.get(currentId);
      if (conversation.parent === void 0)
        return void 0;
      upperEntryId = Math.min(upperEntryId, conversation.parent.at);
      currentId = conversation.parent.conversationId;
    }
  }
  async scanEntries(query, limit, cursor, _context) {
    this.assertOpen();
    const after = cursorId(cursor);
    const maxEntryId = after === void 0 ? query.maxEntryId : Math.min(query.maxEntryId ?? Number.POSITIVE_INFINITY, after - 1);
    const visible = [];
    for (const entry of this.visibleEntries(query.conversationId, query.minEntryId, maxEntryId)) {
      visible.push(entry);
      if (visible.length > limit)
        break;
    }
    return page(visible, limit);
  }
  async task(id, _context) {
    this.assertOpen();
    const value = this.state.tasks.get(id);
    return value === void 0 ? void 0 : clone(value);
  }
  async scanTasks(query, limit, cursor, _context) {
    this.assertOpen();
    const after = cursorId(cursor);
    const ids = query.status === void 0 ? this.state.taskIds : this.state.taskIdsByStatus[query.status];
    const start = after === void 0 ? 0 : upperBound(ids, after);
    const values = [];
    for (let index3 = start; index3 < ids.length && values.length <= limit; index3++) {
      const value = this.state.tasks.get(ids[index3]);
      if (query.conversationId !== void 0 && value.conversationId !== query.conversationId)
        continue;
      if (query.kind !== void 0 && value.kind !== query.kind)
        continue;
      if (query.abortRequested !== void 0 && value.abortRequested !== query.abortRequested)
        continue;
      if (query.background !== void 0 && value.background !== query.background)
        continue;
      values.push(value);
    }
    return page(values, limit);
  }
  async submission(id, _context) {
    this.assertOpen();
    const value = this.state.submissions.get(id);
    return value === void 0 ? void 0 : clone(value);
  }
  async scanSubmissions(query, limit, cursor, _context) {
    this.assertOpen();
    const after = cursorId(cursor);
    const ids = query.status === void 0 ? this.state.submissionIds : this.state.submissionIdsByStatus[query.status];
    const start = after === void 0 ? 0 : upperBound(ids, after);
    const values = [];
    for (let index3 = start; index3 < ids.length && values.length <= limit; index3++) {
      const value = this.state.submissions.get(ids[index3]);
      if (query.conversationId !== void 0 && value.conversationId !== query.conversationId)
        continue;
      values.push(value);
    }
    return page(values, limit);
  }
  async submissionByRequest(conversationId, requestId, _context) {
    this.assertOpen();
    const id = this.state.submissionIdsByRequest.get(conversationId)?.get(requestId);
    if (id === void 0)
      return void 0;
    return clone(this.state.submissions.get(id));
  }
  async findDocument(address, at, _context) {
    this.assertOpen();
    const index3 = this.state.documentAddresses.get(addressKey(address));
    if (at === "current") {
      return index3?.currentId === void 0 ? void 0 : clone(this.state.documents.get(index3.currentId).record);
    }
    for (const id of index3?.ids ?? []) {
      const record = this.state.documents.get(id).record;
      if (isAliveAt(record, at))
        return clone(record);
    }
    return void 0;
  }
  async document(id, at, _context) {
    this.assertOpen();
    const stored = this.materializeDocument(id, at);
    return stored === void 0 ? void 0 : {
      record: clone(stored.record),
      version: stored.version,
      value: clone(stored.value),
      deltasSinceBase: stored.deltasSinceBase
    };
  }
  async scanDocuments(query, limit, cursor, _context) {
    this.assertOpen();
    const ids = this.state.documentIdsByScope.get(scopeKey(query.scope)) ?? [];
    const after = cursorId(cursor);
    const start = after === void 0 ? 0 : upperBound(ids, after);
    const values = [];
    for (let index3 = start; index3 < ids.length && values.length <= limit; index3++) {
      const record = this.state.documents.get(ids[index3]).record;
      if (query.kind !== void 0 && record.kind !== query.kind)
        continue;
      if (isAliveAt(record, query.at))
        values.push(record);
    }
    return page(values, limit);
  }
  async close(_context) {
    this.closed = true;
  }
  materializeDocument(id, at) {
    const stored = this.state.documents.get(id);
    if (stored === void 0)
      return void 0;
    if (at !== "current" && isCurrentOnly(stored.record)) {
      throw new Error(`Document ${id} does not retain historical content`);
    }
    if (!isAliveAt(stored.record, at))
      return void 0;
    const revisions = at === "current" ? stored.revisions : stored.revisions.filter((revision) => revision.seq <= at);
    let baseIndex = revisions.length - 1;
    while (baseIndex >= 0 && revisions[baseIndex].kind !== "base")
      baseIndex--;
    const base = revisions[baseIndex];
    if (base?.kind !== "base")
      throw new Error(`Document ${id} is missing a required base`);
    const value = applyImmutableBatches(base.value, documentDeltaBatches(id, base.version, revisions, baseIndex + 1));
    return { record: stored.record, version: base.version, value, deltasSinceBase: revisions.length - baseIndex - 1 };
  }
  *visibleEntries(conversationId, minEntryId = Number.NEGATIVE_INFINITY, maxEntryId = Number.POSITIVE_INFINITY) {
    if (!this.state.conversations.has(conversationId)) {
      throw new Error(`Unknown conversation: ${conversationId}`);
    }
    let currentId = conversationId;
    let upperEntryId = maxEntryId;
    while (true) {
      const ids = this.state.entryIds.get(currentId) ?? [];
      for (let index3 = upperBound(ids, upperEntryId) - 1; index3 >= 0; index3--) {
        const id = ids[index3];
        if (id < minEntryId)
          break;
        yield this.state.entries.get(id);
      }
      const conversation = this.state.conversations.get(currentId);
      if (conversation.parent === void 0)
        break;
      upperEntryId = Math.min(upperEntryId, conversation.parent.at);
      if (upperEntryId < minEntryId)
        break;
      currentId = conversation.parent.conversationId;
    }
  }
  checkGlobalIds(writes) {
    const claimed = /* @__PURE__ */ new Map();
    for (const write of writes) {
      if (write.type === "document.change" || write.type === "document.retire")
        continue;
      const document = write.type === "document.create" || write.type === "document.copy";
      const table = document ? "document" : write.type;
      const id = document ? write.record.id : write.value.id;
      const existing = tableContaining(this.state, id);
      const earlier = claimed.get(id);
      if (table === "conversation" || table === "entry" || table === "document") {
        if (existing !== void 0)
          throw new Error(`ID ${id} already belongs to ${existing}`);
        if (earlier !== void 0)
          throw new Error(`ID ${id} is written more than once`);
      } else {
        if (existing !== void 0 && existing !== table) {
          throw new Error(`ID ${id} already belongs to ${existing}`);
        }
        if (earlier !== void 0 && earlier !== table)
          throw new Error(`ID ${id} is written as two record types`);
      }
      claimed.set(id, table);
    }
  }
  prepareDocumentActions(writes) {
    const actions = /* @__PURE__ */ new Map();
    for (const write of writes) {
      if (write.type !== "document.create" && write.type !== "document.change" && write.type !== "document.retire") {
        continue;
      }
      const id = write.type === "document.create" ? write.record.id : write.id;
      let action = actions.get(id);
      if (action === void 0) {
        action = { retire: false };
        actions.set(id, action);
      }
      switch (write.type) {
        case "document.create":
          if (action.create !== void 0 || action.content !== void 0) {
            throw new Error(`Document ${id} has more than one content command`);
          }
          action.create = write.record;
          action.content = write.content;
          break;
        case "document.change":
          if (action.content !== void 0)
            throw new Error(`Document ${id} has more than one content command`);
          action.content = write.content;
          break;
        case "document.retire":
          if (action.retire)
            throw new Error(`Document ${id} is retired more than once`);
          action.retire = true;
          break;
      }
    }
    return actions;
  }
  checkDocumentActions(actions) {
    const liveCounts = /* @__PURE__ */ new Map();
    for (const [id, action] of actions) {
      const existing = this.state.documents.get(id);
      if (action.create === void 0 && existing === void 0)
        throw new Error(`Unknown document: ${id}`);
      if (action.create !== void 0 && existing !== void 0)
        throw new Error(`Document ${id} already exists`);
      if (existing?.record.retiredAt !== void 0)
        throw new Error(`Document ${id} is retired`);
      const previous = existing?.revisions.at(-1);
      if (action.content?.kind === "delta") {
        if (previous === void 0)
          throw new Error(`Document ${id} delta has no base`);
        if (previous.version !== action.content.version) {
          throw new Error(`Document ${id} version transition requires a base`);
        }
      }
      const key = action.create === void 0 ? recordAddressKey(existing.record) : recordAddressKey(action.create);
      const currentId = this.state.documentAddresses.get(key)?.currentId;
      let live = liveCounts.get(key);
      if (live === void 0)
        live = currentId === void 0 ? 0 : 1;
      if (action.retire && currentId === id)
        live--;
      if (action.create !== void 0 && !action.retire)
        live++;
      liveCounts.set(key, live);
    }
    for (const live of liveCounts.values()) {
      if (live > 1)
        throw new Error(`Document address already has a current incarnation`);
    }
  }
  applyDocumentActions(actions, seq) {
    for (const [id, action] of actions) {
      let stored = this.state.documents.get(id);
      if (action.create !== void 0) {
        const record = {
          ...action.create,
          createdAt: seq,
          ...action.retire ? { retiredAt: seq } : {}
        };
        stored = { record, revisions: [{ ...action.content, seq }] };
        this.state.recordTypes.set(id, "document");
        this.state.documents.set(id, stored);
        const key = recordAddressKey(record);
        let address = this.state.documentAddresses.get(key);
        if (address === void 0) {
          address = { ids: [] };
          this.state.documentAddresses.set(key, address);
        }
        insertSorted(address.ids, id);
        let scopeIds = this.state.documentIdsByScope.get(scopeKey(record.scope));
        if (scopeIds === void 0) {
          scopeIds = [];
          this.state.documentIdsByScope.set(scopeKey(record.scope), scopeIds);
        }
        insertSorted(scopeIds, id);
        this.nextId = Math.max(this.nextId, id + 1);
      } else if (action.content !== void 0) {
        const revision = { ...action.content, seq };
        if (revision.kind === "base" && isCurrentOnly(stored.record))
          stored.revisions = [revision];
        else
          stored.revisions.push(revision);
      }
      if (action.retire && action.create === void 0)
        stored.record = { ...stored.record, retiredAt: seq };
      if (action.retire && isCurrentOnly(stored.record))
        stored.revisions = [];
      if (action.create !== void 0 || action.retire) {
        const address = this.state.documentAddresses.get(recordAddressKey(stored.record));
        if (action.retire && address.currentId === id)
          delete address.currentId;
        if (action.create !== void 0 && !action.retire)
          address.currentId = id;
      }
    }
  }
  assertOpen() {
    if (this.closed)
      throw new Error("MemoryStorage is closed");
  }
};
export {
  AgentDoc,
  AssistantEntry,
  CompactionEntry,
  CompactionTask,
  ConversationBusy,
  DEFAULT_COMPACTION_POLICY,
  DEFAULT_RETRY_POLICY,
  GenerationTask,
  Harness,
  InboxDoc,
  LiveDoc,
  MemoryStorage,
  ROOT_CONVERSATION_ID,
  ReadAfterWrite,
  ResetEntry,
  StorageRejected,
  SystemEntry,
  ToolResultEntry,
  ToolTask,
  UsageDoc,
  UserEntry,
  configure,
  createRegistry,
  createSession,
  defineDoc,
  defineDocFamily,
  defineEntry,
  defineExtension,
  defineTask,
  defineTool,
  hook,
  section,
  watchEvents,
  wrapSection,
  wrapTool
};
//# sourceMappingURL=@earendil-works_pi-durable.js.map
