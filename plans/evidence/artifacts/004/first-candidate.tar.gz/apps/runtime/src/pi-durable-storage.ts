import type { Context, JsonValue } from "@earendil-works/chord";
import { apply, type Op } from "@earendil-works/chord/delta";
import {
	type ConversationId,
	type ConversationQuery,
	type ConversationRecord,
	type Cursor,
	type DocumentAddress,
	type DocumentContent,
	type DocumentCopySource,
	type DocumentId,
	type DocumentPoint,
	type DocumentQuery,
	type DocumentRecord,
	type EntryId,
	type EntryQuery,
	type EntryRecord,
	type Id,
	type Page,
	type Seq,
	type Storage,
	StorageRejected,
	type StorageWrite,
	type StoredDocument,
	type SubmissionId,
	type SubmissionQuery,
	type SubmissionRecord,
	type TaskId,
	type TaskQuery,
	type TaskRecord,
} from "@earendil-works/pi-durable";
import type { RetainedStorageBinding } from "./host-private.ts";
import {
	decryptRuntimePayload,
	encryptRuntimePayload,
	parseRuntimeCiphertextV1,
	parseRuntimeManifest,
	RUNTIME_CRYPTO_FORMAT_VERSION,
	serializeRuntimeCiphertext,
	serializeRuntimeManifest,
} from "./runtime-crypto.ts";

export type { RetainedStorageBinding } from "./host-private.ts";

export const ENCRYPTED_STORAGE_FORMAT = 1;
export const ENGINE_COMPAT = "pi-durable-1.0.1";
export const TASK_COMPAT = "pi-task-v1";
export const TOOL_COMPAT = "pi-tool-v1";
export const PROVIDER_COMPAT = "provider-request-v1";
export const ADAPTER_COMPAT = "ditto-encrypted-storage-1";

export class EncryptedStorageError extends Error {
	constructor(
		readonly code:
			| "incompatible"
			| "plaintext_retained"
			| "integrity"
			| "unresolved_external_ref"
			| "closed"
			| "expired_transaction",
		message: string,
	) {
		super(message);
		this.name = "EncryptedStorageError";
	}
}

type Sql = string | number | null;
type Row = Record<string, SqlStorageValue>;
type StoredTask = TaskRecord<JsonValue, JsonValue, JsonValue>;
type Query = {
	exec(sql: string, ...params: Sql[]): void;
	get(sql: string, ...params: Sql[]): Row | undefined;
	all(sql: string, ...params: Sql[]): Row[];
};

type DocumentCreate = Extract<
	StorageWrite,
	{ type: "document.create" }
>["record"];
type DocumentAction = {
	retire: boolean;
	create?: DocumentCreate;
	content?: DocumentContent;
	copy?: DocumentCopySource;
};

const SCHEMA = [
	`CREATE TABLE durable_metadata (
		singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
		next_id TEXT NOT NULL,
		next_seq INTEGER NOT NULL
	) STRICT`,
	`INSERT INTO durable_metadata (singleton, next_id, next_seq) VALUES (1, '2', 1)`,
	`CREATE TABLE record_ids (
		id INTEGER PRIMARY KEY,
		record_type TEXT NOT NULL CHECK (record_type IN ('conversation', 'entry', 'task', 'submission', 'document'))
	) STRICT`,
	`CREATE TABLE conversations (
		id INTEGER PRIMARY KEY,
		owner_conversation_id INTEGER,
		owner_task_id INTEGER,
		record TEXT NOT NULL CHECK (json_valid(record))
	) STRICT`,
	"CREATE INDEX conversations_by_owner_conversation ON conversations (owner_conversation_id, id)",
	"CREATE INDEX conversations_by_owner_task ON conversations (owner_task_id, id)",
	`CREATE TABLE entries (
		id INTEGER PRIMARY KEY,
		conversation_id INTEGER NOT NULL,
		head INTEGER,
		commit_seq INTEGER NOT NULL,
		record TEXT NOT NULL CHECK (json_valid(record))
	) STRICT`,
	"CREATE INDEX entries_by_conversation ON entries (conversation_id, id DESC)",
	"CREATE INDEX entry_heads_by_conversation ON entries (conversation_id, id DESC) WHERE head IS NOT NULL",
	`CREATE TABLE tasks (
		id INTEGER PRIMARY KEY,
		conversation_id INTEGER NOT NULL,
		kind TEXT NOT NULL,
		status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'waiting', 'completing', 'terminal')),
		abort_requested INTEGER NOT NULL CHECK (abort_requested IN (0, 1)),
		background INTEGER NOT NULL CHECK (background IN (0, 1)),
		record TEXT NOT NULL CHECK (json_valid(record))
	) STRICT`,
	"CREATE INDEX tasks_by_status ON tasks (status, id)",
	"CREATE INDEX tasks_by_conversation ON tasks (conversation_id, id)",
	"CREATE INDEX tasks_by_kind ON tasks (kind, id)",
	"CREATE INDEX tasks_by_abort_requested ON tasks (abort_requested, id)",
	"CREATE INDEX tasks_by_background ON tasks (background, id)",
	`CREATE TABLE submissions (
		id INTEGER PRIMARY KEY,
		conversation_id INTEGER NOT NULL,
		request_id TEXT,
		status TEXT NOT NULL CHECK (status IN ('queued', 'placed', 'done', 'unanswered')),
		record TEXT NOT NULL CHECK (json_valid(record))
	) STRICT`,
	"CREATE INDEX submissions_by_request ON submissions (conversation_id, request_id)",
	"CREATE INDEX submissions_by_conversation ON submissions (conversation_id, id)",
	"CREATE INDEX submissions_by_status ON submissions (status, id)",
	`CREATE TABLE documents (
		id INTEGER PRIMARY KEY,
		kind TEXT NOT NULL,
		family INTEGER NOT NULL CHECK (family IN (0, 1)),
		key_value TEXT NOT NULL,
		scope_kind TEXT NOT NULL CHECK (scope_kind IN ('session', 'conversation', 'task')),
		owner_id INTEGER NOT NULL,
		created_at INTEGER NOT NULL,
		retired_at INTEGER,
		record TEXT NOT NULL CHECK (json_valid(record))
	) STRICT`,
	`CREATE INDEX documents_by_address
		ON documents (kind, scope_kind, owner_id, family, key_value, created_at DESC, retired_at)`,
	"CREATE INDEX documents_by_scope ON documents (scope_kind, owner_id, id)",
	"CREATE INDEX documents_by_scope_kind ON documents (scope_kind, owner_id, kind, id)",
	`CREATE TABLE document_revisions (
		document_id INTEGER NOT NULL,
		seq INTEGER NOT NULL,
		kind TEXT NOT NULL CHECK (kind IN ('base', 'delta')),
		version INTEGER NOT NULL,
		content TEXT NOT NULL CHECK (json_valid(content)),
		PRIMARY KEY (document_id, seq)
	) STRICT`,
	"CREATE INDEX document_revisions_by_kind ON document_revisions (document_id, kind, seq DESC)",
	`CREATE TABLE ditto_storage_meta (
		singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
		format_version INTEGER NOT NULL,
		engine_compat TEXT NOT NULL,
		task_compat TEXT NOT NULL,
		tool_compat TEXT NOT NULL,
		provider_compat TEXT NOT NULL,
		adapter_compat TEXT NOT NULL
	) STRICT`,
	`INSERT INTO ditto_storage_meta (
		singleton, format_version, engine_compat, task_compat, tool_compat, provider_compat, adapter_compat
	) VALUES (1, ${ENCRYPTED_STORAGE_FORMAT}, '${ENGINE_COMPAT}', '${TASK_COMPAT}', '${TOOL_COMPAT}', '${PROVIDER_COMPAT}', '${ADAPTER_COMPAT}')`,
	`CREATE TABLE durable_schema (
		singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
		version INTEGER NOT NULL CHECK (version >= 0)
	) STRICT`,
	"INSERT INTO durable_schema (singleton, version) VALUES (1, 1)",
];

function idFromNumber<I extends Id<string>>(value: number): I {
	return value as I;
}

function seqFromNumber(value: number): Seq {
	return value as Seq;
}

function encodeJson(value: unknown): string {
	return JSON.stringify(value);
}

function encodeIndexedString(value: string): string {
	return JSON.stringify(value);
}

function cursorId(cursor: Cursor | undefined): number | undefined {
	const after = cursor?.after;
	if (after === undefined) return undefined;
	if (typeof after !== "number" || !Number.isSafeInteger(after))
		throw new TypeError("Invalid storage cursor");
	return after;
}

function page<T extends { id: number }>(
	values: T[],
	limit: number,
): Page<T, Cursor> {
	const items = values.slice(0, limit);
	if (values.length <= limit) return { items };
	const last = items.at(-1);
	if (!last) return { items };
	return { items, next: { after: last.id } };
}

function text(row: Row, key: string): string {
	const value = row[key];
	if (typeof value !== "string")
		throw new EncryptedStorageError("integrity", "Invalid storage row");
	return value;
}

function integer(row: Row, key: string): number {
	const value = row[key];
	if (typeof value !== "number" || !Number.isSafeInteger(value))
		throw new EncryptedStorageError("integrity", "Invalid storage row");
	return value;
}

function scopeColumns(scope: DocumentRecord["scope"]): {
	scopeKind: string;
	ownerId: number;
} {
	switch (scope.kind) {
		case "session":
			return { scopeKind: "session", ownerId: 0 };
		case "conversation":
			return { scopeKind: "conversation", ownerId: scope.conversationId };
		case "task":
			return { scopeKind: "task", ownerId: scope.taskId };
	}
}

function addressParts(address: {
	kind: string;
	scope: DocumentRecord["scope"];
	key?: string;
}) {
	const scope = scopeColumns(address.scope);
	return {
		kind: encodeIndexedString(address.kind),
		...scope,
		family: address.key === undefined ? 0 : 1,
		keyValue: encodeIndexedString(address.key ?? ""),
	};
}

function addressKey(address: {
	kind: string;
	scope: DocumentRecord["scope"];
	key?: string;
}): string {
	const parts = addressParts(address);
	return JSON.stringify([
		parts.kind,
		parts.scopeKind,
		parts.ownerId,
		parts.family,
		parts.keyValue,
	]);
}

function isAliveAt(record: DocumentRecord, at: DocumentPoint): boolean {
	if (at === "current") return record.retiredAt === undefined;
	return (
		record.createdAt <= at &&
		(record.retiredAt === undefined || at < record.retiredAt)
	);
}

function isCurrentOnly(record: DocumentRecord): boolean {
	return record.scope.kind !== "conversation" || record.history === "latest";
}

function writeId(write: StorageWrite): number | undefined {
	switch (write.type) {
		case "conversation":
		case "entry":
		case "task":
		case "submission":
			return write.value.id;
		case "document.create":
		case "document.copy":
			return write.record.id;
		case "document.change":
		case "document.retire":
			return undefined;
	}
}

function isExternalRef(value: unknown): boolean {
	return (
		typeof value === "object" &&
		value !== null &&
		!Array.isArray(value) &&
		"kind" in value &&
		value.kind === "external"
	);
}

export async function runRetainedTransaction<T>(
	storage: DurableObjectStorage,
	callback: (tx: Query) => Promise<T>,
): Promise<T> {
	let active = true;
	const tx = query(storage, () => active);
	try {
		return await storage.transaction(async () => callback(tx));
	} finally {
		active = false;
	}
}

function query(storage: DurableObjectStorage, isActive: () => boolean): Query {
	function guard() {
		if (!isActive())
			throw new EncryptedStorageError(
				"expired_transaction",
				"Expired storage transaction",
			);
	}
	return {
		exec(sql, ...params) {
			guard();
			storage.sql.exec(sql, ...params);
		},
		get(sql, ...params) {
			guard();
			return storage.sql.exec<Row>(sql, ...params).toArray()[0];
		},
		all(sql, ...params) {
			guard();
			return storage.sql.exec<Row>(sql, ...params).toArray();
		},
	};
}

export type EncryptedStorageOpenOptions = {
	inlineMaxBytes?: number;
	chunkBytes?: number;
};

/** Public Pi Storage over DO SQLite. Private record and revision bodies are encrypted before SQL. */
export class EncryptedPiStorage implements Storage {
	private closed = false;
	private closing: Promise<void> | undefined;
	private admittedReads = 0;
	private readsDrained: (() => void) | undefined;

	private constructor(
		private readonly storage: DurableObjectStorage,
		private readonly binding: RetainedStorageBinding,
		private nextId: number,
		private readonly options: EncryptedStorageOpenOptions,
	) {}

	static async open(
		storage: DurableObjectStorage,
		binding: RetainedStorageBinding,
		options: EncryptedStorageOpenOptions = {},
	): Promise<EncryptedPiStorage> {
		await ensureSchema(storage);
		const direct = query(storage, () => true);
		const metadata = direct.get(
			"SELECT next_id, next_seq FROM durable_metadata WHERE singleton = 1",
		);
		if (metadata === undefined)
			throw new EncryptedStorageError(
				"integrity",
				"Durable SQLite metadata is missing",
			);
		const opened = new EncryptedPiStorage(
			storage,
			binding,
			Number(text(metadata, "next_id")),
			options,
		);
		await opened.verifyAll();
		return opened;
	}

	async commit(
		writes: readonly StorageWrite[],
		_context: Context,
	): Promise<Seq> {
		this.assertOpen();
		const documentActions = this.prepareDocumentActions(writes);
		const candidateNextId = this.candidateNextId(writes);
		const seq = await runRetainedTransaction(
			this.storage,
			async (transaction) => {
				const metadata = transaction.get(
					"SELECT next_id, next_seq FROM durable_metadata WHERE singleton = 1",
				);
				if (metadata === undefined)
					throw new EncryptedStorageError(
						"integrity",
						"Durable SQLite metadata is missing",
					);
				const committedSeq = seqFromNumber(integer(metadata, "next_seq"));
				await this.checkGlobalIds(transaction, writes);
				await this.checkDocumentActions(transaction, documentActions);
				for (const write of writes)
					await this.applyTableWrite(transaction, write, committedSeq);
				await this.applyDocumentActions(
					transaction,
					documentActions,
					committedSeq,
				);
				transaction.exec(
					"UPDATE durable_metadata SET next_id = ?, next_seq = ? WHERE singleton = 1",
					String(Math.max(Number(text(metadata, "next_id")), candidateNextId)),
					committedSeq + 1,
				);
				return committedSeq;
			},
		);
		this.nextId = Math.max(this.nextId, candidateNextId);
		return seq;
	}

	async mintId<I extends Id<string>>(): Promise<I> {
		this.assertOpen();
		if (!Number.isSafeInteger(this.nextId))
			throw new Error("ID space is exhausted");
		return idFromNumber<I>(this.nextId++);
	}

	async conversation(
		id: ConversationId,
		_context: Context,
	): Promise<ConversationRecord | undefined> {
		this.assertOpen();
		const row = query(this.storage, () => true).get(
			"SELECT record FROM conversations WHERE id = ?",
			id,
		);
		return row === undefined
			? undefined
			: await this.decodeRecord<ConversationRecord>(
					text(row, "record"),
					`conversations/${id}`,
				);
	}

	async scanConversations(
		queryFilter: ConversationQuery,
		limit: number,
		cursor: Cursor | undefined,
		_context: Context,
	): Promise<Page<ConversationRecord, Cursor>> {
		this.assertOpen();
		const clauses = ["id > ?"];
		const params: Sql[] = [cursorId(cursor) ?? -1];
		if (queryFilter.ownerConversationId !== undefined) {
			clauses.push("owner_conversation_id = ?");
			params.push(queryFilter.ownerConversationId);
		}
		if (queryFilter.ownerTaskId !== undefined) {
			clauses.push("owner_task_id = ?");
			params.push(queryFilter.ownerTaskId);
		}
		params.push(limit + 1);
		const rows = query(this.storage, () => true).all(
			`SELECT id, record FROM conversations WHERE ${clauses.join(" AND ")} ORDER BY id LIMIT ?`,
			...params,
		);
		return page(
			await Promise.all(
				rows.map(async (row) =>
					this.decodeRecord<ConversationRecord>(
						text(row, "record"),
						`conversations/${integer(row, "id")}`,
					),
				),
			),
			limit,
		);
	}

	entry(
		id: EntryId,
		context: Context,
	): Promise<
		{ readonly entry: EntryRecord; readonly commitSeq: Seq } | undefined
	>;
	entry(
		conversationId: ConversationId,
		id: EntryId,
		context: Context,
	): Promise<
		{ readonly entry: EntryRecord; readonly commitSeq: Seq } | undefined
	>;
	entry(
		idOrConversationId: EntryId | ConversationId,
		idOrContext: EntryId | Context,
		context?: Context,
	): Promise<
		{ readonly entry: EntryRecord; readonly commitSeq: Seq } | undefined
	> {
		return this.admitRead(() =>
			this.readEntry(idOrConversationId, idOrContext, context),
		);
	}

	findLatestHeadMarker(
		conversationId: ConversationId,
		atOrBeforeEntryId: EntryId | undefined,
		_context: Context,
	): Promise<(EntryRecord & { readonly head: EntryId }) | undefined> {
		return this.admitRead(() =>
			this.readLatestHeadMarker(conversationId, atOrBeforeEntryId),
		);
	}

	scanEntries(
		queryFilter: EntryQuery,
		limit: number,
		cursor: Cursor | undefined,
		_context: Context,
	): Promise<Page<EntryRecord, Cursor>> {
		return this.admitRead(() => this.readEntries(queryFilter, limit, cursor));
	}

	async task(id: TaskId, _context: Context): Promise<StoredTask | undefined> {
		this.assertOpen();
		const row = query(this.storage, () => true).get(
			"SELECT record FROM tasks WHERE id = ?",
			id,
		);
		return row === undefined
			? undefined
			: this.decodeRecord<StoredTask>(text(row, "record"), `tasks/${id}`);
	}

	async scanTasks(
		queryFilter: TaskQuery,
		limit: number,
		cursor: Cursor | undefined,
		_context: Context,
	): Promise<Page<StoredTask, Cursor>> {
		this.assertOpen();
		const clauses = ["id > ?"];
		const params: Sql[] = [cursorId(cursor) ?? -1];
		if (queryFilter.conversationId !== undefined) {
			clauses.push("conversation_id = ?");
			params.push(queryFilter.conversationId);
		}
		if (queryFilter.kind !== undefined) {
			clauses.push("kind = ?");
			params.push(encodeIndexedString(queryFilter.kind));
		}
		if (queryFilter.status !== undefined) {
			clauses.push("status = ?");
			params.push(queryFilter.status);
		}
		if (queryFilter.abortRequested !== undefined) {
			clauses.push("abort_requested = ?");
			params.push(queryFilter.abortRequested ? 1 : 0);
		}
		if (queryFilter.background !== undefined) {
			clauses.push("background = ?");
			params.push(queryFilter.background ? 1 : 0);
		}
		params.push(limit + 1);
		const rows = query(this.storage, () => true).all(
			`SELECT id, record FROM tasks WHERE ${clauses.join(" AND ")} ORDER BY id LIMIT ?`,
			...params,
		);
		return page(
			await Promise.all(
				rows.map((row) =>
					this.decodeRecord<StoredTask>(
						text(row, "record"),
						`tasks/${integer(row, "id")}`,
					),
				),
			),
			limit,
		);
	}

	async submission(
		id: SubmissionId,
		_context: Context,
	): Promise<SubmissionRecord | undefined> {
		this.assertOpen();
		const row = query(this.storage, () => true).get(
			"SELECT record FROM submissions WHERE id = ?",
			id,
		);
		return row === undefined
			? undefined
			: this.decodeRecord<SubmissionRecord>(
					text(row, "record"),
					`submissions/${id}`,
				);
	}

	async scanSubmissions(
		queryFilter: SubmissionQuery,
		limit: number,
		cursor: Cursor | undefined,
		_context: Context,
	): Promise<Page<SubmissionRecord, Cursor>> {
		this.assertOpen();
		const clauses = ["id > ?"];
		const params: Sql[] = [cursorId(cursor) ?? -1];
		if (queryFilter.conversationId !== undefined) {
			clauses.push("conversation_id = ?");
			params.push(queryFilter.conversationId);
		}
		if (queryFilter.status !== undefined) {
			clauses.push("status = ?");
			params.push(queryFilter.status);
		}
		params.push(limit + 1);
		const rows = query(this.storage, () => true).all(
			`SELECT id, record FROM submissions WHERE ${clauses.join(" AND ")} ORDER BY id LIMIT ?`,
			...params,
		);
		return page(
			await Promise.all(
				rows.map((row) =>
					this.decodeRecord<SubmissionRecord>(
						text(row, "record"),
						`submissions/${integer(row, "id")}`,
					),
				),
			),
			limit,
		);
	}

	async submissionByRequest(
		conversationId: ConversationId,
		requestId: string,
		_context: Context,
	): Promise<SubmissionRecord | undefined> {
		this.assertOpen();
		const row = query(this.storage, () => true).get(
			"SELECT id, record FROM submissions WHERE conversation_id = ? AND request_id = ?",
			conversationId,
			encodeIndexedString(requestId),
		);
		return row === undefined
			? undefined
			: this.decodeRecord<SubmissionRecord>(
					text(row, "record"),
					`submissions/${integer(row, "id")}`,
				);
	}

	async findDocument(
		address: DocumentAddress,
		at: DocumentPoint,
		_context: Context,
	): Promise<DocumentRecord | undefined> {
		this.assertOpen();
		const parts = addressParts(address);
		const sql =
			at === "current"
				? `SELECT id, record FROM documents
					WHERE kind = ? AND scope_kind = ? AND owner_id = ? AND family = ? AND key_value = ?
					AND retired_at IS NULL ORDER BY created_at DESC LIMIT 1`
				: `SELECT id, record FROM documents
					WHERE kind = ? AND scope_kind = ? AND owner_id = ? AND family = ? AND key_value = ?
					AND created_at <= ? AND (retired_at IS NULL OR retired_at > ?)
					ORDER BY created_at DESC LIMIT 1`;
		const params: Sql[] = [
			parts.kind,
			parts.scopeKind,
			parts.ownerId,
			parts.family,
			parts.keyValue,
		];
		if (at !== "current") params.push(at, at);
		const row = query(this.storage, () => true).get(sql, ...params);
		return row === undefined
			? undefined
			: this.decodeRecord<DocumentRecord>(
					text(row, "record"),
					`documents/${integer(row, "id")}`,
				);
	}

	async document(
		id: DocumentId,
		at: DocumentPoint,
		_context: Context,
	): Promise<StoredDocument | undefined> {
		this.assertOpen();
		return runRetainedTransaction(this.storage, (transaction) =>
			this.materializeDocument(transaction, id, at),
		);
	}

	async scanDocuments(
		queryFilter: DocumentQuery,
		limit: number,
		cursor: Cursor | undefined,
		_context: Context,
	): Promise<Page<DocumentRecord, Cursor>> {
		this.assertOpen();
		const scope = scopeColumns(queryFilter.scope);
		const clauses = ["scope_kind = ?", "owner_id = ?", "id > ?"];
		const params: Sql[] = [
			scope.scopeKind,
			scope.ownerId,
			cursorId(cursor) ?? -1,
		];
		if (queryFilter.kind !== undefined) {
			clauses.push("kind = ?");
			params.push(encodeIndexedString(queryFilter.kind));
		}
		if (queryFilter.at === "current") clauses.push("retired_at IS NULL");
		else {
			clauses.push("created_at <= ?", "(retired_at IS NULL OR retired_at > ?)");
			params.push(queryFilter.at, queryFilter.at);
		}
		params.push(limit + 1);
		const rows = query(this.storage, () => true).all(
			`SELECT id, record FROM documents WHERE ${clauses.join(" AND ")} ORDER BY id LIMIT ?`,
			...params,
		);
		return page(
			await Promise.all(
				rows.map((row) =>
					this.decodeRecord<DocumentRecord>(
						text(row, "record"),
						`documents/${integer(row, "id")}`,
					),
				),
			),
			limit,
		);
	}

	close(_context: Context): Promise<void> {
		if (this.closing === undefined) {
			this.closed = true;
			this.closing = this.finishClose();
		}
		return this.closing;
	}

	private async finishClose(): Promise<void> {
		if (this.admittedReads > 0) {
			await new Promise<void>((resolve) => {
				this.readsDrained = resolve;
			});
		}
	}

	private async admitRead<T>(read: () => Promise<T>): Promise<T> {
		this.assertOpen();
		this.admittedReads += 1;
		try {
			return await read();
		} finally {
			this.admittedReads -= 1;
			if (this.admittedReads === 0) this.readsDrained?.();
		}
	}

	private async readConversation(
		id: ConversationId,
	): Promise<ConversationRecord | undefined> {
		const row = query(this.storage, () => true).get(
			"SELECT record FROM conversations WHERE id = ?",
			id,
		);
		return row === undefined
			? undefined
			: this.decodeRecord<ConversationRecord>(
					text(row, "record"),
					`conversations/${id}`,
				);
	}

	private async readEntry(
		idOrConversationId: number,
		idOrContext: EntryId | Context,
		context: Context | undefined,
	) {
		const id =
			context === undefined
				? idFromNumber<EntryId>(idOrConversationId)
				: typeof idOrContext === "number"
					? idFromNumber<EntryId>(idOrContext)
					: undefined;
		if (id === undefined)
			throw new TypeError("Storage.entry() requires an entry ID");
		let conversation: ConversationRecord | undefined;
		if (context !== undefined) {
			const conversationId = idFromNumber<ConversationId>(idOrConversationId);
			conversation = await this.readConversation(conversationId);
			if (conversation === undefined)
				throw new Error(`Unknown conversation: ${conversationId}`);
		}
		const row = query(this.storage, () => true).get(
			"SELECT record, commit_seq FROM entries WHERE id = ?",
			id,
		);
		if (row === undefined) return undefined;
		const entry = await this.decodeRecord<EntryRecord>(
			text(row, "record"),
			`entries/${id}`,
		);
		if (conversation !== undefined) {
			let upperEntryId = Number.POSITIVE_INFINITY;
			while (conversation.id !== entry.conversationId) {
				if (conversation.parent === undefined) return undefined;
				upperEntryId = Math.min(upperEntryId, conversation.parent.at);
				const parent = await this.readConversation(
					conversation.parent.conversationId,
				);
				if (parent === undefined)
					throw new EncryptedStorageError(
						"integrity",
						"Missing parent conversation",
					);
				conversation = parent;
			}
			if (entry.id > upperEntryId) return undefined;
		}
		return { entry, commitSeq: seqFromNumber(integer(row, "commit_seq")) };
	}

	private async readLatestHeadMarker(
		conversationId: ConversationId,
		atOrBeforeEntryId: EntryId | undefined,
	) {
		let conversation = await this.readConversation(conversationId);
		if (conversation === undefined)
			throw new Error(`Unknown conversation: ${conversationId}`);
		let upper: number | undefined = atOrBeforeEntryId;
		const db = query(this.storage, () => true);
		while (true) {
			const row =
				upper === undefined
					? db.get(
							"SELECT id, record FROM entries WHERE conversation_id = ? AND head IS NOT NULL ORDER BY id DESC LIMIT 1",
							conversation.id,
						)
					: db.get(
							"SELECT id, record FROM entries WHERE conversation_id = ? AND head IS NOT NULL AND id <= ? ORDER BY id DESC LIMIT 1",
							conversation.id,
							upper,
						);
			if (row !== undefined) {
				return this.decodeRecord<EntryRecord & { head: EntryId }>(
					text(row, "record"),
					`entries/${integer(row, "id")}`,
				);
			}
			if (conversation.parent === undefined) return undefined;
			upper =
				upper === undefined
					? conversation.parent.at
					: Math.min(upper, conversation.parent.at);
			const parent = await this.readConversation(
				conversation.parent.conversationId,
			);
			if (parent === undefined)
				throw new EncryptedStorageError(
					"integrity",
					"Missing parent conversation",
				);
			conversation = parent;
		}
	}

	private async readEntries(
		queryFilter: EntryQuery,
		limit: number,
		cursor: Cursor | undefined,
	) {
		let conversation = await this.readConversation(queryFilter.conversationId);
		if (conversation === undefined)
			throw new Error(`Unknown conversation: ${queryFilter.conversationId}`);
		const after = cursorId(cursor);
		let upper: number | undefined = queryFilter.maxEntryId;
		if (after !== undefined)
			upper = Math.min(upper ?? Number.MAX_SAFE_INTEGER, after - 1);
		const values: EntryRecord[] = [];
		const db = query(this.storage, () => true);
		while (true) {
			const clauses = ["conversation_id = ?"];
			const params: Sql[] = [conversation.id];
			if (queryFilter.minEntryId !== undefined) {
				clauses.push("id >= ?");
				params.push(queryFilter.minEntryId);
			}
			if (upper !== undefined) {
				clauses.push("id <= ?");
				params.push(upper);
			}
			params.push(limit + 1 - values.length);
			const rows = db.all(
				`SELECT id, record FROM entries WHERE ${clauses.join(" AND ")} ORDER BY id DESC LIMIT ?`,
				...params,
			);
			for (const row of rows) {
				values.push(
					await this.decodeRecord<EntryRecord>(
						text(row, "record"),
						`entries/${integer(row, "id")}`,
					),
				);
			}
			if (values.length > limit || conversation.parent === undefined) break;
			upper =
				upper === undefined
					? conversation.parent.at
					: Math.min(upper, conversation.parent.at);
			if (
				queryFilter.minEntryId !== undefined &&
				upper < queryFilter.minEntryId
			)
				break;
			const parent = await this.readConversation(
				conversation.parent.conversationId,
			);
			if (parent === undefined)
				throw new EncryptedStorageError(
					"integrity",
					"Missing parent conversation",
				);
			conversation = parent;
		}
		return page(values, limit);
	}

	private async materializeDocument(
		executor: Query,
		id: DocumentId,
		at: DocumentPoint,
	): Promise<StoredDocument | undefined> {
		const row = executor.get("SELECT record FROM documents WHERE id = ?", id);
		if (row === undefined) return undefined;
		const record = await this.decodeRecord<DocumentRecord>(
			text(row, "record"),
			`documents/${id}`,
		);
		if (at !== "current" && isCurrentOnly(record))
			throw new Error(`Document ${id} does not retain historical content`);
		if (!isAliveAt(record, at)) return undefined;
		const upper = at === "current" ? Number.MAX_SAFE_INTEGER : at;
		const base = executor.get(
			`SELECT seq, kind, version, content FROM document_revisions
				WHERE document_id = ? AND kind = 'base' AND seq <= ? ORDER BY seq DESC LIMIT 1`,
			id,
			upper,
		);
		if (base === undefined)
			throw new Error(`Document ${id} is missing a required base`);
		let value = await this.decodeJson(
			text(base, "content"),
			`document_revisions/${id}/${integer(base, "seq")}`,
		);
		const tail = executor.all(
			`SELECT seq, kind, version, content FROM document_revisions
				WHERE document_id = ? AND seq > ? AND seq <= ? ORDER BY seq`,
			id,
			integer(base, "seq"),
			upper,
		);
		for (const revision of tail) {
			if (
				text(revision, "kind") !== "delta" ||
				integer(revision, "version") !== integer(base, "version")
			) {
				throw new Error(
					`Document ${id} crosses a stored version boundary without a base`,
				);
			}
			const ops = await this.decodeJson(
				text(revision, "content"),
				`document_revisions/${id}/${integer(revision, "seq")}`,
			);
			if (!Array.isArray(ops))
				throw new EncryptedStorageError("integrity", "Invalid document delta");
			value = apply(value, ops as Op[]);
		}
		if (typeof value !== "object" || value === null || Array.isArray(value))
			throw new EncryptedStorageError("integrity", "Invalid document value");
		return {
			record,
			version: integer(base, "version"),
			value: value as StoredDocument["value"],
			deltasSinceBase: tail.length,
		};
	}

	private candidateNextId(writes: readonly StorageWrite[]): number {
		let nextId = this.nextId;
		for (const write of writes) {
			const id = writeId(write);
			if (id !== undefined) nextId = Math.max(nextId, id + 1);
		}
		return nextId;
	}

	private async checkGlobalIds(
		executor: Query,
		writes: readonly StorageWrite[],
	) {
		const claimed = new Map<number, string>();
		for (const write of writes) {
			if (write.type === "document.change" || write.type === "document.retire")
				continue;
			const document =
				write.type === "document.create" || write.type === "document.copy";
			const table = document ? "document" : write.type;
			const id = document ? write.record.id : write.value.id;
			const existing = executor.get(
				"SELECT record_type FROM record_ids WHERE id = ?",
				id,
			)?.record_type;
			const earlier = claimed.get(id);
			if (
				table === "conversation" ||
				table === "entry" ||
				table === "document"
			) {
				if (existing !== undefined)
					throw new Error(`ID ${id} already belongs to ${existing}`);
				if (earlier !== undefined)
					throw new Error(`ID ${id} is written more than once`);
			} else {
				if (existing !== undefined && existing !== table)
					throw new Error(`ID ${id} already belongs to ${existing}`);
				if (earlier !== undefined && earlier !== table)
					throw new Error(`ID ${id} is written as two record types`);
			}
			claimed.set(id, table);
		}
	}

	private prepareDocumentActions(writes: readonly StorageWrite[]) {
		const actions = new Map<number, DocumentAction>();
		for (const write of writes) {
			if (
				write.type !== "document.create" &&
				write.type !== "document.copy" &&
				write.type !== "document.change" &&
				write.type !== "document.retire"
			)
				continue;
			const id =
				write.type === "document.create" || write.type === "document.copy"
					? write.record.id
					: write.id;
			let action = actions.get(id);
			if (action === undefined) {
				action = { retire: false };
				actions.set(id, action);
			}
			switch (write.type) {
				case "document.create":
					if (
						action.create !== undefined ||
						action.content !== undefined ||
						action.copy !== undefined
					)
						throw new Error(`Document ${id} has more than one content command`);
					action.create = write.record;
					action.content = write.content;
					break;
				case "document.copy":
					if (
						action.create !== undefined ||
						action.content !== undefined ||
						action.copy !== undefined
					)
						throw new Error(`Document ${id} has more than one content command`);
					action.create = write.record;
					action.copy = write.source;
					break;
				case "document.change":
					if (action.content !== undefined || action.copy !== undefined)
						throw new Error(`Document ${id} has more than one content command`);
					action.content = write.content;
					break;
				case "document.retire":
					if (action.retire)
						throw new Error(`Document ${id} is retired more than once`);
					action.retire = true;
					break;
			}
		}
		return actions;
	}

	private async checkDocumentActions(
		executor: Query,
		actions: Map<number, DocumentAction>,
	) {
		const liveCounts = new Map<string, number>();
		for (const [id, action] of actions) {
			if (action.copy !== undefined && actions.has(action.copy.id))
				throw new StorageRejected(
					`Document copy ${id} source is changed in the copy batch`,
				);
			const row = executor.get("SELECT record FROM documents WHERE id = ?", id);
			const existing =
				row === undefined
					? undefined
					: await this.decodeRecord<DocumentRecord>(
							text(row, "record"),
							`documents/${id}`,
						);
			if (action.create === undefined && existing === undefined)
				throw new Error(`Unknown document: ${id}`);
			if (action.create !== undefined && existing !== undefined)
				throw new Error(`Document ${id} already exists`);
			if (existing?.retiredAt !== undefined)
				throw new Error(`Document ${id} is retired`);
			if (action.content?.kind === "delta") {
				const previous = executor.get(
					"SELECT version FROM document_revisions WHERE document_id = ? ORDER BY seq DESC LIMIT 1",
					id,
				);
				if (previous === undefined)
					throw new Error(`Document ${id} delta has no base`);
				if (integer(previous, "version") !== action.content.version)
					throw new Error(`Document ${id} version transition requires a base`);
			}
			const record = action.create ?? existing;
			if (record === undefined) throw new Error(`Unknown document: ${id}`);
			const key = addressKey(record);
			let live = liveCounts.get(key);
			if (live === undefined)
				live =
					(await this.currentDocumentId(executor, record)) === undefined
						? 0
						: 1;
			if (action.retire && existing !== undefined) live -= 1;
			if (action.create !== undefined && !action.retire) live += 1;
			liveCounts.set(key, live);
		}
		for (const live of liveCounts.values()) {
			if (live > 1)
				throw new Error("Document address already has a current incarnation");
		}
	}

	private async currentDocumentId(
		executor: Query,
		address: { kind: string; scope: DocumentRecord["scope"]; key?: string },
	): Promise<DocumentId | undefined> {
		const parts = addressParts(address);
		const id = executor.get(
			`SELECT id FROM documents
				WHERE kind = ? AND scope_kind = ? AND owner_id = ? AND family = ? AND key_value = ? AND retired_at IS NULL
				LIMIT 1`,
			parts.kind,
			parts.scopeKind,
			parts.ownerId,
			parts.family,
			parts.keyValue,
		)?.id;
		return typeof id === "number" ? idFromNumber<DocumentId>(id) : undefined;
	}

	private async applyTableWrite(
		executor: Query,
		write: StorageWrite,
		seq: Seq,
	) {
		switch (write.type) {
			case "conversation":
				await this.claimId(executor, write.value.id, "conversation");
				executor.exec(
					"INSERT INTO conversations (id, owner_conversation_id, owner_task_id, record) VALUES (?, ?, ?, ?)",
					write.value.id,
					write.value.owner?.conversationId ?? null,
					write.value.owner?.taskId ?? null,
					await this.encodeRecord(
						write.value,
						`conversations/${write.value.id}`,
					),
				);
				break;
			case "entry":
				await this.claimId(executor, write.value.id, "entry");
				executor.exec(
					"INSERT INTO entries (id, conversation_id, head, commit_seq, record) VALUES (?, ?, ?, ?, ?)",
					write.value.id,
					write.value.conversationId,
					write.value.head ?? null,
					seq,
					await this.encodeRecord(write.value, `entries/${write.value.id}`),
				);
				break;
			case "task":
				await this.claimId(executor, write.value.id, "task");
				executor.exec(
					`INSERT INTO tasks (id, conversation_id, kind, status, abort_requested, background, record)
						VALUES (?, ?, ?, ?, ?, ?, ?)
						ON CONFLICT(id) DO UPDATE SET conversation_id = excluded.conversation_id, kind = excluded.kind,
						status = excluded.status, abort_requested = excluded.abort_requested,
						background = excluded.background, record = excluded.record`,
					write.value.id,
					write.value.conversationId,
					encodeIndexedString(write.value.kind),
					write.value.state.status,
					write.value.abortRequested ? 1 : 0,
					write.value.background ? 1 : 0,
					await this.encodeRecord(write.value, `tasks/${write.value.id}`),
				);
				break;
			case "submission":
				await this.claimId(executor, write.value.id, "submission");
				executor.exec(
					`INSERT INTO submissions (id, conversation_id, request_id, status, record) VALUES (?, ?, ?, ?, ?)
						ON CONFLICT(id) DO UPDATE SET conversation_id = excluded.conversation_id,
						request_id = excluded.request_id, status = excluded.status, record = excluded.record`,
					write.value.id,
					write.value.conversationId,
					write.value.requestId === undefined
						? null
						: encodeIndexedString(write.value.requestId),
					write.value.status,
					await this.encodeRecord(write.value, `submissions/${write.value.id}`),
				);
				break;
			case "document.create":
			case "document.copy":
			case "document.change":
			case "document.retire":
				break;
		}
	}

	private async claimId(executor: Query, id: number, table: string) {
		executor.exec(
			"INSERT OR IGNORE INTO record_ids (id, record_type) VALUES (?, ?)",
			id,
			table,
		);
	}

	private async applyDocumentActions(
		executor: Query,
		actions: Map<number, DocumentAction>,
		seq: Seq,
	) {
		for (const [id, action] of actions) {
			let content = action.content;
			if (action.copy !== undefined) {
				try {
					const stored = await this.materializeDocument(
						executor,
						action.copy.id,
						action.copy.at,
					);
					if (stored === undefined)
						throw new Error(
							`Fork source document ${action.copy.id} cannot be read`,
						);
					const create = action.create;
					if (create === undefined)
						throw new Error(`Document ${id} has more than one content command`);
					if (
						stored.record.scope.kind !== "conversation" ||
						create.scope.kind !== "conversation" ||
						stored.record.kind !== create.kind ||
						stored.record.key !== create.key ||
						stored.record.history !== create.history ||
						stored.record.fork !== create.fork
					) {
						throw new Error(
							`Fork source document ${action.copy.id} does not match the copied record`,
						);
					}
					content = {
						kind: "base",
						version: stored.version,
						value: stored.value,
					};
				} catch (error) {
					if (error instanceof StorageRejected) throw error;
					throw new StorageRejected(`Document copy ${id} was rejected`, {
						cause: error,
					});
				}
			}
			let record: DocumentRecord;
			if (action.create !== undefined) {
				record = {
					...action.create,
					createdAt: seq,
					...(action.retire ? { retiredAt: seq } : {}),
				};
				const parts = addressParts(record);
				await this.claimId(executor, id, "document");
				executor.exec(
					`INSERT INTO documents
						(id, kind, family, key_value, scope_kind, owner_id, created_at, retired_at, record)
						VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
					id,
					parts.kind,
					parts.family,
					parts.keyValue,
					parts.scopeKind,
					parts.ownerId,
					seq,
					action.retire ? seq : null,
					await this.encodeRecord(record, `documents/${id}`),
				);
			} else {
				const row = executor.get(
					"SELECT record FROM documents WHERE id = ?",
					id,
				);
				if (row === undefined) throw new Error(`Unknown document: ${id}`);
				record = await this.decodeRecord<DocumentRecord>(
					text(row, "record"),
					`documents/${id}`,
				);
			}
			if (content !== undefined) {
				if (content.kind === "base" && isCurrentOnly(record))
					executor.exec(
						"DELETE FROM document_revisions WHERE document_id = ?",
						id,
					);
				const encoded =
					content.kind === "base"
						? encodeJson(content.value)
						: encodeJson(content.ops);
				executor.exec(
					"INSERT INTO document_revisions (document_id, seq, kind, version, content) VALUES (?, ?, ?, ?, ?)",
					id,
					seq,
					content.kind,
					content.version,
					await this.encodeText(encoded, `document_revisions/${id}/${seq}`),
				);
			}
			if (action.retire) {
				if (action.create === undefined) {
					record = { ...record, retiredAt: seq };
					executor.exec(
						"UPDATE documents SET retired_at = ?, record = ? WHERE id = ?",
						seq,
						await this.encodeRecord(record, `documents/${id}`),
						id,
					);
				}
				if (isCurrentOnly(record))
					executor.exec(
						"DELETE FROM document_revisions WHERE document_id = ?",
						id,
					);
			}
		}
	}

	private async verifyAll(): Promise<void> {
		const db = query(this.storage, () => true);
		for (const row of db.all("SELECT id, record FROM conversations"))
			await this.decodeRecord(
				text(row, "record"),
				`conversations/${integer(row, "id")}`,
			);
		for (const row of db.all("SELECT id, record FROM entries"))
			await this.decodeRecord(
				text(row, "record"),
				`entries/${integer(row, "id")}`,
			);
		for (const row of db.all("SELECT id, record FROM tasks"))
			await this.decodeRecord(
				text(row, "record"),
				`tasks/${integer(row, "id")}`,
			);
		for (const row of db.all("SELECT id, record FROM submissions"))
			await this.decodeRecord(
				text(row, "record"),
				`submissions/${integer(row, "id")}`,
			);
		for (const row of db.all("SELECT id, record FROM documents"))
			await this.decodeRecord(
				text(row, "record"),
				`documents/${integer(row, "id")}`,
			);
		for (const row of db.all(
			"SELECT document_id, seq, content FROM document_revisions",
		))
			await this.decodeJson(
				text(row, "content"),
				`document_revisions/${integer(row, "document_id")}/${integer(row, "seq")}`,
			);
	}

	private async encodeRecord(
		value: unknown,
		recordId: string,
	): Promise<string> {
		return this.encodeText(encodeJson(value), recordId);
	}

	private async encodeText(
		plaintext: string,
		recordId: string,
	): Promise<string> {
		const sealed = await encryptRuntimePayload(
			new TextEncoder().encode(plaintext),
			this.binding.keyring,
			this.aad(recordId),
			this.options,
		);
		return sealed.kind === "inline"
			? serializeRuntimeCiphertext(sealed.envelope)
			: serializeRuntimeManifest(sealed.manifest);
	}

	private async decodeRecord<T>(stored: string, recordId: string): Promise<T> {
		const value = await this.decodeJson(stored, recordId);
		return value as T;
	}

	private async decodeJson(stored: string, recordId: string): Promise<unknown> {
		let parsed: unknown;
		try {
			parsed = JSON.parse(stored) as unknown;
		} catch {
			throw new EncryptedStorageError("integrity", "Storage integrity failure");
		}
		if (isExternalRef(parsed))
			throw new EncryptedStorageError(
				"unresolved_external_ref",
				"Unresolved external record reference",
			);
		try {
			const bytes = isManifest(parsed)
				? await decryptRuntimePayload(
						{ kind: "chunked", manifest: parseRuntimeManifest(parsed) },
						this.binding.keyring,
						this.aad(recordId),
					)
				: await decryptRuntimePayload(
						{ kind: "inline", envelope: parseRuntimeCiphertextV1(parsed) },
						this.binding.keyring,
						this.aad(recordId),
					);
			return JSON.parse(new TextDecoder().decode(bytes)) as unknown;
		} catch (error) {
			if (error instanceof EncryptedStorageError) throw error;
			throw new EncryptedStorageError("integrity", "Storage integrity failure");
		}
	}

	private aad(recordId: string) {
		return {
			ownerId: this.binding.ownerId,
			workspaceSessionId: this.binding.workspaceSessionId,
			recordId,
			formatVersion: RUNTIME_CRYPTO_FORMAT_VERSION,
		};
	}

	private assertOpen() {
		if (this.closed) throw new Error("EncryptedPiStorage is closed");
	}
}

function isManifest(value: unknown): boolean {
	return (
		typeof value === "object" &&
		value !== null &&
		!Array.isArray(value) &&
		"chunkCount" in value &&
		"chunks" in value
	);
}

async function ensureSchema(storage: DurableObjectStorage): Promise<void> {
	const existing = storage.sql
		.exec<{ name: string }>(
			"SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'ditto_storage_meta'",
		)
		.toArray();
	if (existing.length === 0) {
		const stock = storage.sql
			.exec<{ name: string }>(
				"SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('durable_schema', 'conversations', 'tasks')",
			)
			.toArray();
		if (stock.length > 0)
			throw new EncryptedStorageError(
				"plaintext_retained",
				"Plaintext storage cannot be opened as retained",
			);
		await runRetainedTransaction(storage, async (tx) => {
			for (const statement of SCHEMA) tx.exec(statement);
		});
		return;
	}
	const row = storage.sql
		.exec<{
			format_version: number;
			engine_compat: string;
			task_compat: string;
			tool_compat: string;
			provider_compat: string;
			adapter_compat: string;
		}>(
			"SELECT format_version, engine_compat, task_compat, tool_compat, provider_compat, adapter_compat FROM ditto_storage_meta WHERE singleton = 1",
		)
		.toArray()[0];
	if (
		row === undefined ||
		row.format_version !== ENCRYPTED_STORAGE_FORMAT ||
		row.engine_compat !== ENGINE_COMPAT ||
		row.task_compat !== TASK_COMPAT ||
		row.tool_compat !== TOOL_COMPAT ||
		row.provider_compat !== PROVIDER_COMPAT ||
		row.adapter_compat !== ADAPTER_COMPAT
	)
		throw new EncryptedStorageError(
			"incompatible",
			"Incompatible encrypted storage",
		);
}
