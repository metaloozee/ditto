import { env, runInDurableObject } from "cloudflare:test";
import { BACKGROUND_CONTEXT } from "@earendil-works/chord/context";
import {
	type DocumentId,
	type EntryId,
	ROOT_CONVERSATION_ID,
} from "@earendil-works/pi-durable";
import { registerStorageConformance } from "@earendil-works/pi-durable/testing";
import { describe, expect, it } from "vitest";
import type { RetainedStorageBinding } from "./host-private.ts";
import type { PiDurableHostFixture } from "./pi-durable-host.ts";
import {
	EncryptedPiStorage,
	EncryptedStorageError,
	runRetainedTransaction,
} from "./pi-durable-storage.ts";
import { importRuntimeKeyringFromBytes } from "./runtime-crypto.ts";

declare module "cloudflare:test" {
	interface ProvidedEnv {
		PI_HOST_STORAGE: DurableObjectNamespace<PiDurableHostFixture>;
	}
}

const SENTINEL = "SENTINEL_private_payload_004";

function keyBytes(fill: number): Uint8Array {
	return new Uint8Array(32).fill(fill);
}

async function binding(
	current = "v1",
	keys: Record<string, number> = { v1: 7 },
	ownerId = "owner-004",
	workspaceSessionId = "session-004",
): Promise<RetainedStorageBinding> {
	return {
		ownerId,
		workspaceSessionId,
		keyring: await importRuntimeKeyringFromBytes(
			current,
			Object.fromEntries(
				Object.entries(keys).map(([version, fill]) => [
					version,
					keyBytes(fill),
				]),
			),
		),
	};
}

async function withDo(
	name: string,
	use: (
		storage: DurableObjectStorage,
		binding: RetainedStorageBinding,
	) => Promise<void>,
) {
	const stub = env.PI_HOST_STORAGE.getByName(name);
	await runInDurableObject(stub, async (_instance, state) => {
		await use(state.storage, await binding());
	});
}

registerStorageConformance(
	{ describe, expect, it },
	"encrypted DO SQLite",
	async (use) => {
		const stub = env.PI_HOST_STORAGE.getByName(
			`conformance-${crypto.randomUUID()}`,
		);
		await runInDurableObject(stub, async (_instance, state) => {
			const storage = await EncryptedPiStorage.open(
				state.storage,
				await binding(),
			);
			try {
				await use(storage);
			} finally {
				await storage.close(BACKGROUND_CONTEXT);
			}
		});
	},
);

describe("encrypted storage transactions and integrity", () => {
	it("rejects a callback, rolls back, excludes unrelated work, and expires the handle", async () => {
		const stub = env.PI_HOST_STORAGE.getByName("tx-faults");
		await runInDurableObject(stub, async (_instance, state) => {
			await runRetainedTransaction(state.storage, async (tx) => {
				tx.exec("CREATE TABLE tx_probe (id INTEGER PRIMARY KEY, note TEXT)");
				tx.exec("INSERT INTO tx_probe VALUES (1, 'kept')");
			});
		});
		let release!: () => void;
		const hold = new Promise<void>((resolve) => {
			release = resolve;
		});
		let started!: () => void;
		const startedPromise = new Promise<void>((resolve) => {
			started = resolve;
		});
		let expired: QueryHandle | undefined;
		const rolled = runInDurableObject(stub, async (_instance, state) => {
			try {
				await runRetainedTransaction(state.storage, async (tx) => {
					expired = tx;
					tx.exec("INSERT INTO tx_probe VALUES (2, 'lost')");
					started();
					await hold;
					throw new Error("Synthetic callback rejection");
				});
			} finally {
				expect(() => expired?.get("SELECT id FROM tx_probe")).toThrow(
					/Expired storage transaction/,
				);
			}
		});
		await startedPromise;
		let unrelatedResolved = false;
		const unrelated = runInDurableObject(
			stub,
			async (_instance, state) =>
				state.storage.sql
					.exec<{ n: number }>("SELECT COUNT(*) AS n FROM tx_probe")
					.one().n,
		).then((count) => {
			unrelatedResolved = true;
			return count;
		});
		await new Promise((resolve) => setTimeout(resolve, 30));
		expect(unrelatedResolved).toBe(false);
		release();
		await expect(rolled).rejects.toThrow("Synthetic callback rejection");
		await expect(unrelated).resolves.toBe(1);
	});

	it("reopens encrypted rows in order and keeps sentinels out of raw record bodies", async () => {
		const stub = env.PI_HOST_STORAGE.getByName("reopen-sentinel");
		await runInDurableObject(stub, async (_instance, state) => {
			const keys = await binding();
			const first = await EncryptedPiStorage.open(state.storage, keys);
			const root = ROOT_CONVERSATION_ID;
			await first.commit(
				[{ type: "conversation", value: { id: root } }],
				BACKGROUND_CONTEXT,
			);
			const entryId = await first.mintId<EntryId>();
			await first.commit(
				[
					{
						type: "entry",
						value: {
							id: entryId,
							conversationId: root,
							kind: "note",
							data: { text: SENTINEL },
						},
					},
				],
				BACKGROUND_CONTEXT,
			);
			await first.close(BACKGROUND_CONTEXT);
			const raw = state.storage.sql
				.exec<{ record: string }>("SELECT record FROM entries")
				.one().record;
			expect(raw).not.toContain(SENTINEL);
			expect(raw).toContain("aes-256-gcm");
			const second = await EncryptedPiStorage.open(state.storage, keys);
			expect(
				(await second.entry(entryId, BACKGROUND_CONTEXT))?.entry.data,
			).toEqual({
				text: SENTINEL,
			});
			await second.close(BACKGROUND_CONTEXT);
		});
	});

	it("round-trips chunked document content without storing the plaintext body", async () => {
		await withDo("chunked", async (storage, keys) => {
			const opened = await EncryptedPiStorage.open(storage, keys, {
				inlineMaxBytes: 8,
				chunkBytes: 4,
			});
			const root = ROOT_CONVERSATION_ID;
			await opened.commit(
				[{ type: "conversation", value: { id: root } }],
				BACKGROUND_CONTEXT,
			);
			const documentId = await opened.mintId<DocumentId>();
			await opened.commit(
				[
					{
						type: "document.create",
						record: {
							id: documentId,
							kind: "app.note",
							scope: { kind: "session" },
						},
						content: {
							kind: "base",
							version: 1,
							value: { text: SENTINEL },
						},
					},
				],
				BACKGROUND_CONTEXT,
			);
			const raw = storage.sql
				.exec<{ content: string }>("SELECT content FROM document_revisions")
				.one().content;
			expect(raw).not.toContain(SENTINEL);
			expect(raw).toContain("chunkCount");
			expect(
				(await opened.document(documentId, "current", BACKGROUND_CONTEXT))
					?.value,
			).toEqual({ text: SENTINEL });
			await opened.close(BACKGROUND_CONTEXT);
		});
	});

	it("fails closed on tamper, swap, wrong owner, missing key, rotation and bad versions", async () => {
		const stub = env.PI_HOST_STORAGE.getByName("integrity");
		await runInDurableObject(stub, async (_instance, state) => {
			const keys = await binding();
			const opened = await EncryptedPiStorage.open(state.storage, keys);
			const root = ROOT_CONVERSATION_ID;
			await opened.commit(
				[{ type: "conversation", value: { id: root } }],
				BACKGROUND_CONTEXT,
			);
			const first = await opened.mintId<EntryId>();
			const second = await opened.mintId<EntryId>();
			await opened.commit(
				[
					{
						type: "entry",
						value: {
							id: first,
							conversationId: root,
							kind: "note",
							data: { text: `${SENTINEL}-a` },
						},
					},
					{
						type: "entry",
						value: {
							id: second,
							conversationId: root,
							kind: "note",
							data: { text: `${SENTINEL}-b` },
						},
					},
				],
				BACKGROUND_CONTEXT,
			);
			await opened.close(BACKGROUND_CONTEXT);
			const rotated = await EncryptedPiStorage.open(
				state.storage,
				await binding("v2", { v1: 7, v2: 9 }),
			);
			expect(
				(await rotated.entry(first, BACKGROUND_CONTEXT))?.entry.data,
			).toEqual({
				text: `${SENTINEL}-a`,
			});
			const added = await rotated.mintId<EntryId>();
			await rotated.commit(
				[
					{
						type: "entry",
						value: {
							id: added,
							conversationId: root,
							kind: "note",
							data: { text: "rotated" },
						},
					},
				],
				BACKGROUND_CONTEXT,
			);
			const versions = state.storage.sql
				.exec<{ record: string }>("SELECT id, record FROM entries ORDER BY id")
				.toArray()
				.map((row) => JSON.parse(row.record) as { keyVersion: string });
			expect(versions.map((row) => row.keyVersion)).toEqual(["v1", "v1", "v2"]);
			await rotated.close(BACKGROUND_CONTEXT);
			await expect(
				EncryptedPiStorage.open(state.storage, await binding("v2", { v2: 9 })),
			).rejects.toThrow(EncryptedStorageError);
			await expect(
				EncryptedPiStorage.open(
					state.storage,
					await binding("v1", { v1: 7 }, "other-owner"),
				),
			).rejects.toThrow(/Storage integrity failure/);
			await expect(
				EncryptedPiStorage.open(
					state.storage,
					await binding("v1", { v1: 7 }, "owner-004", "other-session"),
				),
			).rejects.toThrow(/Storage integrity failure/);
			const rows = state.storage.sql
				.exec<{ id: number; record: string }>(
					"SELECT id, record FROM entries ORDER BY id",
				)
				.toArray();
			state.storage.sql.exec(
				"UPDATE entries SET record = ? WHERE id = ?",
				rows[1]?.record,
				rows[0]?.id,
			);
			await expect(
				EncryptedPiStorage.open(state.storage, keys),
			).rejects.toThrow(/Storage integrity failure/);
			state.storage.sql.exec(
				"UPDATE entries SET record = ? WHERE id = ?",
				rows[0]?.record,
				rows[0]?.id,
			);
			const envelope = JSON.parse(rows[0]?.record ?? "{}") as {
				ciphertext: string;
			};
			envelope.ciphertext = `${envelope.ciphertext.slice(0, -2)}${envelope.ciphertext.endsWith("AA") ? "BB" : "AA"}`;
			state.storage.sql.exec(
				"UPDATE entries SET record = ? WHERE id = ?",
				JSON.stringify(envelope),
				rows[0]?.id,
			);
			await expect(
				EncryptedPiStorage.open(state.storage, await binding("v1", { v1: 8 })),
			).rejects.toThrow(EncryptedStorageError);
			state.storage.sql.exec(
				"UPDATE ditto_storage_meta SET format_version = 99",
			);
			const scheduled = false;
			await expect(
				EncryptedPiStorage.open(state.storage, keys),
			).rejects.toThrow(/Incompatible encrypted storage/);
			expect(scheduled).toBe(false);
			state.storage.sql.exec(
				"UPDATE entries SET record = ? WHERE id = ?",
				JSON.stringify({
					kind: "external",
					version: 1,
					digest: "aa",
					byteCount: 3,
					locator: "r2/not-written",
				}),
				rows[0]?.id,
			);
			state.storage.sql.exec(
				"UPDATE ditto_storage_meta SET format_version = 1",
			);
			await expect(
				EncryptedPiStorage.open(state.storage, keys),
			).rejects.toThrow(/Unresolved external record reference/);
		});
	});
});

type QueryHandle = {
	get(sql: string, ...params: Array<string | number | null>): unknown;
};
